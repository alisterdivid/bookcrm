<?php
require_once("core/DB_Connection.php");
require_once("core/functions.php");
$ajax = isset($_REQUEST["ajax"]) ? $_REQUEST["ajax"] : "";
$action = isset($_REQUEST["action"]) ? $_REQUEST["action"] : "";
$op = isset($_REQUEST["op"]) ? $_REQUEST["op"] : "";

if ($op && $action){
	if ($action == "bulk"){
		include ("acuityscheduling/tpl/preferences/bulk.php");
		die();
	}
}
if ($action == "exportAppointments"){
	include( "acuityscheduling/tpl/preferences/expertAppointments.php" );
	die();
}
?>
<?php include("acuityscheduling/preferences.php"); ?>