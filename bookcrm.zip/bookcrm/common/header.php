<?php
include("core/config.php");
require_once("core/DB_Connection.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    </head>
<body class="no-touch   theme-blue has-transforms">
