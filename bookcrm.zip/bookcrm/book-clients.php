<?php
$ajax = isset($_REQUEST["ajax"]) ? $_REQUEST["ajax"] : "";
$action = isset($_REQUEST["action"]) ? $_REQUEST["action"] : "";
if (($ajax == "1") || ($action == 'delete')){
	require_once("core/DB_Connection.php");
	require_once("core/functions.php");
	include ("acuityscheduling/clients-action.php");
	die();
}
require_once("common/header.php");
?>

<?php include("acuityscheduling/clients.php"); ?>

<?php

require_once('common/footer.php');

?>
