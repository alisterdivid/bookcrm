<?php
if(isset( $_POST['month'])) {
    $requestDate = $_POST['month'];
    if ($requestDate == 'today') {
        $requestDate = date('Y-m-d');
    }

    $dateArray = explode('-', $requestDate);
    $_GET['year'] = $dateArray[0];
    $_GET['month'] = $dateArray[1];
}
?>
<table class="calendarHeading">
    <tr>
        <?php
            $calendar = new PTScheduleCalendar();
            echo $calendar->calendarHeading();
        ?>
    </tr>
</table>
<style>
    tr.calLable{
        background: white;
    }
</style>
<?php
 echo $calendar->show();
 ?>