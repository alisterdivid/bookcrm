<?php

$minDay = isset($_POST["minDay"]) ? $_POST["minDay"] : false;
$maxDay = isset($_POST["maxDay"]) ? $_POST["maxDay"] : false;
$expertor = new PTBookExpert();

$expertor->setMaxMinDates($minDay, $maxDay);
$apList = $expertor->getExpertAppointments();
PT_array_to_csv($apList, "schedule".date("Y-m-d").".csv", true);

