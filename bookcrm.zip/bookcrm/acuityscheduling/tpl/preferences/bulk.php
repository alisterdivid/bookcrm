<?php
$expertor = new PTBookExpert();

if (isset($_REQUEST["include-clients"]) && $_REQUEST["include-clients"]){
	$inDays = $_REQUEST["include-clients"];
	$expertor->setInDays($inDays);
	$clList = $expertor->getExpertClients();
	PT_array_to_csv($clList, "list.csv", true);
}
