
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,t,n){function r(n){if(!t[n]){var o=t[n]={exports:{}};e[n][0].call(o.exports,function(t){var o=e[n][1][t];return r(o||t)},o,o.exports)}return t[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<n.length;o++)r(n[o]);return r}({1:[function(e,t,n){function r(){}function o(e,t,n){return function(){return i(e,[f.now()].concat(u(arguments)),t?null:this,n),t?void 0:this}}var i=e("handle"),a=e(2),u=e(3),c=e("ee").get("tracer"),f=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],d="api-",l=d+"ixn-";a(p,function(e,t){s[t]=o(d+t,!0,"api")}),s.addPageAction=o(d+"addPageAction",!0),s.setCurrentRouteName=o(d+"routeName",!0),t.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,t){var n={},r=this,o="function"==typeof t;return i(l+"tracer",[f.now(),e,n],r),function(){if(c.emit((o?"":"no-")+"fn-start",[f.now(),r,o],n),o)try{return t.apply(this,arguments)}catch(e){throw c.emit("fn-err",[arguments,this,e],n),e}finally{c.emit("fn-end",[f.now()],n)}}}};a("setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,t){m[t]=o(l+t)}),newrelic.noticeError=function(e){"string"==typeof e&&(e=new Error(e)),i("err",[e,f.now()])}},{}],2:[function(e,t,n){function r(e,t){var n=[],r="",i=0;for(r in e)o.call(e,r)&&(n[i]=t(r,e[r]),i+=1);return n}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],3:[function(e,t,n){function r(e,t,n){t||(t=0),"undefined"==typeof n&&(n=e?e.length:0);for(var r=-1,o=n-t||0,i=Array(o<0?0:o);++r<o;)i[r]=e[t+r];return i}t.exports=r},{}],4:[function(e,t,n){t.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,t,n){function r(){}function o(e){function t(e){return e&&e instanceof r?e:e?c(e,u,i):i()}function n(n,r,o,i){if(!d.aborted||i){e&&e(n,r,o);for(var a=t(o),u=m(n),c=u.length,f=0;f<c;f++)u[f].apply(a,r);var p=s[y[n]];return p&&p.push([b,n,r,a]),a}}function l(e,t){v[e]=m(e).concat(t)}function m(e){return v[e]||[]}function w(e){return p[e]=p[e]||o(n)}function g(e,t){f(e,function(e,n){t=t||"feature",y[n]=t,t in s||(s[t]=[])})}var v={},y={},b={on:l,emit:n,get:w,listeners:m,context:t,buffer:g,abort:a,aborted:!1};return b}function i(){return new r}function a(){(s.api||s.feature)&&(d.aborted=!0,s=d.backlog={})}var u="nr@context",c=e("gos"),f=e(2),s={},p={},d=t.exports=o();d.backlog=s},{}],gos:[function(e,t,n){function r(e,t,n){if(o.call(e,t))return e[t];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[t]=r,r}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],handle:[function(e,t,n){function r(e,t,n,r){o.buffer([e],r),o.emit(e,t,n)}var o=e("ee").get("handle");t.exports=r,r.ee=o},{}],id:[function(e,t,n){function r(e){var t=typeof e;return!e||"object"!==t&&"function"!==t?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");t.exports=r},{}],loader:[function(e,t,n){function r(){if(!x++){var e=h.info=NREUM.info,t=d.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&t))return s.abort();f(y,function(t,n){e[t]||(e[t]=n)}),c("mark",["onload",a()+h.offset],null,"api");var n=d.createElement("script");n.src="https://"+e.agent,t.parentNode.insertBefore(n,t)}}function o(){"complete"===d.readyState&&i()}function i(){c("mark",["domContent",a()+h.offset],null,"api")}function a(){return E.exists&&performance.now?Math.round(performance.now()):(u=Math.max((new Date).getTime(),u))-h.offset}var u=(new Date).getTime(),c=e("handle"),f=e(2),s=e("ee"),p=window,d=p.document,l="addEventListener",m="attachEvent",w=p.XMLHttpRequest,g=w&&w.prototype;NREUM.o={ST:setTimeout,SI:p.setImmediate,CT:clearTimeout,XHR:w,REQ:p.Request,EV:p.Event,PR:p.Promise,MO:p.MutationObserver};var v=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1071.min.js"},b=w&&g&&g[l]&&!/CriOS/.test(navigator.userAgent),h=t.exports={offset:u,now:a,origin:v,features:{},xhrWrappable:b};e(1),d[l]?(d[l]("DOMContentLoaded",i,!1),p[l]("load",r,!1)):(d[m]("onreadystatechange",o),p[m]("onload",r)),c("mark",["firstbyte",u],null,"api");var x=0,E=e(4)},{}]},{},["loader"]);</script>
	<title>Import/Export</title>
	<meta name="viewport" content="initial-scale=1, maximum-scale=1.0">
	<link href="acuityscheduling/responsive/css/all.min-875.css" rel="stylesheet">
	<link rel="shortcut icon" href="/favicon.ico" />
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-title" content="Acuity Scheduling">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="theme-color" content="#efefef">
	<meta name="msapplication-navbutton-color" content="#efefef">
	<meta name="apple-mobile-web-app-status-bar-style" content="#efefef">
	<meta name="csrf-token" content="empldVNVbjVTWjBvMnZ2aWoweGYwRG9kMUp1Sjk0TmVJTFYzc3c5VVB4Zz06eyJ1IjoxNTAzNjY1MSwieCI6MTUxOTYyMTczNSwibiI6IjBmOWE3MGVmIn0=">

	<link href="img/apple-touch-icon-57x57.png" sizes="57x57" rel="apple-touch-icon">
	<link href="img/apple-touch-icon-114x114.png" sizes="114x114" rel="apple-touch-icon">
	<link href="img/apple-touch-icon-144x144.png" sizes="144x144" rel="apple-touch-icon">
	<link href="img/apple-touch-icon-180x180.png" sizes="144x144" rel="apple-touch-icon">
	<link href="img/apple-touch-icon-120x120.png" sizes="120x120" rel="apple-touch-icon">
	<link href="img/apple-touch-icon-152x152.png" sizes="152x152" rel="apple-touch-icon">
	<link href="img/apple-touch-icon-76x76.png" sizes="76x76" rel="apple-touch-icon">

	<link rel="manifest" href="manifest.json">

	<link rel="apple-touch-startup-image" href="img/startup_screen-320x460.png" />
	<link rel="apple-touch-startup-image" media="(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2)" href="img/startup_screen-640x1096.png">
	<link rel="apple-touch-startup-image" media="(device-width: 1024px) and (device-height: 768px)" href="img/startup_screen-1024x768.png" />
	<link rel="apple-touch-startup-image" media="(device-width: 1136px) and (device-height: 640px)" href="img/startup_screen-1136x640.png" />
	<link rel="apple-touch-startup-image" media="(device-width: 768px) and (device-height: 1024px) and (-webkit-device-pixel-ratio: 2)" href="img/startup_screen-1536x2048.png" />
	<link rel="apple-touch-startup-image" media="(device-width: 1024px) and (device-height: 748px) and (-webkit-device-pixel-ratio: 2)" href="img/startup_screen-2048x1536.png" />
	<link rel="apple-touch-startup-image" media="(device-width: 320px) and (device-height: 460px)" href="img/startup_screen-320x460.png" />
	<link rel="apple-touch-startup-image" media="(device-width: 320px) and (device-height: 480px)" href="img/startup_screen-320x480.png" />
	<link rel="apple-touch-startup-image" media="(device-width: 480px) and (device-height: 320px)" href="img/startup_screen-480x320.png" />
	<link rel="apple-touch-startup-image" media="(device-width: 640px) and (device-height: 1136px)" href="img/startup_screen-640x1136.png" />
	<link rel="apple-touch-startup-image" media="(device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2)" href="img/startup_screen-640x960.png" />
	<link rel="apple-touch-startup-image" media="(device-width: 768px) and (device-height: 1004px)" href="img/startup_screen-768x1024.png" />
	<link rel="apple-touch-startup-image" media="(device-width: 480px) and (device-height: 320px) and (-webkit-device-pixel-ratio: 2)" href="img/startup_screen-960x640.png" />

	<link href="img/startup_screen-640x1096.png" media="(device-width: 375px) and (device-height: 667px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
	<link href="img/startup_screen-768x1024.png" media="(device-width: 414px) and (device-height: 736px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 3)" rel="apple-touch-startup-image">
	<link href="img/startup_screen-1024x768.png" media="(device-width: 414px) and (device-height: 736px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 3)" rel="apple-touch-startup-image">

	<style>html { display:none; }</style><script>if (self === top) { document.documentElement.style.display = 'block'; } else { top.location = self.location; }</script>

	<script type="text/javascript">
		window.ErrorTrack = [];
		window.ErrorTrack['try'] = function(fn) {
			try {
				fn();
			} catch(er) {
				if (typeof window.trackJs!='undefined') window.trackJs.track(er);
				throw er;
			}
		};
		window.Acuity = [];
		window.Acuity.wrap = function (fn) {
			return function (arg) {
				ErrorTrack['try'](function () { fn(arg); } ); };
		};
	</script>

    <style>
        #footer li.acuity-logo {
            height: 80px;
        }
    </style>
</head>
<body class="no-touch   theme-blue">
<div class="container fast-animated main-nav-display sticky-main-nav-display" id="container-wrapper">

	<div class="pull-right help-top-container">
		<script type="text/javascript">
			justCompletedSetupStep = '';
		</script>
		<div class="global-search-container hidden-print">
			<form action="" method="POST">
				<div class="search-group">
					<input type="text" class="form-control" name="search" autocomplete="off" spellcheck="off" placeholder="Search...">
					<span class="search-icon-addon"><i class="icon-search"></i></span>
				</div>
			</form>

			<div class="global-search-results hidden"></div>
		</div>
    </div>

	<div class="main-nav-container hide-sm-nav  getting-started-not-showing">
		<button type="button" class="btn btn-sm btn-info toggle-main-nav">
			<i class="icon-align-justify" aria-hidden="true" title="Menu"></i>
		</button>
		<div class="nav menu-nav main-nav left-main-nav">
            <div id="monthly-calendar">
				<?php
				if(isset( $_GET['day'])) {
					$requestDate = $_GET['day'];
					if ($requestDate == 'today') {
						$requestDate = date('Y-m-d');
					}
					$dateArray = explode('-', $requestDate);
					$_GET['year'] = $dateArray[0];
					$_GET['month'] = $dateArray[1];
				}
				$topCalendar = new PTtopCalendar();
				echo $topCalendar->calendarHeading();
				echo $topCalendar->show();
				?>
            </div>
			<ul>
				<li class="current-nav">
					<a href=book-appointments.php?rs=1" class="nav-with-children">
						<span class="icon-appointments"></span> Appointments
					</a>
					<ul>
						<li ><a href=book-appointments.php?rs=1">Appointment Calendar</a></li>
						<li ><a href="book-clients.php">Client List</a></li>
						<li ><a href="book-reports.php">Reports</a></li>
						<li class="current-nav"><a href="book-preferences.php?action=importexport">Import/Export</a></li>
					</ul>
				</li>
				<li>
                    <a href="#" class="nav-with-children">
                        <span class="icon-csp"></span> Client's Scheduling Page
                    </a>
				</li>
				<li >
					<a href="#" class="nav-with-children">
						<span class="icon-settings"></span> Business Settings
					</a>
				</li>
			</ul>
			<div id="footer">
				<div class="wrap">
					<ul class="nav-footer">
						<li class="">
							<a href="book-preferences.php?action=myaccount"><span class="nav-item-name">My Account</span> <small>softensoftwares@gmail.com</small></a>
						</li>

						<li><a href="logout.php" data-toggle="tooltip" data-placement="top" title="Stay out of trouble"><span class="nav-item-name">Log Out</span></a></li>

						<li class="acuity-logo"><img src="acuityscheduling/img/logo-1.png" alt="Pickering Toyota Book CRM" height="52" width="172"></li>
					</ul>
				</div>
			</div>
		</div>        
    </div>
	<div class="row preferences-container">

		<div class="content default">

			<h1 class="page-title">
				Import/Export
			</h1>


			<div class="pane error-flash alert alert-danger" style="display:none"></div>
			<div class="content-module-full">
				<h4>Export</h4>
				<a href="#" target="_blank" class="btn btn-inverse btn-bordered btn-md btn-client-export margin-right margin-bottom"><i class="icon-download-alt"></i>  Export Client List to Excel</a>

				<a href="#" class="custom-export-form-btn btn btn-inverse btn-bordered btn-md margin-right margin-bottom"><i class="icon-download-alt"></i>  Export Appointments &amp; Forms to Excel </a>

				<div class="custom-export-form well" style="display:none; width: 85%;">
					<form action="book-preferences.php?action=exportAppointments" method="POST" class="form-horizontal">
						Date from <input type="text" class="form-control inline-field" placeholder="YYYY-MM-DD" id="minDay" name="minDay" value="" /> to <input type="text" class="form-control inline-field" placeholder="YYYY-MM-DD" id="maxDay" name="maxDay" value="" /> <span class="hide-if-placeholder text-muted">(date format is YYYY-MM-DD, example: 2015-11-21)</span>  <br />
						<div class="checkbox">
							<label><input type="checkbox" name="includeCanceled" value="1" /> Include canceled appointments</label>
						</div>
						<input type="submit" class="btn btn-default margin-top" value="Export Appointments to Excel" />
					</form>
				</div>


				<div class="custom-client-export-form well" style="display:none; width: 85%;">
					<form action="book-preferences.php?action=bulk&op=exportExcelAll" method="POST">
						<div class="form-group">
							<label class="control-label">Export </label>
							<div class="">
								<select name="include-clients" class="form-control" style="width: 50%;">
									<option value="all">All clients</option>
									<optgroup label="Old clients whose last appointment was...">
                                        <option value="14">More than 2 weeks ago</option>
                                        <option value="30">More than 30 days ago</option>
                                        <option value="90">More than 3 months ago</option>
                                        <option value="180">More than 6 months ago</option>
                                        <option value="canceled">Canceled</option>
									</optgroup>
									<optgroup label="Recent clients whose last appointment was...">
										<option value="-90">Within the past 3 months</option>
										<option value="-180">Within the past 6 months</option>
										<option value="-365">Within the past 1 year</option>
										<option value="-730">Within the past 2 years</option>
										<option value="-1095">Within the past 3 years</option>
										<option value="-1460">Within the past 4 years</option>
									</optgroup>
								</select>
							</div>
						</div>
						<input type="submit" class="btn btn-default" value="Export Clients to Excel" />
					</form>
				</div>
			</div>
		</div>
	</div>


</div>

<script type="text/javascript">
	window._trackJs = {
		token: "fbe49d5762cf4560847a05563bd04720",
		application: "admin",
		enabled: !(window.location.host.indexOf('127.0.0.1') >= 0),
		onError: function (payload, error) {
			var ignore = [/olark/, /ssl\.google-analytics/, /events\.olark\.com/, /assets\.customer\.io/, /error - getDetails/, /Error loading script/, /onContainerTouchMove/, /onContainerTouchStart/, /\[object Event\]/, /setHintValue/, /Type mismatch/, /Error calling method on NPObject/, /Out of memory/, /Argumento o llamada a procedimiento/, /__gCrWeb/, /undefined.*updatedAt/, /t is undefined/, /updatedAt.*undefined/, /Unspecified error/, /Redactor/];
			for (var i=0; i<ignore.length; i++) {
				if (ignore[i].test(payload.message)) return false;
			}

			return true;
		}
	};
</script>



<script>
	(function(d) {
		var config = {
				kitId: 'tvj8amu',
				scriptTimeout: 3000,
				async: true
			},
			h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
	})(document);
</script>


<!--[if lt IE 9]>
<script src="acuityscheduling/responsive/js/respond.min.js"></script>
<script src="acuityscheduling/js/tiny_mce/tiny_mce.js"></script>
<![endif]-->
<script type="text/javascript">
	window.CURRENT_VERSION=875;
	window.USERID='15036651';
	window.CLIENT_PAGE='https://app.acuityscheduling.com/schedule.php?owner=15036651';

</script>
<script type="text/javascript" src="acuityscheduling/responsive/js/all.min-875.js"></script>

<script type="text/javascript">if (typeof window.trackJs != 'undefined') window.trackJs.configure({userId: window.USERID});</script>



<script type="text/javascript">
	if (typeof _cio == 'undefined') {
		var _cio = _cio || [];
		(function() {
			var a,b,c;a=function(f){return function(){_cio.push([f].
			concat(Array.prototype.slice.call(arguments,0)))}};b=["load","identify",
				"sidentify","track","page"];for(c=0;c<b.length;c++){_cio[b[c]]=a(b[c])};
			var t = document.createElement('script'),
				s = document.getElementsByTagName('script')[0];
			t.async = true;
			t.id    = 'cio-tracker';
			t.setAttribute('data-site-id', '265a473ee947bb20fbb1');
			t.src = 'https://assets.customer.io/assets/track.js';
			s.parentNode.insertBefore(t, s);
		})();
	}
</script>

<script type="text/javascript">
	if (typeof amplitude == 'undefined') {
		(function(e,t){var n=e.amplitude||{_q:[],_iq:{}};var r=t.createElement("script");r.type="text/javascript";
			r.async=true;r.src="acuityscheduling/libs/amplitude-3.4.0-min.gz.js";
			r.onload=function(){e.amplitude.runQueuedFunctions()};var i=t.getElementsByTagName("script")[0];
			i.parentNode.insertBefore(r,i);function s(e,t){e.prototype[t]=function(){this._q.push([t].concat(Array.prototype.slice.call(arguments,0)));
				return this}}var o=function(){this._q=[];return this};var a=["add","append","clearAll","prepend","set","setOnce","unset"];
			for(var u=0;u<a.length;u++){s(o,a[u])}n.Identify=o;var c=function(){this._q=[];return this;
			};var p=["setProductId","setQuantity","setPrice","setRevenueType","setEventProperties"];
			for(var l=0;l<p.length;l++){s(c,p[l])}n.Revenue=c;var d=["init","logEvent","logRevenue","setUserId","setUserProperties","setOptOut","setVersionName","setDomain","setDeviceId","setGlobalUserProperties","identify","clearUserProperties","setGroup","logRevenueV2","regenerateDeviceId","logEventWithTimestamp","logEventWithGroups"];
			function v(e){function t(t){e[t]=function(){e._q.push([t].concat(Array.prototype.slice.call(arguments,0)));
			}}for(var n=0;n<d.length;n++){t(d[n])}}v(n);n.getInstance=function(e){e=(!e||e.length===0?"$default_instance":e).toLowerCase();
				if(!n._iq.hasOwnProperty(e)){n._iq[e]={_q:[]};v(n._iq[e])}return n._iq[e]};e.amplitude=n;
		})(window,document);
	}
	amplitude.getInstance().init("5bf377fa898a63e32d803ce376dbf310", '15036651', {includeUtm: true, includeReferrer: true});
</script>

<script src="https://apis.google.com/js/platform.js?onload=renderOptIn" async defer></script>
<script type="text/javascript">


	var u = {
		id: '15036651',
		email: 'softensoftwares@gmail.com',
		'$email': 'softensoftwares@gmail.com',
		created_at: 1516802400,
		business_name: 'uniqks',
		'$first_name': 'uniqks',
		keyword: 'Capterra',
		plan: 'Free',
		schedulingURL: 'https://app.acuityscheduling.com/schedule.php?owner=15036651',
		days_since_created: 29.631203703704,
		date_expired: 1518066000,


		source: 't'

	};

	_cio.identify(u);

	u['$created'] = u.created_at;


	amplitude.getInstance().setUserProperties({
		plan: u.plan,
		created_at: u.created_at,
		days_since_created: u.days_since_created,
		source: u.keyword
	});


	//begin Wootric code

	window.wootricSettings = {
		email: u.email,
		external_id: u.id,
		created_at: u.created_at,
		account_token: 'NPS-c8ffa412'
	};
</script>

<script type="text/javascript" src="https://disutgh7q0ncc.cloudfront.net/beacon.js"></script>
<script type="text/javascript">
	// This loads the Wootric survey
	if (typeof window.wootric === 'function') window.wootric('run');
</script>
<!-- end Wootric code -->

<script type="text/javascript">


	window['_fs_debug'] = false;
	window['_fs_host'] = 'www.fullstory.com';
	window['_fs_org'] = 'BdR';
	(function(m,n,e,t,l,o,g,y){
		g=m[e]=function(a,b){g.q?g.q.push([a,b]):g._api(a,b);};g.q=[];
		o=n.createElement(t);o.async=1;o.src='https://'+_fs_host+'/s/fs.js';
		y=n.getElementsByTagName(t)[0];y.parentNode.insertBefore(o,y);
		g.identify=function(i,v){g(l,{uid:i});if(v)g(l,v)};g.setUserVars=function(v){FS(l,v)};
		g.setSessionVars=function(v){FS('session',v)};g.setPageVars=function(v){FS('page',v)};
	})(window,document,'FS','script','user');

	FS.identify('15036651', {
		email: 'softensoftwares@gmail.com',
		displayName: u.business_name
	});



</script>


<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	ga('create', 'UA-1071942-1', 'auto');
	ga('send', 'pageview');

</script>
<script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"5649288"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script><noscript><img src="//bat.bing.com/action/0?ti=5649288&Ver=2" height="0" width="0" style="display:none; visibility: hidden;" /></noscript>
<!-- Facebook Pixel Code -->
<script>
	!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
		n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
		n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
		t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
		document,'script','https://connect.facebook.net/en_US/fbevents.js');
	fbq('set', 'autoConfig', 'false', '1210643745657267');
	fbq('init', '1210643745657267'); // Insert your pixel ID here.
	fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
               src="https://www.facebook.com/tr?id=1210643745657267&ev=PageView&noscript=1"
	/></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->







<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"e7043daa18","applicationID":"11269421","transactionName":"ZlQBZxYHXBACUhcMXl8eIEYXEl0OTEERAFdUQwZdBwNBTRNZE0pYXEEMQRADShMMQxc=","queueTime":0,"applicationTime":60,"atts":"ShMWEV4dT09BUEFfSkxM","errorBeacon":"bam.nr-data.net","agent":""}</script></body>
</html>


<script type="text/javascript">
	$('#container-wrapper').removeClass('calendar-container-wrapper');</script>

<script type="text/javascript">track('feature/importexport', {age:29.631203703704});</script>
