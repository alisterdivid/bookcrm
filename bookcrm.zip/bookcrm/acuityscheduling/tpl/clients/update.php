<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 3/2/2018
 * Time: 3:27 PM
 */

    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $notes = $_POST['notes'];
    $clientId = $_REQUEST['clientId'];
    $backto = $_REQUEST['backto'];

    if(isset($_POST['firstName']) || isset($_POST['lastName'])) {

            $sql = "UPDATE tbl_book_clients SET 
                         firstName = '" . $firstName . "',
                         lastName = '" . $lastName . "',
                         phone = '" . $phone . "',
                         email = '" . $email . "',
                         notes = '" . $notes . "'                         
                    WHERE id = '".$clientId."'";
            $db->query($sql);

    }


    header('Location: '.'book-clients.php?action=detail&firstName='.$firstName.'&lastName='.$lastName.'&phone='.$phone.'&backto='.$backto.'&ajax=1', true, 302);

    exit;