<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 3/1/2018
 * Time: 7:13 PM
 */
$backId = $_REQUEST['backto'];
$firstName = $_REQUEST['firstName'];
$lastName = $_REQUEST['lastName'];

$sql = "SELECT clients.id AS clientID, clients.firstName AS lf_first_name , clients.lastName AS lf_last_name ,
                   clients.phone AS phone , clients.email AS email, clients.notes AS clientNotes,
                   clients.intake AS intake
               FROM tbl_book_clients AS clients   
               WHERE  clients.firstName = '$firstName' AND clients.lastName = '$lastName'"; 
//$sql = "select * from leads WHERE id = '$backId'";
$leadList = $db->queryArray($sql);
$curLead = $leadList[0];
?>
<head>
    <script type="text/javascript">
        window.NREUM || (NREUM = {}), __nr_require = function (e, t, n) {
            function r(n) {
                if (!t[n]) {
                    var o = t[n] = {exports: {}};
                    e[n][0].call(o.exports, function (t) {
                        var o = e[n][1][t];
                        return r(o || t)
                    }, o, o.exports)
                }
                return t[n].exports
            }

            if ("function" == typeof __nr_require) return __nr_require;
            for (var o = 0; o < n.length; o++) r(n[o]);
            return r
        }({
            1: [function (e, t, n) {
                function r() {
                }

                function o(e, t, n) {
                    return function () {
                        return i(e, [f.now()].concat(u(arguments)), t ? null : this, n), t ? void 0 : this
                    }
                }

                var i = e("handle"), a = e(2), u = e(3), c = e("ee").get("tracer"), f = e("loader"), s = NREUM;
                "undefined" == typeof window.newrelic && (newrelic = s);
                var p = ["setPageViewName", "setCustomAttribute", "setErrorHandler", "finished", "addToTrace", "inlineHit", "addRelease"],
                    d = "api-", l = d + "ixn-";
                a(p, function (e, t) {
                    s[t] = o(d + t, !0, "api")
                }), s.addPageAction = o(d + "addPageAction", !0), s.setCurrentRouteName = o(d + "routeName", !0), t.exports = newrelic, s.interaction = function () {
                    return (new r).get()
                };
                var m = r.prototype = {
                    createTracer: function (e, t) {
                        var n = {}, r = this, o = "function" == typeof t;
                        return i(l + "tracer", [f.now(), e, n], r), function () {
                            if (c.emit((o ? "" : "no-") + "fn-start", [f.now(), r, o], n), o) try {
                                return t.apply(this, arguments)
                            } catch (e) {
                                throw c.emit("fn-err", [arguments, this, e], n), e
                            } finally {
                                c.emit("fn-end", [f.now()], n)
                            }
                        }
                    }
                };
                a("setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","), function (e, t) {
                    m[t] = o(l + t)
                }), newrelic.noticeError = function (e) {
                    "string" == typeof e && (e = new Error(e)), i("err", [e, f.now()])
                }
            }, {}], 2: [function (e, t, n) {
                function r(e, t) {
                    var n = [], r = "", i = 0;
                    for (r in e) o.call(e, r) && (n[i] = t(r, e[r]), i += 1);
                    return n
                }

                var o = Object.prototype.hasOwnProperty;
                t.exports = r
            }, {}], 3: [function (e, t, n) {
                function r(e, t, n) {
                    t || (t = 0), "undefined" == typeof n && (n = e ? e.length : 0);
                    for (var r = -1, o = n - t || 0, i = Array(o < 0 ? 0 : o); ++r < o;) i[r] = e[t + r];
                    return i
                }

                t.exports = r
            }, {}], 4: [function (e, t, n) {
                t.exports = {exists: "undefined" != typeof window.performance && window.performance.timing && "undefined" != typeof window.performance.timing.navigationStart}
            }, {}], ee: [function (e, t, n) {
                function r() {
                }

                function o(e) {
                    function t(e) {
                        return e && e instanceof r ? e : e ? c(e, u, i) : i()
                    }

                    function n(n, r, o, i) {
                        if (!d.aborted || i) {
                            e && e(n, r, o);
                            for (var a = t(o), u = m(n), c = u.length, f = 0; f < c; f++) u[f].apply(a, r);
                            var p = s[y[n]];
                            return p && p.push([b, n, r, a]), a
                        }
                    }

                    function l(e, t) {
                        v[e] = m(e).concat(t)
                    }

                    function m(e) {
                        return v[e] || []
                    }

                    function w(e) {
                        return p[e] = p[e] || o(n)
                    }

                    function g(e, t) {
                        f(e, function (e, n) {
                            t = t || "feature", y[n] = t, t in s || (s[t] = [])
                        })
                    }

                    var v = {}, y = {},
                        b = {on: l, emit: n, get: w, listeners: m, context: t, buffer: g, abort: a, aborted: !1};
                    return b
                }

                function i() {
                    return new r
                }

                function a() {
                    (s.api || s.feature) && (d.aborted = !0, s = d.backlog = {})
                }

                var u = "nr@context", c = e("gos"), f = e(2), s = {}, p = {}, d = t.exports = o();
                d.backlog = s
            }, {}], gos: [function (e, t, n) {
                function r(e, t, n) {
                    if (o.call(e, t)) return e[t];
                    var r = n();
                    if (Object.defineProperty && Object.keys) try {
                        return Object.defineProperty(e, t, {value: r, writable: !0, enumerable: !1}), r
                    } catch (i) {
                    }
                    return e[t] = r, r
                }

                var o = Object.prototype.hasOwnProperty;
                t.exports = r
            }, {}], handle: [function (e, t, n) {
                function r(e, t, n, r) {
                    o.buffer([e], r), o.emit(e, t, n)
                }

                var o = e("ee").get("handle");
                t.exports = r, r.ee = o
            }, {}], id: [function (e, t, n) {
                function r(e) {
                    var t = typeof e;
                    return !e || "object" !== t && "function" !== t ? -1 : e === window ? 0 : a(e, i, function () {
                        return o++
                    })
                }

                var o = 1, i = "nr@id", a = e("gos");
                t.exports = r
            }, {}], loader: [function (e, t, n) {
                function r() {
                    if (!x++) {
                        var e = h.info = NREUM.info, t = d.getElementsByTagName("script")[0];
                        if (setTimeout(s.abort, 3e4), !(e && e.licenseKey && e.applicationID && t)) return s.abort();
                        f(y, function (t, n) {
                            e[t] || (e[t] = n)
                        }), c("mark", ["onload", a() + h.offset], null, "api");
                        var n = d.createElement("script");
                        n.src = "https://" + e.agent, t.parentNode.insertBefore(n, t)
                    }
                }

                function o() {
                    "complete" === d.readyState && i()
                }

                function i() {
                    c("mark", ["domContent", a() + h.offset], null, "api")
                }

                function a() {
                    return E.exists && performance.now ? Math.round(performance.now()) : (u = Math.max((new Date).getTime(), u)) - h.offset
                }

                var u = (new Date).getTime(), c = e("handle"), f = e(2), s = e("ee"), p = window, d = p.document,
                    l = "addEventListener", m = "attachEvent", w = p.XMLHttpRequest, g = w && w.prototype;
                NREUM.o = {
                    ST: setTimeout,
                    SI: p.setImmediate,
                    CT: clearTimeout,
                    XHR: w,
                    REQ: p.Request,
                    EV: p.Event,
                    PR: p.Promise,
                    MO: p.MutationObserver
                };
                var v = "" + location, y = {
                        beacon: "bam.nr-data.net",
                        errorBeacon: "bam.nr-data.net",
                        agent: "js-agent.newrelic.com/nr-1071.min.js"
                    }, b = w && g && g[l] && !/CriOS/.test(navigator.userAgent),
                    h = t.exports = {offset: u, now: a, origin: v, features: {}, xhrWrappable: b};
                e(1), d[l] ? (d[l]("DOMContentLoaded", i, !1), p[l]("load", r, !1)) : (d[m]("onreadystatechange", o), p[m]("onload", r)), c("mark", ["firstbyte", u], null, "api");
                var x = 0, E = e(4)
            }, {}]
        }, {}, ["loader"]);</script>
    <title>Pcikering Toyota Scheduling</title>
</head>


<div class="pane error-flash alert alert-danger" style="display:none"></div>
<form autocomplete="off"
      action="book-clients.php?action=update&firstName=<?php  echo $curLead['lf_first_name'];?>&lastName=<?php  echo $curLead['lf_last_name'];?>&phone=<?php  echo $curLead['phone'];?>&backto=<?php  echo $curLead['id'];?>&clientId=<?php  echo $curLead['clientID'];?>&refresh=1"
      method="POST" id="client-details-page" class="form-inline form-hidden detail-nav-link" novalidate>
    <input type="hidden" name="__csrf_magic"
           value="SDZNRmJyR0d5SEJtMWZWV09TQkdNK1dOOW1BaG1hNkxjeEtDMzVXN0FRZz06eyJ1IjoxNTAzNjY1MSwieCI6MTUyMDE2MjA4OCwibiI6IjQ3YjFmYTdkIn0="/>
    <div class="content inverse client-details">
        <div class="hidden-print">
            <div class="pull-right btn-group btn-top hidden-print">
                <a href="book-appointments.php?action=new&firstName=<?php  echo $curLead['lf_first_name'];?>&lastName=<?php  echo $curLead['lf_last_name'];?>&phone=<?php  echo $curLead['phone'];?>&email=<?php  echo $curLead['email'];?>&timezone=America/New_York"
                   class="detail-nav-link btn btn-inverse"><i class="icon-time"></i> Schedule</a>
                <a href="#" class="btn btn-inverse edit-client"><i class="icon-pencil"></i> Edit</a>
                <a href="#" class="btn btn-inverse block-client-popover" data-container="body" data-toggle="popover"
                   data-placement="bottom" data-html="true"
                   data-content="<p>Are you sure you want to ban this client from scheduling appointments online?</p><form action='book-clients.php?action=block&firstName=<?php  echo $curLead['lf_first_name'];?>&lastName=<?php  echo $curLead['lf_last_name'];?>&phone=<?php  echo $curLead['phone'];?>&email=<?php  echo $curLead['email'];?>&__csrf_magic=SDZNRmJyR0d5SEJtMWZWV09TQkdNK1dOOW1BaG1hNkxjeEtDMzVXN0FRZz06eyJ1IjoxNTAzNjY1MSwieCI6MTUyMDE2MjA4OCwibiI6IjQ3YjFmYTdkIn0=' class='detail-nav-link' method='POST'><input type='hidden' name='is-valid' value='1' /><textarea name='message' class='form-control' placeholder='Enter a message to show to the client'></textarea><p><input type='submit' class='btn btn-primary btn-block' value='Ban Client' /></p></form>">
                    <i class="icon-minus-sign"></i> Ban
                </a>
                <a href="book-clients.php?action=detail&firstName=<?php  echo $curLead['lf_first_name'];?>&lastName=<?php  echo $curLead['lf_last_name'];?>&phone=<?php  echo $curLead['phone'];?>&print=1" target="_blank"
                   class="btn btn-inverse hidden-sm hidden-x print-client"><i class="icon-print"></i> Print</a>
                <button type="button" class="btn btn-inverse dropdown-toggle visible-xs visible-sm"
                        data-toggle="dropdown" title="Additional Settings">
                    <i class="icon-cog" aria-hidden="true" title="Additional Settings"></i> <span class="caret"></span>
                </button>
                <ul class="dropdown-menu" role="menu">
                    <li>
                        <a href="book-clients.php?action=detail&firstName=<?php  echo $curLead['lf_first_name'];?>&lastName=<?php  echo $curLead['lf_last_name'];?>&phone=<?php  echo $curLead['phone'];?>&print=1"
                           target="_blank" class="print-client"><i class="icon-print"></i> Print</a>
                    </li>
                    <li><a href="#"
                           data-confirm-prompt="Please type 'DELETE' to confirm. Deleting will permanently remove this client and all their appointments (14)."
                           data-confirm-double="DELETE"
                           data-confirm-href="book-clients.php?action=delete&firstName=<?php  echo $curLead['lf_first_name'];?>&lastName=<?php  echo $curLead['lf_last_name'];?>&phone=<?php  echo $curLead['phone'];?>&__csrf_magic=SDZNRmJyR0d5SEJtMWZWV09TQkdNK1dOOW1BaG1hNkxjeEtDMzVXN0FRZz06eyJ1IjoxNTAzNjY1MSwieCI6MTUyMDE2MjA4OCwibiI6IjQ3YjFmYTdkIn0="><i
                                    class="icon-trash text-danger"></i> Delete</a></li>
                </ul>

                <a href="#"
                   data-confirm-prompt="Please type 'DELETE' to confirm. Deleting will permanently remove this client and all their appointments (14)."
                   data-confirm-double="DELETE"
                   data-confirm-href="book-clients.php?action=delete&firstName=<?php  echo $curLead['lf_first_name'];?>&lastName=<?php  echo $curLead['lf_last_name'];?>&phone=<?php  echo $curLead['phone'];?>&__csrf_magic=SDZNRmJyR0d5SEJtMWZWV09TQkdNK1dOOW1BaG1hNkxjeEtDMzVXN0FRZz06eyJ1IjoxNTAzNjY1MSwieCI6MTUyMDE2MjA4OCwibiI6IjQ3YjFmYTdkIn0="
                   class="btn btn-delete hidden-sm hidden-xs"><i class="icon-trash"></i> Delete</a>
            </div>

            <a href="book-appointments.php?action=detail&id=<?php echo $curLead['id'];?>" class="btn btn-inverse btn-top detail-nav-link hidden-print"><i
                        class="icon-chevron-left"></i> Back</a>
        </div>


        <div class="row appt-heading client-name-heading">
            <div class="col-xs-12 client-name">
                <span class="field-rendered edit-client"><?php  echo $curLead['lf_first_name'];?> <?php  echo $curLead['lf_last_name'];?></span>
                <span class="field-input">
				<input type="text" name="firstName" class="form-control input-md" size="12" value="<?php  echo $curLead['lf_first_name'];?> "/>
				<input type="text" name="lastName" class="form-control input-md" value="<?php  echo $curLead['lf_last_name'];?>"/>
			</span>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3 row-label subhead-ac">
                Phone
            </div>
            <div class="col-sm-8">
                <span class="field-rendered"><a href="tel:<?php  echo $curLead['phone'];?>" class="real-link"><?php  echo $curLead['phone'];?></a></span>
                <span class="field-input">
				<input type="text" name="phone" class="form-control" size="25" value="<?php  echo $curLead['phone'];?>"/>
			</span>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3 row-label subhead-ac">
                E-mail
            </div>
            <div class="col-sm-8">
                <span class="field-rendered"><a href="mailto:<?php  echo $curLead['email'];?>" class="real-link"><?php  echo $curLead['email'];?></a></span>
                <span class="field-input">
				<input type="email" name="email" class="form-control" size="25" value="<?php  echo $curLead['email'];?>"/>
			</span>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
			<span class="field-input">
				<a href="#" class="btn btn-link pull-right cancel-client-edit">cancel</a>
				<input type="submit" class="btn btn-default" value="Save Changes"/>
			</span>
            </div>
        </div>
    </div>

    <div class="content client-extra-details">
        <h3>Notes about client</h3>
        <div class="form-field  show-on-hover-container">
		<span class="field-rendered edit-client edit-client-notes">
			<span class="body-italic-small">
                <?php
                    if(($curLead['clientNotes'] != null) && ($curLead['clientNotes'] != "")){
                        echo $curLead['clientNotes'];
                    }
                    else{
                        echo "No Client Notes";
                    }
                ?>

            </span>
			<a href="#" class="btn btn-inverse btn-bordered btn-xs show-on-hover margin-left"><i
                        class="icon-pencil"></i> Edit</a>
		</span>
            <span class="field-input">
			<textarea rows="5" class="form-control margin-top margin-bottom" style="width:100%" id="client-notes"
                      name="notes" placeholder="Private notes about client" maxlength="65535"><?php echo $curLead['clientNotes'];?> </textarea>
			<a href="#" class="btn btn-link pull-right cancel-client-edit">cancel</a>
			<input type="submit" class="btn btn-default" value="Save Changes"/>
		</span>
        </div>
    </div>
</form>

<div class="content client-extra-details">
    <h3>Intake Forms</h3>
    <div class="row">
        <div class="col-xs-12 form-field body-italic-small">
            No Intake Forms
        </div>
    </div>
</div>

<form id="bulk-cancel-form" class="form-hidden detail-nav-link"
      action="book-clients.php?action=bulkCancel&firstName=<?php echo $curLead['lf_first_name'];?>&lastName=<?php echo $curLead['lf_last_name'];?>&phone=<?php echo $curLead['phone'];?>" method="POST">
    <div class="content client-extra-details client-appt-history">
        <h3>
            Upcoming Appointments
            <?php
            $upcomingSql = "SELECT clients.id AS clientID, clients.firstName AS lf_first_name , clients.lastName AS lf_last_name ,
                                   clients.phone AS phone , clients.email AS email, clients.notes AS clientNotes,
                                   clients.intake AS intake, leads.id AS id ,leads.td_request_date AS td_request_date, 
                                   leads.td_request_time AS td_request_time, leads.rq_pack_id AS rq_pack_id,
                                   leads.rq_comments AS rq_comments ,tbl_service.service_name, leads.lead_type AS lead_type
                               FROM leads AS leads, tbl_book_clients AS clients   , tbl_service
                               WHERE leads.siteuser_id = clients.id AND tbl_service.id = leads.rq_pack_id  AND leads.service_type = 'service-department'
                                      AND clients.firstName = '$firstName' AND clients.lastName = '$lastName' AND leads.td_request_date > now()";
//            $upcomingSql = "SELECT leads.* ,tbl_service.service_name
//                                  FROM leads ,tbl_service
//                               WHERE  leads.rq_pack_id = tbl_service.id AND  leads.lf_first_name = '$firstName'
//                                  AND leads.lf_last_name = '$lastName' AND service_type = 'service-department' AND td_request_date > NOW()";
            $upcommingList = $db->queryArray($upcomingSql);
            echo  '( '.count($upcommingList).' )';

            $pastSql = "SELECT clients.id AS clientID, clients.firstName AS lf_first_name , clients.lastName AS lf_last_name ,
                                   clients.phone AS phone , clients.email AS email, clients.notes AS clientNotes,
                                   clients.intake AS intake, leads.id AS id ,leads.td_request_date AS td_request_date, 
                                   leads.td_request_time AS td_request_time, leads.rq_pack_id AS rq_pack_id,leads.lead_type AS lead_type,
                                   leads.rq_comments AS rq_comments ,tbl_service.service_name, leads.lead_type AS lead_type
                               FROM leads AS leads, tbl_book_clients AS clients   , tbl_service
                               WHERE leads.siteuser_id = clients.id AND tbl_service.id = leads.rq_pack_id  AND leads.service_type = 'service-department'
                                      AND clients.firstName = '$firstName' AND clients.lastName = '$lastName' AND leads.td_request_date < now()";
//            $pastSql = "SELECT leads.* ,tbl_service.service_name FROM leads ,tbl_service
//                                    WHERE  leads.rq_pack_id = tbl_service.id AND leads.lf_first_name = '$firstName'
//                                    AND leads.lf_last_name = '$lastName' AND service_type = 'service-department' AND td_request_date < NOW()";
            $pastList = $db->queryArray($pastSql);
            ?>
        </h3>
        <div class="row appt-details">
            <div class="col-xs-12 pad-top">
                <div class="pull-right">
                    <a class="btn btn-sm btn-primary" href="#"
                       data-confirm-href="book-clients.php?action=assignAll&toUser=<?php  echo $curLead['id'];?>&firstName=<?php  echo $curLead['lf_last_name'];?>&lastName=<?php  echo $curLead['lf_last_name'];?>&phone=<?php  echo $curLead['phone'];?>"
                       data-confirm-prompt="Are you sure you want to allow <?php  echo $curLead['email'];?> to view all upcoming and past <?php echo count($pastList)?> appointments?">
                        <i class="icon-user"></i> Assign all to client user (<?php  echo $curLead['email'];?>)</a>
                </div>
            </div>
        </div>
        <div class="row appt-details">
            <div class="col-xs-12 pad-top">
                <a href="#" class="small" id="check-all-appt">Check all</a>
                <div class="pull-right">
                    <a href="#" class="btn-bulk-reschedule btn btn-inverse btn-bordered" data-appointment-container="#bulk-cancel-form"
                       data-back-url="book-clients.php?action=detail&firstName=<?php echo $curLead['lf_first_name'];?>&lastName=<?php echo $curLead['lf_last_name'];?>&phone=<?php echo $curLead['phone'];?>">
                        Reschedule Selected
                    </a>
                    <a href="#" data-toggle="popover" data-container="#bulk-cancel-form" data-placement="bottom" data-html="true"
                       data-content="<p>Are you sure you want to cancel the selected appointments?</p><div class='form-group'><a href='#' id='cancel-add-note-bulk'>Include note in e-mail to client...</a></a></div><p><input type='submit' value='Yes, cancel appointments' class='btn btn-primary btn-block' /></p><p><input type='submit' name='no-email' value='Yes, but do not e-mail client' class='btn btn-primary btn-block' /></p><p><a href='#' class='btn btn-link btn-block btn-hide-popover'>No, I don't want to cancel these</a></p>"
                       disabled="disabled" id="cancel-appts-btn" class="btn btn-sm btn-danger">Cancel Selected</a>
                </div>
            </div>
        </div>
        <?php
        if($upcommingList != null){
            for($i = 0; $i < count($upcommingList); $i++){
                ?>
                <div class="calendar-appt <?php  if ($i == 0) echo 'first';?> ">
                    <div class="row appt-details" style="box-shadow: inset 5px 0 0 0 #F1EFBC;">
                        <div class="col-xs-12">
                            <span class="appt-datetime"><?php  echo date('l, F d, Y', strtotime($upcommingList[$i]['td_request_date']));?></span>
                            <span class="appt-duration">30 MIN</span>
                            <div class="pull-right is-paid">
                                <?php
                                if($upcommingList[$i]['lead_type']=='closing_lead'){
                                    echo '<span class="label label-danger">CANCELED</span>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>

                    <div class="row appt-heading" data-appointment-id="<?php echo $upcommingList[$i]['id'];?>" style="box-shadow: inset 5px 0 0 0 #F1EFBC;">
                        <div class="col-xs-12">
                              <?php
                                if($upcommingList[$i]['lead_type'] !='closing_lead') {
                                    ?>
                                    <input type="checkbox" name="appt[]" class="appt-checkbox"
                                           value="<?php echo $upcommingList[$i]['id']; ?>"/>
                                    <?php
                                }
                                    ?>
                            <a class="btn-link detail-nav-link appt-time margin-right"
                               href="book-appointments.php?action=detail&id=<?php echo $upcommingList[$i]['id'];?>?backto=l:0"><?php  echo $upcommingList[$i]['td_request_time'];?> </a>
                            <span class="appt-client-name">
                        <a class="btn-link detail-nav-link" href="book-appointments.php?action=detail&id=<?php  echo $upcommingList[$i]['id'];?>?backto=l:0"><?php  echo $upcommingList[$i]['lf_first_name'];?> <?php  echo $upcommingList[$i]['lf_last_name'];?></a>
					</span>
                        </div>
                    </div>

                    <div class="row appt-details" style="box-shadow: inset 5px 0 0 0 #F1EFBC;">
                        <div class="col-xs-12">
                            <?php echo $upcommingList[$i]['service_name']?>
                            FROM  <?php echo $upcommingList[$i]['td_request_time']?>-12:00PM
                            <br/>
                        </div>
                    </div>
                </div>
                <?php
            }
        }
        ?>

    </div>
    <div class="content client-extra-details client-appt-history">
        <h3>Past Appointments (<?php echo count($pastList)?>) </h3>

        <?php
        if($pastList != null){
            for($j = 0; $j< count($pastList); $j++){
                ?>
                <div class="calendar-appt first ">
                    <div class="row appt-details" style="box-shadow: inset 5px 0 0 0 #F1EFBC;">
                        <div class="col-xs-12">
                            <span class="appt-datetime"><?php  echo date('l, F d, Y', strtotime($pastList[$j]['td_request_date']));?></span>
                            <span class="appt-duration">30 MIN</span>

                            <div class="pull-right is-paid">
                                <?php
                                if($upcommingList[$j]['lead_type']=='closing_lead'){
                                    echo '<span class="label label-danger">CANCELED</span>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>

                    <div class="row appt-heading" data-appointment-id="<?php echo $pastList[$j]['id'];?>" style="box-shadow: inset 5px 0 0 0 #F1EFBC;">
                        <div class="col-xs-12">
                            <a class="btn-link detail-nav-link appt-time margin-right"
                               href="book-appointments.php?action=detail&id=<?php echo $pastList[$j]['id'];?>?backto=l:0"><?php echo $pastList[$j]['td_request_time'];?> </a>
                            <span class="appt-client-name">
                        <a class="btn-link detail-nav-link" href="book-appointments.php?action=detail&id=<?php echo $pastList[$j]['id'];?>?backto=l:0"><?php echo $pastList[$j]['lf_first_name'];?> <?php echo $pastList[$j]['lf_last_name'];?></a>
					</span>
                        </div>
                    </div>

                    <div class="row appt-details" style="box-shadow: inset 5px 0 0 0 #F1EFBC;">
                        <div class="col-xs-12">
                            <?php echo $pastList[$j]['service_name'];?>
                            FROM <?php echo $pastList[$j]['td_request_time'];?>-11:30AM
                            <br/>
                        </div>
                    </div>
                </div>

                <?php

            }
        }
        ?>
    </div>
</form>
<script type="text/javascript">
   <?php
    if(isset($_REQUEST['print'])){
   ?>
   $(function () {
       track('print');
       window.print();
   });
   <?php
   }
        ?>
</script>
