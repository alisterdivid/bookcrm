<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 3/1/2018
 * Time: 5:39 PM
 */


if(isset($_REQUEST['appt'])){
    $mIdArray = $_REQUEST['appt'];
    for($i = 0; $i<count($mIdArray); $i++) {
        $sql = "UPDATE leads SET lead_type= 'closing_lead' WHERE id = '".$mIdArray[$i]."'";
      $db->query($sql);
    }
}


$request_url='book-clients.php?action=detail&ajax=1&standalone=&firstName='.$_REQUEST['firstName'].'&lastName='.$_REQUEST['lastName'].'&phone=123'.$_REQUEST['phone'];

header('Location: '.$request_url, true, 302);
exit;
