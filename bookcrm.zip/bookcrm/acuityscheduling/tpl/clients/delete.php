<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 3/2/2018
 * Time: 2:37 PM
 */

$firstName = $_REQUEST['firstName'];
$lastName = $_REQUEST['lastName'];

$sql = "select id  from tbl_book_clients WHERE firstName = '$firstName' AND lastName = '$lastName'";
$clientsList = $db->queryArray($sql);
$delClientId = $clientsList[0]['id'];

$sql = "delete from tbl_book_clients WHERE id = '$delClientId'";
$db->query($sql);

$sql = "DELETE FROM leads WHERE siteuser_id = '$delClientId' AND service_type = 'service-department'";
$db->query($sql);

header('Location: book-clients.php', true, 302);
exit;

