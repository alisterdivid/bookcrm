<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 2/28/2018
 * Time: 7:39 PM
 */

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$serviceId = $_POST['appointmentType'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$notes = $_POST['notes'];

if(isset($_POST['firstName']) && isset($_POST['lastName'])) {
    $sql = "select id from tbl_book_clients WHERE firstName = '$firstName' AND lastName = '$lastName'";
    $confirmClients = $db->queryArray($sql);
    if($confirmClients != null){
        $clientId = $confirmClients[0]['id'];
        $sql = "UPDATE  tbl_book_clients 
                          SET firstName= '" . $firstName . "', 
                              lastName = '" . $lastName . "', 
                              email = '" . $email . "',
                              phone = '" . $phone . "', 
                              notes = '" . $notes . "', 
                              update_time = now()
                          where id = '$clientId'";
       $db->query($sql);
    }
    else {
        $sql = "INSERT INTO tbl_book_clients 
                          SET firstName= '" . $firstName . "', 
                              lastName = '" . $lastName . "', 
                              email = '" . $email . "',
                              phone = '" . $phone . "', 
                              notes = '" . $notes . "', 
                              update_time = now(),
                              create_time = now()"; echo $sql;
        $db_insert = $db->queryInsert($sql);

    }
}
$backUrl = "book-clients.php?action=detail&backto=clients&refresh=1&ajax=1&standalone=&firstName=".$firstName."&lastName=".$lastName."&phone=".$phone;
header('Location: ' . $backUrl, true, 302);
exit;