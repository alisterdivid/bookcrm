<div class="main-nav-container hide-sm-nav calendar-display getting-started-not-showing">
    <button type="button" class="btn btn-sm btn-info toggle-main-nav" initialized-contoller="true">
        <i class="icon-align-justify" aria-hidden="true" title="Menu"></i>
    </button>
    <div class="nav menu-nav main-nav condense-navigation">
        <a href="#" class="hide-main-menu visible-main-nav-showing hidden-xs hidden-sm" data-class="main-nav-display" data-container="body" data-toggle="tooltip" title="" data-placement="bottom" aria-label="Hide menu" data-original-title="Hide Left Menu"><i class="icon-align-justify" aria-hidden="true"></i></a>
        <a href="#" class="hide-main-menu visible-main-nav-not-showing hidden-xs hidden-sm" data-class="main-nav-display" data-container="body" data-toggle="tooltip" title="" data-placement="right" aria-label="Show menu" data-original-title="Show Menu"><i class="icon-align-justify" aria-hidden="true"></i></a>

<style>
    @media (min-width: 992px) {
        .calendar-display.main-nav-container {
            min-height: 820px;
        }
    }
</style>

        <div id="monthly-calendar">
            <?php
            if(isset( $_GET['day'])) {
                $requestDate = $_GET['day'];
                if ($requestDate == 'today') {
                    $requestDate = date('Y-m-d');
                }
                $dateArray = explode('-', $requestDate);
                $_GET['year'] = $dateArray[0];
                $_GET['month'] = $dateArray[1];
            }
            $topCalendar = new PTtopCalendar();
            echo $topCalendar->calendarHeading();
            echo $topCalendar->show();
            ?>
        </div>
        <ul>
            <li class="<?php if($selParentTitle == 'appointments'){ echo 'current-nav';}?> ">
                <a href="book-appointments.php?rs=1" class="nav-with-children">
                    <span class="icon-appointments"></span> Appointments
                </a>
                <ul>
                    <li class="<?php if($curpage == 'appointment'){ echo 'current-nav';}?>"><a href="book-appointments.php?rs=1">Appointment Calendar</a></li>
                    <li class="<?php if($curpage == 'clients'){ echo 'current-nav';}?>"><a href="book-clients.php">Client List</a></li>
                    <li class="<?php if($curpage == 'reports'){ echo 'current-nav';}?>"><a href="book-reports.php">Reports</a></li>
                    <li class="<?php if($curpage == 'preference'){ echo 'current-nav';}?>"><a href="book-preferences.php?action=importexport">Import/Export</a></li>
                </ul>
            </li>
            <li >
                <a href="#" class="nav-with-children">
                    <span class="icon-csp"></span> Client's Scheduling Page
                </a>
                <ul>
                    <li><a href="#">Scheduling Page Link</a></li>
                    <li><a href="#">Customize Appearance</a></li>
                    <li><a href="#">Advanced CSS</a></li>
                </ul>
            </li>
            <li>
                <a href="#" class="nav-with-children">
                    <span class="icon-settings"></span> Business Settings
                </a>
                <ul>
                    <li class="nav-first-item "><a href="#">Availability</a></li>

                    <li><a href="#">Appointment Types</a></li>
                    <li class="nav-separator "><a href="#">Intake Form Questions</a></li>
                    <li><a href="#">Packages &amp; <span class="hidden-smaller-width">Gift</span> Certificates</a></li>
                    <li><a href="#">Manage Users</a></li>
                    <li><a href="#">Integrations</a></li>
                    <li><a href="#">Sync with Other Calendars</a></li>
                    <li class=""><a href="#">Payment Settings</a></li>
                    <li class=""><a href="#">E-mail Settings</a></li>
                </ul>
            </li>
        </ul>
        <div id="footer">
            <div class="wrap">
                <ul class="nav-footer">
                    <li class="">
                        <a href="#"><span class="nav-item-name">My Account</span> <small>softensoftwares@gmail.com</small></a>
                    </li>

                    <li><a href="#" data-toggle="tooltip" data-placement="top" title="" data-original-title="Ciao for now!"><span class="nav-item-name">Log Out</span></a></li>

                    <li class="acuity-logo" style="height:80px;"><img src="acuityscheduling/img/logo-1.png" alt="Acuity Scheduling Logo" height="52" width="172"></li>
                </ul>
            </div>
        </div>
    </div>
</div>