<?php
//$sql = "INSERT INTO `pickeringtoyota_toyota`.`leads` (`lf_first_name`, `lf_last_name`, `lead_insert_date`, `service_type`, `td_request_date`, `td_request_time`) VALUES ('jang ', 'Test', '2018-02-26 11:59:48', 'service-department', '2018-02-12', '09:00')";
//$db->queryInsert($sql);
//$sql = "INSERT INTO `pickeringtoyota_toyota`.`leads` (`lf_first_name`, `lf_last_name`, `lead_insert_date`, `service_type`, `td_request_date`, `td_request_time`) VALUES ('Test', 'test2', '2018-02-22 12:01:18', 'service-department', '2018-02-12', '10:00'); ";
//$db->queryInsert($sql);
$sql = "select * from tbl_service";
$serviceList = $db->queryArray($sql);
?>
<head><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,t,n){function r(n){if(!t[n]){var o=t[n]={exports:{}};e[n][0].call(o.exports,function(t){var o=e[n][1][t];return r(o||t)},o,o.exports)}return t[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<n.length;o++)r(n[o]);return r}({1:[function(e,t,n){function r(){}function o(e,t,n){return function(){return i(e,[f.now()].concat(u(arguments)),t?null:this,n),t?void 0:this}}var i=e("handle"),a=e(2),u=e(3),c=e("ee").get("tracer"),f=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],d="api-",l=d+"ixn-";a(p,function(e,t){s[t]=o(d+t,!0,"api")}),s.addPageAction=o(d+"addPageAction",!0),s.setCurrentRouteName=o(d+"routeName",!0),t.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,t){var n={},r=this,o="function"==typeof t;return i(l+"tracer",[f.now(),e,n],r),function(){if(c.emit((o?"":"no-")+"fn-start",[f.now(),r,o],n),o)try{return t.apply(this,arguments)}catch(e){throw c.emit("fn-err",[arguments,this,e],n),e}finally{c.emit("fn-end",[f.now()],n)}}}};a("setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,t){m[t]=o(l+t)}),newrelic.noticeError=function(e){"string"==typeof e&&(e=new Error(e)),i("err",[e,f.now()])}},{}],2:[function(e,t,n){function r(e,t){var n=[],r="",i=0;for(r in e)o.call(e,r)&&(n[i]=t(r,e[r]),i+=1);return n}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],3:[function(e,t,n){function r(e,t,n){t||(t=0),"undefined"==typeof n&&(n=e?e.length:0);for(var r=-1,o=n-t||0,i=Array(o<0?0:o);++r<o;)i[r]=e[t+r];return i}t.exports=r},{}],4:[function(e,t,n){t.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,t,n){function r(){}function o(e){function t(e){return e&&e instanceof r?e:e?c(e,u,i):i()}function n(n,r,o,i){if(!d.aborted||i){e&&e(n,r,o);for(var a=t(o),u=m(n),c=u.length,f=0;f<c;f++)u[f].apply(a,r);var p=s[y[n]];return p&&p.push([b,n,r,a]),a}}function l(e,t){v[e]=m(e).concat(t)}function m(e){return v[e]||[]}function w(e){return p[e]=p[e]||o(n)}function g(e,t){f(e,function(e,n){t=t||"feature",y[n]=t,t in s||(s[t]=[])})}var v={},y={},b={on:l,emit:n,get:w,listeners:m,context:t,buffer:g,abort:a,aborted:!1};return b}function i(){return new r}function a(){(s.api||s.feature)&&(d.aborted=!0,s=d.backlog={})}var u="nr@context",c=e("gos"),f=e(2),s={},p={},d=t.exports=o();d.backlog=s},{}],gos:[function(e,t,n){function r(e,t,n){if(o.call(e,t))return e[t];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[t]=r,r}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],handle:[function(e,t,n){function r(e,t,n,r){o.buffer([e],r),o.emit(e,t,n)}var o=e("ee").get("handle");t.exports=r,r.ee=o},{}],id:[function(e,t,n){function r(e){var t=typeof e;return!e||"object"!==t&&"function"!==t?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");t.exports=r},{}],loader:[function(e,t,n){function r(){if(!x++){var e=h.info=NREUM.info,t=d.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&t))return s.abort();f(y,function(t,n){e[t]||(e[t]=n)}),c("mark",["onload",a()+h.offset],null,"api");var n=d.createElement("script");n.src="https://"+e.agent,t.parentNode.insertBefore(n,t)}}function o(){"complete"===d.readyState&&i()}function i(){c("mark",["domContent",a()+h.offset],null,"api")}function a(){return E.exists&&performance.now?Math.round(performance.now()):(u=Math.max((new Date).getTime(),u))-h.offset}var u=(new Date).getTime(),c=e("handle"),f=e(2),s=e("ee"),p=window,d=p.document,l="addEventListener",m="attachEvent",w=p.XMLHttpRequest,g=w&&w.prototype;NREUM.o={ST:setTimeout,SI:p.setImmediate,CT:clearTimeout,XHR:w,REQ:p.Request,EV:p.Event,PR:p.Promise,MO:p.MutationObserver};var v=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1071.min.js"},b=w&&g&&g[l]&&!/CriOS/.test(navigator.userAgent),h=t.exports={offset:u,now:a,origin:v,features:{},xhrWrappable:b};e(1),d[l]?(d[l]("DOMContentLoaded",i,!1),p[l]("load",r,!1)):(d[m]("onreadystatechange",o),p[m]("onload",r)),c("mark",["firstbyte",u],null,"api");var x=0,E=e(4)},{}]},{},["loader"]);</script>
    <title>Acuity Scheduling</title>
</head>


<div class="pane error-flash alert alert-danger" style="display:none"></div>

<script type="text/javascript">
    self.owner = 15036651;
    self.durations = new Array();
    self.typeToCalendars = new Array();
    self.isClass = new Array();
    <?php if($serviceList != null){
    for ($j = 0; $j < count($serviceList); $j++) {
    $serviceId =  $serviceList[$i]['id'];
    ?>
    self.durations['<?php echo $serviceId ;?>'] = 30;
    self.typeToCalendars['<?php echo $serviceId ;?>'] = [[1856907, 'frank', '', 'America/New_York']];
    <?php
    }
    }
    ?>
</script>

<div class="content inverse schedule-appointment" id="schedule-appointment">
    <a href="book-appointments.php" data-pjax class="btn btn-inverse btn-top btn-detail-back hidden-print"><i class="icon-chevron-left"></i> Back</a>
    <form action="book-appointments.php?action=insert" autocomplete="off" class="detail-nav-link" method="POST" novalidate>
        <input type="hidden" name="__csrf_magic" value="YldQbCtMR0FyTG1ETytnYll0UG1rc2wrdGk5eFRSTURnV0g3TVlNSjM2az06eyJ1IjoxNTAzNjY1MSwieCI6MTUyMDA0NjY1NywibiI6IjQ3YjFmYTdkIn0=" />
        <div class="panel-group">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="panel-toggle" id="schedule-type-toggle" data-toggle="collapse" data-parent="#schedule-appointment" href="#schedule-type">Appointment Type</a>
                </h4>
            </div>
            <div id="schedule-type" class="panel-collapse collapse in">
                <div class="panel-body">
                    <select name="appointmentType" label="Appointment type" id="appointmentType" class="required form-control">
                        <option value="">Choose appointment type...</option>
                        <?php
                        if($serviceList != null){
                            for($i = 0 ; $i<count($serviceList);$i++){
                                ?>
                                <option value="<?php echo $serviceList[$i]['id'];?>"  html="<?php echo $serviceList[$i]['service_name'];?><br /><span class='small'>30 minutes</span>">
                                    <?php echo $serviceList[$i]['service_name'];?>
                                </option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                    <div id="addons-container">
                    </div>
                    <div id="schedule-calendar-container" style="display:none">
                        <span class="body-italic-small">with</span>
                        <select name="calendar" class="form-control" id="calendar-list"></select>
                    </div>
                </div>
            </div>
        </div>

        <div class="panel-group">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="panel-toggle collapsed" id="schedule-time-toggle" data-toggle="collapse" data-parent="#schedule-appointment" href="#schedule-time">
                        Date &amp; Time
                    </a>
                </h4>
            </div>
            <div id="schedule-time" class="panel-collapse collapse collapse">
                <div class="panel-body">
                    <div id="custom-date-options" class="always-date-custom" >
                        <p>
                            Date: <input class="form-control" type="date" name="date[]" id="date" value="<?php echo $_REQUEST['date'];?>" />
                        </p>
                        <p id="appt-custom-time">
                            Time:
                        <div class="timezone-time appt-custom-time" style="width: 20em;">
                            <input class="form-control timezone-time__input" type="text" name="time[]" id="appt-custom" value="<?php echo $_REQUEST['time'];?>" placeholder="Ex: 11:30am" />
                            <div class="timezone-time__timezone hidden"><em>(<span class="timezone-text"></span>)</em></div>
                        </div>
                        </p>
                    </div>
                    <div class="hiding-from-specific">
                        <div id="date-picker">
                            <span class="loading-text">Loading calendar...</span>
                        </div>
                        <div class="pull-right calendar-btns">
                            <div class="btn-group">
                                <button type="button" class="btn btn-inverse btn-bordered dropdown-toggle" id="repeat-appt-btn" disabled="disabled" data-toggle="dropdown">
                                    <i class="icon-repeat" aria-hidden="true"></i> Recurring <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right" role="menu">
                                    <li class="disabled"><a href="#">Repeat...</a></li>
                                    <li><a href="#" class="recur-btn" id="recur-weekly">Every day of week</a></li>
                                    <li><a href="#" class="recur-btn" id="recur-biweekly">Every other</a></li>
                                    <li><a href="#" class="recur-btn" id="recur-triweekly">Every third</a></li>
                                    <li><a href="#" class="recur-btn" id="recur-quadweekly">Every fourth</a></li>
                                    <li><a href="#" class="recur-btn" id="recur-monthly">Same date every month</a></li>
                                    <li><a href="#" class="recur-btn" id="recur-monthly-day">Same day of week every month</a></li>
                                    <li><a href="#" class="recur-btn" id="recur-daily">Daily</a></li>
                                    <li class="divider"></li>
                                    <li><a href="#" id="add-another-time">Choose additional time</a></li>
                                </ul>
                            </div>
                            <button type="button" class="btn btn-inverse active" id="custom-time" data-toggle="button"><i class="icon-time"></i> Custom</button>
                        </div>
                        <p id="times">
                            <em>Select a date to see available times</em>
                        </p>
                        <div class="clearfix"></div>

                        <div class="group-quantity-container" style="display:none">
                            Schedule <input type="text" id="group-quantity" class="form-control inline-field" value="1" size="2" /> spots total
                            <a href="#" class="btn btn-primary btn-set-quantity">Set Quantity</a>
                            <div class="group-quantity-warning text-danger" style="display:none">Did you mean to click the Set Quantity button before moving on to the next step?</div>
                        </div>

                        <div id="extra-times">
                            <!-- DYNAMIC -->
                        </div>
                        <div id="recur-settings" style="display:none">
                            Repeat <span id="recur-type" data-type="">type</span> at <span id="recur-time">time</span> starting <span id="recur-start">start</span> for
                            <select id="recur-times" class="form-control"><option label="2" value="2">2</option>
                                <option label="3" value="3">3</option>
                                <option label="4" value="4">4</option>
                                <option label="5" value="5">5</option>
                                <option label="6" value="6">6</option>
                                <option label="7" value="7">7</option>
                                <option label="8" value="8" selected="selected">8</option>
                                <option label="9" value="9">9</option>
                                <option label="10" value="10">10</option>
                                <option label="11" value="11">11</option>
                                <option label="12" value="12">12</option>
                                <option label="13" value="13">13</option>
                                <option label="14" value="14">14</option>
                                <option label="15" value="15">15</option>
                                <option label="16" value="16">16</option>
                                <option label="17" value="17">17</option>
                                <option label="18" value="18">18</option>
                                <option label="19" value="19">19</option>
                                <option label="20" value="20">20</option>
                                <option label="21" value="21">21</option>
                                <option label="22" value="22">22</option>
                                <option label="23" value="23">23</option>
                                <option label="24" value="24">24</option>
                                <option label="25" value="25">25</option>
                                <option label="26" value="26">26</option>
                                <option label="27" value="27">27</option>
                                <option label="28" value="28">28</option>
                                <option label="29" value="29">29</option>
                                <option label="30" value="30">30</option>
                                <option label="31" value="31">31</option>
                                <option label="32" value="32">32</option>
                                <option label="33" value="33">33</option>
                                <option label="34" value="34">34</option>
                                <option label="35" value="35">35</option>
                                <option label="36" value="36">36</option>
                                <option label="37" value="37">37</option>
                                <option label="38" value="38">38</option>
                                <option label="39" value="39">39</option>
                                <option label="40" value="40">40</option>
                                <option label="41" value="41">41</option>
                                <option label="42" value="42">42</option>
                                <option label="43" value="43">43</option>
                                <option label="44" value="44">44</option>
                                <option label="45" value="45">45</option>
                                <option label="46" value="46">46</option>
                                <option label="47" value="47">47</option>
                                <option label="48" value="48">48</option>
                                <option label="49" value="49">49</option>
                                <option label="50" value="50">50</option>
                                <option label="51" value="51">51</option>
                                <option label="52" value="52">52</option>
                            </select> times.<br />
                            <br />
                            <a href="#" class="btn btn-default" id="add-recur-times">Add Times</a> <a href="#" class="btn btn-link">cancel</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="panel-group">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="panel-toggle collapsed" id="schedule-name-toggle" data-toggle="collapse" data-parent="#schedule-appointment" href="#schedule-name">
                        Client Name
                    </a>
                </h4>
            </div>
            <div id="schedule-name" class="panel-collapse collapse">
                <div class="panel-body">
                    <div>
                        <label class="control-label hide-if-placeholder">First Name <span class="error">*</span></label>
                        <input type="text" class="form-control" autocorrect="off" autocomplete="off" placeholder="First Name *" id="firstName" name="firstName" maxlength="49" value="" />
                    </div>
                    <div>
                        <label class="control-label hide-if-placeholder">Last Name <span class="error">*</span></label>
                        <input type="text" class="form-control" autocorrect="off" autocomplete="off" placeholder="Last Name *" id="lastName" name="lastName" maxlength="40" value="" />
                    </div>
                    <div>
                        <label class="control-label hide-if-placeholder">Phone</label>
                        <input type="tel" class="form-control" autocorrect="off" autocomplete="off" placeholder="Phone" name="phone" id="phone" maxlength="64" value="" />
                    </div>
                    <div>
                        <label class="control-label hide-if-placeholder">E-mail</label>
                        <input type="email" class="form-control" autocorrect="off" autocomplete="off" placeholder="E-mail" name="email" id="email" maxlength="128" value="" />
                    </div>
                </div>
            </div>
        </div>


        <div class="panel-group">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a class="panel-toggle collapsed" id="schedule-forms-toggle" data-toggle="collapse" data-parent="#schedule-appointment" href="#schedule-forms">
                        <span class="show-if-has-forms" style="display:none">Forms and</span> Notes
                    </a>
                </h4>
            </div>
            <div id="schedule-forms" class="panel-collapse collapse">
                <div class="panel-body">
                    <div class="form-group">
                        <label for="appt-notes" class="control-label">Notes</label>
                        <textarea rows="5" class="form-control" style="width:100%" id="appt-notes" name="notes" placeholder="Private notes about appointment"></textarea>
                    </div>
                    <div id="forms-container"><span class="body-italic-small">Choose an appointment type to see its Intake Forms...</span></div>
                </div>
            </div>
        </div>


        <div class="schedule-actions panel-body">
            <div class="" id="submit-warning">
                <div class="submit-warning-message"></div>

                <div class="show-if-overbooking">Are you sure you want to schedule this appointment even though it might overbook?</div>

                <div class="btn-group schedule-btn-group dropup">
                    <input type="submit" id="submit-appointment" class="btn btn-default" data-loading-text="Scheduling..." disabled="disabled" value="Schedule Appointment" />
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="caret"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <ul class="dropdown-menu dropdown-dark" role="menu">
                        <li>
                            <input type="submit" name="no-email" value="Schedule, but don't send confirmation e-mail" data-loading-text="Scheduling..." class="btn btn-default" />
                        </li>
                    </ul>
                </div>

                <a class="btn btn-link pull-right btn-detail-back" href="book-appointments.php?rs=1">Cancel</a>
            </div>
            <div class="alert alert-danger" style="display:none" id="submit-error"></div>
        </div>
    </form>
</div>





<script type="text/javascript">
</script>