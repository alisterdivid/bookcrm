<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 2/28/2018
 * Time: 7:39 PM
 */

$date = $_POST['date'][0];
if(($date == '') || $date == null){
    $date = $_POST['date'][1];
}
$time = $_POST['time'][0];
if(($time == '') || $time == null){
    $time = $_POST['time'][1];
}
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$serviceId = $_POST['appointmentType'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$notes = $_POST['notes'];

if(isset($_POST['firstName']) && isset($_POST['lastName'])) {
    $sql = "select id from tbl_book_clients WHERE firstName = '$firstName' AND lastName = '$lastName'";
    $confirmClients = $db->queryArray($sql);
    if($confirmClients != null){
        $clientId = $confirmClients[0]['id'];
    }
    else {
        $sql = "INSERT INTO tbl_book_clients 
                          SET firstName= '" . $firstName . "', 
                              lastName = '" . $lastName . "', 
                              email = '" . $email . "',
                              phone = '" . $phone . "', 
                              update_time = now(),
                              create_time = now()";
        $db_insert = $db->queryInsert($sql);

        $sql = "select id from tbl_book_clients ORDER BY id DESC ";
        $clientsList = $db->queryArray($sql);
        $clientId = $clientsList[0]['id'];
    }

    $sql = "INSERT INTO leads 
                      SET siteuser_id = '" . $clientId . "', 
                          rq_pack_id= '" . $serviceId . "', 
                          rq_comments = '" . $notes . "',
                          td_request_date = '" . $date . "',
                          td_request_time = '" . $time . "',
                          service_type = 'service-department', 
                          lead_insert_date = now()";
    $db_insert = $db->queryInsert($sql);


    $sql = "select id from leads WHERE service_type = 'service-department' ORDER BY id DESC ";
    $leadList = $db->queryArray($sql);
    $mId = $leadList[0]['id'];
    $sql = "insert into tbl_book_logs 
                    SET lead_id = '$mId',
                        change_type ='Scheduled',
                        change_time = now() ";
    $db->queryInsert($sql);
}

if(($email != null) && ($email != "")){
    $sql = "select service_name from tbl_service WHERE id = '$serviceId'";
    $serviceList = $db->queryArray($sql);
    $serviceName = $serviceList[0]['service_name'];
    $htmlmessage = '<table cellspacing="4" cellpadding="5" class="user-info-table" style="width:100%">
                  <tbody>
                    <tr>
                      <td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">Hi '.$firstName.',</td>
                    </tr>
                    <tr>
                      <td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">&nbsp;</td>
                    </tr>
                    <tr>
                      <td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">Thank you, your appointment has been successfully scheduled.</td>
                    </tr>
					<tr><td>&nbsp;</td></tr>
					<tr><td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">What :'.$serviceName.'</td></tr>
					<tr><td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">From '.date('l , F d Y H:s a',strtotime($date.' '.$time)).'(30min)</td></tr>
					<tr><td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:500; padding:5px; text-align:left;"></td></tr>
                    <tr>
                      <td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">&nbsp;</td>
                    </tr>
                    <tr>
                      <td style="font-size:14px; line-height:14px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">Team Pickering Toyota</td>
                    </tr>
                  </tbody>
                </table>';
    PT_sendEmail($email,'Sevice Scheduled' ,$htmlmessage);

    $htmlmessage1 = '<table cellspacing="4" cellpadding="5" class="user-info-table" style="width:100%">
                  <tbody>                
                    <tr>
                      <td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">&nbsp;</td>
                    </tr>
                    <tr>
                      <td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">Appointment Scheduled</td>
                    </tr>
					<tr><td>&nbsp;</td></tr>
					<tr><td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">What :'.$serviceName.'</td></tr>
					<tr><td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">From '.date('l , F d Y H:s a',strtotime($date.' '.$time)).'(30min)</td></tr>
					<tr><td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:500; padding:5px; text-align:left;"></td></tr>
                    <tr>
                      <td style="font-size:14px; line-height:20px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">&nbsp;</td>
                    </tr>
                    <tr>
                      <td style="font-size:14px; line-height:14px; color:#2c2c2c; font-weight:700; padding:5px; text-align:left;">Team Pickering Toyota</td>
                    </tr>
                  </tbody>
                </table>';
    PT_sendEmail(PT_Email,'New Sevice Scheduled' ,$htmlmessage1);
}
$request_url = ($_SERVER["HTTP_REFERER"]);
header('Location: ' . $request_url, true, 302);
exit;