<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 3/3/2018
 * Time: 4:37 PM
 */

if(isset($_REQUEST['start_time']) && ($_REQUEST['start_time'] != null)){
    $type = $_REQUEST['type'];
    $returnUrl = $_REQUEST['returnUrl'];
    $start_time = $_REQUEST['start_time'];
    $end_time = $_REQUEST['end_time'];
    $start_date = $_REQUEST['start_date'];
    $end_date = $_REQUEST['end_date'];
    $dayOfWeek = $_REQUEST['dayOfWeek'];
    $recur_until = $_REQUEST['recur-until'];
    $notes = $_REQUEST['notes'];

    $sql = "insert into tbl_book_block 
                        SET block_type = '$type',
                         start_date = '$start_date',
                         end_date = '$end_date',
                         start_time = '$start_time',
                         end_time = '$end_time',
                         dayOfweek = '$dayOfWeek',
                         recur_until = '$recur_until',
                         notes = '$notes',
                         update_time = now(),
                         create_time = now()";
    $db->queryInsert($sql);
}
header('Location: book-appointments.php', true, 302);
exit;

