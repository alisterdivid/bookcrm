<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 3/1/2018
 * Time: 5:39 PM
 */


if(isset($_REQUEST['apptId'])){
    $mId = $_REQUEST['apptId'];
    $sql = "UPDATE leads SET lead_type= 'closing_lead' WHERE id = '$mId'";
    $db->query($sql);
}


$request_url=( $_SERVER["HTTP_REFERER"]);

header('Location: '.$request_url, true, 302);
exit;
