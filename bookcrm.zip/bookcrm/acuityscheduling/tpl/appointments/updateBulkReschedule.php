<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 3/1/2018
 * Time: 5:39 PM
 */


if(isset($_REQUEST['time'])){
    $mIds = $_REQUEST['time'];
    foreach ($mIds as $key => $mId) {
        $requestDate = explode(' ' , $mId);
        $sql = "UPDATE leads SET td_request_date= '".$requestDate[0]."',
                                  td_request_time = '".$requestDate[1]."'
                                WHERE id = '$key'";
        $db->query($sql);
    }

    $requestUrl = $_SERVER['REQUEST_URI'];
    $requestUrl = explode('updateBulkReschedule&back=',$requestUrl);
    header('Location: '.$requestUrl[1], true, 302);
    exit;
}

