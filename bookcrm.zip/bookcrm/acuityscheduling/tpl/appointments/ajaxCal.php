<?php
if(isset( $_GET['day'])) {
    $requestDate = $_GET['day'];
    if ($requestDate == 'today') {
        $requestDate = date('Y-m-d');
    }

    $dateArray = explode('-', $requestDate);
    $_GET['year'] = $dateArray[0];
    $_GET['month'] = $dateArray[1];
}
$topCalendar = new PTtopCalendar();
echo $topCalendar->calendarHeading();
echo $topCalendar->show();
?>
