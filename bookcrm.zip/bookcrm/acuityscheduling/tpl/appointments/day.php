<?php
global $view, $ajax;
if(isset( $_GET['day'])) {
    $requestDate = $_GET['day'];
    if ($requestDate == 'today') {
        $requestDate = date('Y-m-d');
    }
    $dateArray = explode('-', $requestDate);
    $_GET['year'] = $dateArray[0];
    $_GET['month'] = $dateArray[1];
    $_GET['day'] = $dateArray[2];

    $date=date_create($requestDate);
}
?>
<?php
if ($ajax == "1"){
	?>
	<script type="text/javascript">
		if (window.CURRENT_VERSION<875) location.reload();
	</script>
	<?php
}
?>

<div class="calendar-heading-container">
	<div class="hidden-print">
		<div class="calendar-heading">
			<div class="calendar-title-header">
				<h4 class="calendar-title">
					<span class="calendar-title-text"><?php echo date_format($date,"l,F d, Y");?></span>
                    <span class="calendar-loading-text progress-spinner">Loading...</span>
				</h4>

				<span class="appointment-count">
					<?php
                        $calendar = new Calendar();
					    echo $calendar->countDayAppts();
					?>
					  appointments
                </span>
			</div>
		</div>
	</div>
	<div class="scale-75">

		<script id="filter-calendars-popover-content" type="text/x-template">
			<form action="book-appointments.php" method="POST">
				<input type="hidden" name="filter-submit" value="1" />
				<div class="calendar-selection-container">

					<div class="checkbox">
						<label>
							<input type="checkbox" name="filterCalendars[]" data-parent-calendar="1856907" class="filter-calendar" value="1856907" checked="checked" />
							frank
						</label>
					</div>
				</div>
                <input type="submit" class="btn btn-default btn-block margin-top" value="Show Selected" />
			</form>
		</script>

		<div class="calendar-summary">
			<div class="btn-group btn-view-group">
                <?php
                    echo $calendar->showDayNavi();
                ?>
			</div>


			<a href="#" class="btn btn-inverse btn-show-search hidden-lg hidden-md"><i class="icon-search"></i></a>

			<span class="appointment-action-group btn-group hidden-xs hidden-sm">
			<a class="btn btn-inverse detail-nav-link fastjax new-appointment-link" href="book-appointments.php?action=new"><i class="icon-plus-sign"></i> Appointment</a>
			<a class="btn btn-inverse detail-nav-link btn-block-time fastjax" href="book-appointments.php?action=newBlockHtml&day=<?php echo $requestDate;?>">
				<i></i> Block
			</a>
					</span>

			<div class="secondary-actions-group">
<!--				<div class="btn-group print-btn hidden-print hidden-xs">-->
<!--					<button type="button" class="btn btn-inverse btn-sm dropdown-toggle" data-placement="bottom" data-toggle="dropdown" title="Zoom">-->
<!--						<i class="icon-zoom-in"></i>-->
<!--						<span class="text-muted">0.75x</span>				</button>-->
<!--					<ul class="dropdown-menu dropdown-menu-right dropdown-menu-narrow" role="menu">-->
<!--						<li ><a href="book-appointments.php?scale=-1">(Auto)</a></li>-->
<!--						<li ><a href="book-appointments.php?scale=0.5">0.5x</a></li>-->
<!--						<li class="active"><a href="book-appointments.php?scale=0.75">0.75x</a></li>-->
<!--						<li ><a href="book-appointments.php?scale=1">1x</a></li>-->
<!--						<li ><a href="book-appointments.php?scale=2">2x</a></li>-->
<!--						<li ><a href="book-appointments.php?scale=3">3x</a></li>-->
<!--						<li ><a href="book-appointments.php?scale=4">4x</a></li>-->
<!--					</ul>-->
<!--				</div>-->

				<div class="btn-group print-btn hidden-print hidden-xs hidden-sm">
					<button type="button" class="btn btn-inverse btn-sm dropdown-toggle" data-placement="bottom" data-toggle="dropdown" title="Print">
						<i class="icon-print" aria-hidden="true" title="Print"></i>
					</button>
					<ul class="dropdown-menu dropdown-menu-right" role="menu">
						<li><a href="book-appointments.php?print=1" class="real-link" target="_blank"><i class="icon-calendar"></i> Print Calendar</a></li>
						<li><a href="book-appointments.php?print=1&agenda=1" class="real-link" target="_blank"><i class="icon-list"></i> Print Agenda</a></li>
					</ul>
				</div>

				<div class="print-btn">

					<script id="support-form-template" type="text/x-template">
						<div class="content">
							<a href="book-appointments.php" data-pjax class="btn btn-inverse btn-bordered btn-top btn-detail-back hidden-print"><i class="icon-chevron-left"></i> Back</a>

							<div class="row">
								<div class="col-xs-12">
									<form action="help.php?action=send&backto=thanks" class="support-form form-horizontal detail-nav-link margin-top" method="POST">
										<input type="hidden" name="fullstory" id="fullstory" value="" />
										<div class="form-group">
											<label class="control-label col-xs-2">Your<br />E-mail</label>
											<div class="col-xs-10">
												<input type="email" class="form-control validate required" id="email" name="email" value="softensoftwares@gmail.com" />
											</div>
										</div>
										<div class="form-group">
											<label class="control-label col-xs-2">Subject</label>
											<div class="col-xs-10">
												<input type="text" class="form-control" id="help-subject" name="subject" value="" />
											</div>
										</div>
										<div class="form-group">
											<label class="control-label col-xs-2">Message</label>
											<div class="col-xs-10">
												<textarea class="form-control validate required" name="message" id="help-message" rows="10"></textarea>
											</div>
										</div>
										<div class="form-group">
											<label class="control-label col-sm-2"></label>
											<div class="col-sm-9">
												<select name="feeling" id="help-feeling" class="form-control inline-field">
													<option value="">Right now I'm...</option>
													<option value="Smiling">Smiling</option>
													<option value="Furrowing my eyebrows">Furrowing my eyebrows</option>
													<option value="Making a mean face">Making a mean face</option>
													<option value="Stroking my chin with curiosity">Stroking my chin with curiosity</option>
													<option value="I don’t make faces">I don’t make faces</option>
													<option value="other">Other...</option>
												</select>
												<input type="text" name="feeling_other" id="help-feeling-other" style="display:none" class="form-control" placeholder="¯\_(ツ)_/¯" />
											</div>
										</div>
										<div class="form-group">
											<div class="col-xs-10 ">
												<input type="submit" class="btn btn-default" value="Send Message" />
												<div class="margin-top text-muted">
													Or e-mail us at <a href="mailto:support@acuityscheduling.com" class="real-link">support@acuityscheduling.com</a>
												</div>
											</div>
										</div>
									</form>		</div>
							</div>
						</div>
					</script>




					<script id="getting-started-content" type="text/x-template">
						<div class="collapsed-open">

							<div class="getting-started-container">
								<div class="getting-started-toprail getting-started-core-steps" >

									<button type="button" class="close pull-right hide-guide" aria-hidden="true" data-toggle="tooltip" title="Complete the 4 core steps to hide this" data-placement="left">&times;</button>

									<div class="toprail-title-1 column-1">&nbsp;</div>
									<div class="toprail-title-1 column-2">Let's Take a Walkthrough</div>
								</div>

								<div class="getting-started-bottomrail getting-started-core-steps" >
									<div class="column-1">
										<strong>Let's do this, Frank!</strong><br><br> There are four core steps to start accepting appointments. If you can master these four things, you can do anything! (We believe in you.)<br><br>
									</div>

									<div class="column-2 core-steps-button-container">
										<a href="book-appointments.php?action=appointmentTypes&coreFromWalkthrough=1" class="btn  btn-step-completed">Create your Appointment Types <i class="icon-ok-sign icon-step-completed"></i></a>
										<a href="preferences.php?tab=schedule&coreFromWalkthrough=1" class="btn  ">Set up your Calendar Availability <i class="icon-ok-sign icon-step-completed"></i></a>
										<a href="preferences.php?tab=customization&coreFromWalkthrough=1" class="btn  btn-step-completed">Customize your Client's Scheduling Page <i class="icon-ok-sign icon-step-completed"></i></a>
										<a href="preferences.php?action=syncing&coreFromWalkthrough=1" class="btn  btn-step-completed">Sync with Other Calendars <i class="icon-ok-sign icon-step-completed"></i></a>
									</div>

									<div class="column-3">
										Psst, come back! We're almost done setting things up. Let's continue on with
										setting up your availability next.
									</div>
								</div>




								<div class="getting-started-toprail getting-started-extra-steps" style="display:none">
									<a href="account.php?action=toggleGettingStarted&state=0" class="close-getting-started close pull-right" aria-hidden="true">&times;</a>
									<div class="toprail-title-1 column-1">&nbsp;</div>
									<div class="toprail-title-1 column-2">Let's Take a Walkthrough</div>
								</div>

								<div class="getting-started-bottomrail extra-steps-bottomrail getting-started-extra-steps" style="display:none">
									<div class="column-1"><strong>Bravo Frank!</strong><br><br>Those are the basic elements,<br> but if you're interested in amping it up, here are a few more things you can do:<br><br>
										<p class="more-help-text"><a href="#" class="btn-show-core-steps"><i class="icon-chevron-left"></i>&nbsp;&nbsp;go back to core steps</a></p>
									</div>

									<div class="column-2 core-steps-button-container">

										<a href="/admin/email-settings" class="btn  ">Customize Emails and Text Reminders <i class="icon-ok-sign icon-step-completed"></i></a>
										<a href="/preferences.php?tab=payments" class="btn  ">Accept Payments <i class="icon-ok-sign icon-step-completed"></i></a>
										<a href="/forms.php" class="btn  ">Gather Client Info with Intake Forms <i class="icon-ok-sign icon-step-completed"></i></a>
										<a href="/admin/scheduling-link" class="btn  ">Embed your Scheduler on your Website <i class="icon-ok-sign icon-step-completed"></i></a>
										<a href="/preferences.php?action=users" class="btn  ">Add Additional Users <i class="icon-ok-sign icon-step-completed"></i></a>
									</div>

									<div class="column-3">
										<div style="extra-step-info">
											<i class="icon-arrow-left"></i>&nbsp;&nbsp;Choose a section to jump to it and learn more!


										</div>
									</div>
								</div>
							</div>
					</script>

					<script type="text/javascript">
						justCompletedSetupStep = '';
					</script>
				</div>

				<div class="global-search-container hidden-print">
					<form action="" method="POST">
						<div class="search-group">
							<input type="text" class="form-control" name="search" autocomplete="off" spellcheck="off" placeholder="Search...">
							<span class="search-icon-addon"><i class="icon-search"></i></span>
						</div>
					</form>

					<div class="global-search-results hidden"></div>
				</div>		</div>
		</div>
	</div></div>
<div class="calendar-appointments">
	<div class="calendar-daily-view-container affix-scroll-container" tabindex="1">
		<div class="calendar-daily-view row calendar-columns-1">

			<table width="100%">
				<tr>
                    <td class="calendar-times-column"><script type="text/javascript">var currentDate='2018-03-06';</script><div class="appointmentListing-container timeListing-container affix affix-left" data-top="126" data-left="250" style="left: 0px; z-index: 3;"><div class="listingTitle "><i class="icon-time"></i></div><div class="timeListing"><div class="timeslot newHour" style="height:84px">9am</div><div class="timeslot newHour" style="height:84px">10am</div><div class="timeslot newHour" style="height:84px">11am</div><div class="timeslot newHour" style="height:84px">Noon</div><div class="timeslot newHour" style="height:84px">1pm</div><div class="timeslot newHour" style="height:84px">2pm</div><div class="timeslot newHour" style="height:84px">3pm</div><div class="timeslot newHour" style="height:84px">4pm</div><div class="timeslot newHour" style="height:84px">5pm</div></div></div></td>
					<td>
						<table style="min-width:100%">
							<tr>

                                <?php
                                echo $calendar->showDayView();
                                ?>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</div>
	</div>
	<div class="clearfix"></div>

	<div class="calendar-list-view-container">

	</div>
</div>
<input type="hidden" id="current-date" value="2018-02-23" />

