<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 3/2/2018
 * Time: 9:18 PM
 */

if(isset($_REQUEST['id'])){
    $mId = $_REQUEST['id'];
    $serviceId = $_REQUEST['appointmentType'];
    $firstName = $_REQUEST['first_name'];
    $lastName = $_REQUEST['last_name'];
    $phone = $_REQUEST['phone'];
    $email = $_REQUEST['email'];
    $notes = $_REQUEST['notes'];

    $sql = "select id from tbl_book_clients WHERE firstName = '$firstName'  AND lastName = '$lastName'";
    $clientList = $db->queryArray($sql);
    if($clientList != null){
        $sql = "update tbl_book_clients 
                          SET firstName= '" . $firstName . "', 
                              lastName = '" . $lastName . "', 
                              email = '" . $email . "',
                              phone = '" . $phone . "', 
                              update_time = now()
                           where id = '".$clientList[0]['id'];
        $db_insert = $db->queryInsert($sql);
        $clientId = $clientList[0]['id'];
    }
    else {
        $sql = "insert into tbl_book_clients 
                          SET firstName= '" . $firstName . "', 
                              lastName = '" . $lastName . "', 
                              email = '" . $email . "',
                              phone = '" . $phone . "', 
                              update_time = now(),
                              create_time = now()";
        $db_insert = $db->queryInsert($sql);

        $sql = "select id from tbl_book_clients ORDER BY id DESC ";
        $clientsList = $db->queryArray($sql);
        $clientId = $clientsList[0]['id'];
    }


    $sql = "select clients.* , lead.rq_comments as lnotes ,
                    lead.rq_pack_id as serviceId
                      from leads as lead , tbl_book_clients as clients 
                      WHERE lead.siteuser_id =clients.id AND lead.service_type ='service-department' AND lead.id = '$mId'";
    $oldData = $db->queryArray($sql);
    if($oldData != null){
        if(($oldData[0]['firstName'] != $firstName) || ($oldData[0]['lastName'] != $lastName)){
            $sql = "insert into tbl_book_logs 
                    SET lead_id = '$mId',
                        change_type ='Name',
                        change_time = now() ";
            $db->queryInsert($sql);
        }
        if($oldData[0]['phone'] != $phone){
            $sql = "insert into tbl_book_logs 
                    SET lead_id = '$mId',
                        change_type ='Phone',
                        change_time = now() ";
            $db->queryInsert($sql);
        }
        if($oldData[0]['email'] != $email){
            $sql = "insert into tbl_book_logs 
                    SET lead_id = '$mId',
                        change_type ='Email',
                        change_time = now() ";
            $db->queryInsert($sql);
        }
        if($oldData[0]['lnotes'] != $notes){
            $sql = "insert into tbl_book_logs 
                    SET lead_id = '$mId',
                        change_type ='Notes',
                        change_time = now() ";
            $db->queryInsert($sql);
        }
        if($oldData[0]['serviceId'] != $serviceId){
            $sql = "insert into tbl_book_logs 
                    SET lead_id = '$mId',
                        change_type ='Sevice',
                        change_time = now() ";
            $db->queryInsert($sql);
        }
    }

    $sql = "UPDATE leads SET 
                         siteuser_id = '" . $clientId . "',
                         rq_pack_id = '" . $serviceId . "',
                         rq_comments = '" . $notes . "'
                    WHERE id = '$mId'";
    $db->query($sql);



    header('Location: '.'book-appointments.php?action=detail&ajax=1&id='.$mId.'&ajax=1', true, 302);
}

exit;
