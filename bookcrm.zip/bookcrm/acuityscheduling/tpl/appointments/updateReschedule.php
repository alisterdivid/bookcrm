<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 3/1/2018
 * Time: 5:39 PM
 */


if(isset($_REQUEST['appt'])){
    $mId = $_REQUEST['appt'];
    $requestDate = $_POST['date'][1];
    if(($requestDate == null) || ($requestDate == '')){
        $requestDate = $_POST['date'][0];
    }
    $requestTime = $_POST['time'][1];
    if(($requestTime == null) || ($requestTime == '')){
        $requestTime = $_POST['time'][0];
    }
    $sql = "UPDATE leads SET 
                         td_request_date = '" . $requestDate . "',
                         td_request_time = '" . $requestTime . "'
                    WHERE id = '$mId'";
    $db->query($sql);
    header('Location: '.'book-appointments.php?action=detail&ajax=1&id='.$mId.'&ajax=1', true, 302);
}

exit;
