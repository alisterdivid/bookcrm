<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 3/1/2018
 * Time: 10:37 AM
 */
echo '123';