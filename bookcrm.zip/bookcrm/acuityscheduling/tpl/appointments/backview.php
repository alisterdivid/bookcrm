<?php
$backId = $_REQUEST['appt'];
$sql = "SELECT clients.id AS clientID, clients.firstName AS lf_first_name , clients.lastName AS lf_last_name ,
               clients.phone AS phone , clients.email AS email, clients.notes AS clientNotes,
               clients.intake AS intake, leads.id AS id ,leads.td_request_date AS td_request_date, 
               leads.td_request_time AS td_request_time, leads.rq_pack_id AS rq_pack_id,
               leads.rq_comments AS rq_comments 
           FROM leads AS leads, tbl_book_clients AS clients 
           WHERE leads.siteuser_id = clients.id AND leads.service_type='service-department' AND leads.id = '$backId' ";
$leadList = $db->queryArray($sql);
$curLead = $leadList[0];

?>

<head><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,t,n){function r(n){if(!t[n]){var o=t[n]={exports:{}};e[n][0].call(o.exports,function(t){var o=e[n][1][t];return r(o||t)},o,o.exports)}return t[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<n.length;o++)r(n[o]);return r}({1:[function(e,t,n){function r(){}function o(e,t,n){return function(){return i(e,[f.now()].concat(u(arguments)),t?null:this,n),t?void 0:this}}var i=e("handle"),a=e(2),u=e(3),c=e("ee").get("tracer"),f=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],d="api-",l=d+"ixn-";a(p,function(e,t){s[t]=o(d+t,!0,"api")}),s.addPageAction=o(d+"addPageAction",!0),s.setCurrentRouteName=o(d+"routeName",!0),t.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,t){var n={},r=this,o="function"==typeof t;return i(l+"tracer",[f.now(),e,n],r),function(){if(c.emit((o?"":"no-")+"fn-start",[f.now(),r,o],n),o)try{return t.apply(this,arguments)}catch(e){throw c.emit("fn-err",[arguments,this,e],n),e}finally{c.emit("fn-end",[f.now()],n)}}}};a("setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,t){m[t]=o(l+t)}),newrelic.noticeError=function(e){"string"==typeof e&&(e=new Error(e)),i("err",[e,f.now()])}},{}],2:[function(e,t,n){function r(e,t){var n=[],r="",i=0;for(r in e)o.call(e,r)&&(n[i]=t(r,e[r]),i+=1);return n}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],3:[function(e,t,n){function r(e,t,n){t||(t=0),"undefined"==typeof n&&(n=e?e.length:0);for(var r=-1,o=n-t||0,i=Array(o<0?0:o);++r<o;)i[r]=e[t+r];return i}t.exports=r},{}],4:[function(e,t,n){t.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,t,n){function r(){}function o(e){function t(e){return e&&e instanceof r?e:e?c(e,u,i):i()}function n(n,r,o,i){if(!d.aborted||i){e&&e(n,r,o);for(var a=t(o),u=m(n),c=u.length,f=0;f<c;f++)u[f].apply(a,r);var p=s[y[n]];return p&&p.push([b,n,r,a]),a}}function l(e,t){v[e]=m(e).concat(t)}function m(e){return v[e]||[]}function w(e){return p[e]=p[e]||o(n)}function g(e,t){f(e,function(e,n){t=t||"feature",y[n]=t,t in s||(s[t]=[])})}var v={},y={},b={on:l,emit:n,get:w,listeners:m,context:t,buffer:g,abort:a,aborted:!1};return b}function i(){return new r}function a(){(s.api||s.feature)&&(d.aborted=!0,s=d.backlog={})}var u="nr@context",c=e("gos"),f=e(2),s={},p={},d=t.exports=o();d.backlog=s},{}],gos:[function(e,t,n){function r(e,t,n){if(o.call(e,t))return e[t];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[t]=r,r}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],handle:[function(e,t,n){function r(e,t,n,r){o.buffer([e],r),o.emit(e,t,n)}var o=e("ee").get("handle");t.exports=r,r.ee=o},{}],id:[function(e,t,n){function r(e){var t=typeof e;return!e||"object"!==t&&"function"!==t?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");t.exports=r},{}],loader:[function(e,t,n){function r(){if(!x++){var e=h.info=NREUM.info,t=d.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&t))return s.abort();f(y,function(t,n){e[t]||(e[t]=n)}),c("mark",["onload",a()+h.offset],null,"api");var n=d.createElement("script");n.src="https://"+e.agent,t.parentNode.insertBefore(n,t)}}function o(){"complete"===d.readyState&&i()}function i(){c("mark",["domContent",a()+h.offset],null,"api")}function a(){return E.exists&&performance.now?Math.round(performance.now()):(u=Math.max((new Date).getTime(),u))-h.offset}var u=(new Date).getTime(),c=e("handle"),f=e(2),s=e("ee"),p=window,d=p.document,l="addEventListener",m="attachEvent",w=p.XMLHttpRequest,g=w&&w.prototype;NREUM.o={ST:setTimeout,SI:p.setImmediate,CT:clearTimeout,XHR:w,REQ:p.Request,EV:p.Event,PR:p.Promise,MO:p.MutationObserver};var v=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1071.min.js"},b=w&&g&&g[l]&&!/CriOS/.test(navigator.userAgent),h=t.exports={offset:u,now:a,origin:v,features:{},xhrWrappable:b};e(1),d[l]?(d[l]("DOMContentLoaded",i,!1),p[l]("load",r,!1)):(d[m]("onreadystatechange",o),p[m]("onload",r)),c("mark",["firstbyte",u],null,"api");var x=0,E=e(4)},{}]},{},["loader"]);</script>
    <title><?php echo $curLead['lf_first_name'];?> <?php echo $curLead['lf_last_name'];?> on <?php echo date('F d, Y',strtotime($curLead['td_request_date']));?> at <?php echo $curLead['td_request_time'];?> | Pickering Toyota Scheduling</title>
</head>


<div class="pane error-flash alert alert-danger" style="display:none"></div>


<form action="book-appointments.php?action=update&id=<?php echo $curLead['id'];?>&backto=" method="POST" id="appointment-details-page" class="form-inline detail-nav-link appointment-details-page form-hidden" autocomplete="off" novalidate>
    <input type="hidden" name="__csrf_magic" value="MktrR09qKzlHZ3hWam5tQ1VYeXg0TXdoUnVEY3NJMjcya21MSnYxVktXQT06eyJ1IjoxNTAzNjY1MSwieCI6MTUxOTYzNjIyMiwibiI6IjBmOWE3MGVmIn0=" />
    <div class="content inverse content-inverse">
        <div class="btn-group pull-right dropdown-button-group hidden-print btn-top">
            <a class="btn btn-delete cancel-appt-popup visible-lg visible-md" data-container="body" data-toggle="popover" data-placement="bottom" data-html="true" data-content="<p>Are you sure you want to cancel this appointment?</p><form action='book-appointments.php' method='GET'><input type='hidden' id='no-email' name='no-email' value='0' /><input type='hidden' name='action' value='cancel' /><input type='hidden' name='apptId' value='<?php echo $curLead['id'];?>' /><div class='checkbox'><label><input type='checkbox' name='noshow' value='1' /> This was a no show appointment</label><div class='cancel-note-container'><a href='#' id='cancel-add-note'>Include note in e-mail to client...</a></a></div></div><p><input type='submit' id='cancel-yes-email-btn' class='btn btn-primary btn-block' value='Yes, cancel appointment' data-loading-text='Canceling...' /></p><p><input type='submit' id='cancel-no-email-btn' class='btn btn-primary btn-block' value='Yes, but don&rsquo;t e-mail client' data-loading-text='Canceling...' /></form>"><i class="icon-remove-sign"></i> Cancel</a>
            <a href="book-appointments.php?action=reschedule&appt=<?php echo $curLead['id'];?>" class="detail-nav-link btn btn-inverse visible-lg visible-md"><i class="icon-random"></i> Reschedule</a>
            <a href="book-clients.php?action=detail&firstName=<?php echo $curLead['lf_first_name'];?>&lastName=<?php echo $curLead['lf_last_name'];?>&phone=<?php echo $curLead['phone'];?>&backto=<?php echo $curLead['id'];?>" class="detail-nav-link btn btn-inverse visible-lg visible-md"><i class="icon-user"></i> History</a>
            <a href="#" class="edit-appointment btn btn-inverse visible-lg visible-md"><i class="icon-pencil"></i> Edit</a>

            <button type="button" class="btn btn-inverse dropdown-toggle" data-toggle="dropdown">
                <i class="icon-cog"></i> <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu">
                <li class="hidden-lg hidden-md"><a href="book-clients.php?action=detail&firstName=<?php echo $curLead['lf_first_name'];?>&lastName=<?php echo $curLead['lf_last_name'];?>&phone=<?php echo $curLead['phone'];?>&backto=<?php echo $curLead['id'];?>" class="detail-nav-link"><i class="icon-user"></i> History</a></li>
                <li><a href="book-appointments.php?action=new&firstName=<?php echo $curLead['lf_first_name'];?>&lastName=<?php echo $curLead['lf_last_name'];?>&phone=<?php echo $curLead['phone'];?>&email=<?php echo $curLead['email'];?>&timezone=America%2FNew_York&appointmentType=5736892" class="detail-nav-link"><i class="icon-time"></i> New Appointment</a></li>
                <li><a href="schedule.php?action=appt&owner=15036651&id=64587308aaf327dca12488fcc3411b01&apptId=172679472" class="real-link" target="_blank"><i class="icon-link"></i>Client's Confirmation Page</a></li>

                <li><a href="#" class="resend-btn" data-prompt="Are you sure you want to resend the initial confirmation email to <strong>asd@adf.com</strong>?" data-link="book-appointments.php?action=resendConfirmation&id=<?php echo $curLead['id'];?>" data-back-link="book-appointments.php?action=backview&appt=<?php echo $curLead['id'];?>" target="_blank"><i class="icon-envelope"></i> Resend Confirmation Email</a></li>

                <li class="visible-md visible-lg"><a href="book-appointments.php?action=backview&appt=<?php echo $curLead['id'];?>&print=1" target="_blank" class="real-link"><i class="icon-print"></i> Print</a></li>
                <li class="hidden-lg hidden-md"><a href="#" class="edit-appointment"><i class="icon-pencil"></i> Edit</a></li>
                <li class="hidden-lg hidden-md"><a href="book-appointments.php?action=reschedule&appt=<?php echo $curLead['id'];?>" class="detail-nav-link"><i class="icon-random"></i> Reschedule</a></li>
                <li class="divider hidden-lg hidden-md"></li>
                <li class="hidden-lg hidden-md">
                    <a class="cancel-appt-popup" data-container="body" data-toggle="popover" data-placement="bottom" data-html="true"
                       data-content="<p>Are you sure you want to cancel this appointment?</p><form action='book-appointments.php' method='GET'><input type='hidden' id='no-email' name='no-email' value='0' /><input type='hidden' name='action' value='cancel' />
                       <input type='hidden' name='apptId' value='<?php echo $curLead['id'];?>' /><div class='checkbox'><label><input type='checkbox' name='noshow' value='1' /> This was a no show appointment</label>
                       <div class='cancel-note-container'><a href='#' id='cancel-add-note'>Include note in e-mail to client...</a></a></div></div><p>
                       <input type='submit' class='btn btn-primary btn-block' value='Yes, cancel appointment' /></p><p>
                       <input type='submit' id='cancel-no-email-btn' class='btn btn-primary btn-block' value='Yes, but don&rsquo;t e-mail client' /></form>">
                        <i class="icon-remove-sign text-danger"></i> Cancel Appointment</a>
                </li>
            </ul>
        </div>

        <a href="book-appointments.php" data-pjax class="btn btn-inverse btn-top btn-detail-back hidden-print"><i class="icon-chevron-left"></i> Back</a>


        <div>
            <div class="row">
                <div class="col-xs-7">
                    <?php echo date('l, F d, Y',strtotime($curLead['td_request_date']));?>
                </div>
                <div class="col-xs-5 text-right">
                    30min
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
				<span class="field-rendered edit-appointment">
						<?php echo $curLead['lf_first_name']?>
														</span>
                    <span class="field-input">

					<select name="appointmentType" class="form-control" id="appointmentType">
                        <?php
                        $sql = "select * from tbl_service";
                        $serviceList = $db->queryArray($sql);
                        if($serviceList != null){
                            for($i = 0 ; $i<count($serviceList);$i++){
                                ?>
                                <option value="<?php echo $serviceList[$i]['id'];?>" >
                                    <?php echo $serviceList[$i]['service_name'];?>
                                </option>
                                <?php
                            }
                        }
                        ?>
                    </select>

					<div id="addons-container">
										</div>

					from 9:30am - 10:00am with

											<input type="hidden" name="calendar" value="1856907" /> frank
															</span>
                </div>
            </div>
            <div class="row appt-heading">
                <div class="col-sm-4">
                    9:30am - 10:00am
                </div>
                <div class="col-sm-7">

                    <span class="field-rendered edit-appointment">albert asd</span>
                    <span class="field-input">
					<input type="text" class="form-control" autocomplete="off" name="first_name" maxlength="40" value="albert" />
					<input type="text" class="form-control" autocomplete="off" name="last_name" maxlength="40" value="asd" />
				</span>
                </div>
            </div>
            <div class="row appt-info">
                <div class="col-sm-4 row-label">Phone</div>
                <div class="col-sm-8">
				<span class="field-rendered">
					<a href="tel:asd" class="real-link hidden-print">asd</a>
					<span class="visible-print">asd</span>
									</span>
                    <span class="field-input">
					<input type="text" class="form-control" autocomplete="off" name="phone" size="15" maxlength="64" value="asd" />
				</span>
                </div>
            </div>
            <div class="row appt-info">
                <div class="col-sm-4 row-label">E-mail</div>
                <div class="col-sm-8">
				<span class="field-rendered">
					<a href="mailto:asd@adf.com" class="real-link hidden-print">asd@adf.com</a>
					<span class="visible-print">asd@adf.com</span>
<!--											<i class="icon-warning-sign text-danger" data-toggle="tooltip" title="Failed: Dropped. See details under View all changes and notifications sent."></i>-->
									</span>
                    <span class="field-input">
					<input type="email" class="form-control" autocomplete="off" name="email" size="25" maxlength="128" value="asd@adf.com" />
				</span>
                </div>
            </div>
            <div class="row appt-info">
                <div class="col-sm-4 row-label">Time zone</div>
                <div class="col-sm-8">
                    (GMT-5:00) Eastern Time
                </div>
            </div>

            <div class="row appt-info">
                <div class="col-xs-12 text-muted field-rendered margin-top">
                    Scheduled by client logged in as asd@adf.com on February 21, 2018 10:06pm<br /><a href="appointments.php?action=apptLog&id=172679472" class="detail-nav-link">View all changes &amp; notifications sent &raquo;</a>
                </div>
            </div>

            <div class="row appt-info">
                <div class="col-xs-12">
				<span class="field-rendered">

				</span>
                    <span class="field-input">
					<a href="#" class="pull-right btn-link cancel-appointment-edit">cancel</a>
					<input type="submit" value="Save Changes" data-loading-text="Saving..." class="btn btn-default" />
				</span>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <h3>Notes</h3>
        <div class="form-field show-on-hover-container">
            <div class="field-name" data-toggle="tooltip" title="Client mentioned they love jamba juice? Put that kind of stuff here so you can be thoughtful later. ">Notes about this appointment</div>
            <span class="field-rendered edit-appointment edit-appointment-notes">
			<em>No notes</em>
			<a href="#" class="btn btn-inverse btn-bordered btn-sm show-on-hover margin-left"><i class="icon-pencil"></i> Edit</a>
		</span>
            <span class="field-input">
			<textarea rows="5" class="form-control" style="width:100%" id="appt-notes" name="notes" placeholder="Private notes about appointment" maxlength="65535"></textarea>
			<input type="submit" value="Save Changes" data-loading-text="Saving..." class="btn btn-default" />
		</span>
        </div>

        <div class="form-field show-on-hover-container">
            <div class="field-name">Notes about this client</div>
            <span class="field-rendered">
			<em>No notes</em>
			<a href="clients.php?action=detail&firstName=albert&lastName=asd&phone=asd&backto=172679472" class="detail-nav-link btn btn-inverse btn-bordered btn-sm show-on-hover"><i class="icon-user"></i> View Client History</a>
		</span>
            <span class="field-input">
			<div class="">
				Notes about this client that show on all of their appointments<br />can be edited in their
				<a href="clients.php?action=detail&firstName=albert&lastName=asd&phone=asd&backto=172679472" class="detail-nav-link btn btn-inverse btn-bordered btn-xs"><i class="icon-user"></i> History</a>
			</div>

		</span>
        </div>


        <h3>History</h3>
        <div class="row">
            <div class="col-md-6 form-field">
                <div class="field-name">Previous Appointment</div>
                <div class="field-value">
                    <?php
                    echo $curLead['lf_first_name'];
                    $appDateTime = $curLead['td_request_date'].' '.$curLead['td_request_time'];
                    $preAppSql = "select id, td_request_date , td_request_time from leads WHERE service_type = 'service-department' AND td_request_date < '".date('Y-m-d H:i:s',strtotime($appDateTime))."' and siteuser_id = '".$curLead['clientID']."' order by td_request_date desc";
                    $preAppList = $db->queryArray($preAppSql);
                    if($preAppList != null) {
                        if (count($preAppList) > 1) {
                            ?>
                            <br/>
                            <a href="book-appointments.php?action=detail&id=<?php echo $preAppList[1]['id']; ?> ?backto=l:0"
                               class="detail-nav-link btn btn-inverse btn-bordered margin-top margin-bottom hidden-print"><i
                                        class="icon-chevron-left"></i> <?php echo date('F d, Y', strtotime($preAppList[1]['td_request_date'])); ?>
                                F at <?php echo date('H:s a', strtotime($preAppList[1]['td_request_time'])); ?> </a>

                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
            <div class="col-md-6 form-field">
                <div class="field-name">Next Appointment</div>
                <div class="field-value">
                    <?php
                    $nextAppSql = "select id, td_request_date , td_request_time from leads WHERE service_type = 'service-department' AND td_request_date > '".date('Y-m-d H:i:s',strtotime($appDateTime))."' and siteuser_id = '".$curLead['clientID']."' order by td_request_date desc";
                    $nextAppList = $db->queryArray($nextAppSql);
                    if($nextAppList != null) {
                        ?>
                        Consultation
                        <br/>
                        <a href="book-appointments.php?action=detail&id=<?php echo $nextAppList[0]['id']; ?>?backto=l:0"
                           class="detail-nav-link btn btn-inverse btn-bordered margin-top margin-bottom hidden-print"><?php echo date('F d, Y', strtotime($nextAppList[0]['td_request_date']));?>
                            at  <?php echo date('H:s a', strtotime($nextAppList[0]['td_request_time'])); ?><i class="icon-chevron-right"></i></a>
                        <?php
                    }
                    else {
                        ?>
                        <a href="book-appointments.php?action=new&amp;firstName=<?php echo $curLead['lf_first_name'];?>&amp;lastName=<?php echo $curLead['lf_last_name'];?>&amp;phone=<?php echo $curLead['phone'];?>&amp;email=<?php echo $curLead['email'];?>&amp;timezone=America%2FNew_York&amp;appointmentType=<?php echo $curLead['rq_pack_id'];?>"
                           class="btn btn-inverse btn-bordered detail-nav-link margin-top margin-bottom hidden-print"><i
                                    class="icon-time"></i> Schedule New Appointment</a>
                        <?php
                    }
                    ?>
                </div>
            </div>
            <div class="col-xs-12 form-field">
                <!--				<a href="book-clients.php?action=detail&firstName=--><?php //echo $curLead['lf_first_name'];?><!--&lastName=--><?php //echo $curLead['lf_last_name'];?><!--&phone=--><?php //echo $curLead['phone'];?><!--&backto=--><?php //echo $curLead['id'];?><!--" class="detail-nav-link">View all 14 appointments &raquo;</a>-->
            </div>
        </div>
    </div>
</form>





<script type="text/javascript">
</script>



