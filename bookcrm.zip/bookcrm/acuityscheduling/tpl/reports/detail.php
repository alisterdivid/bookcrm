<?php
$report     = new PTBookReport();
$dateArrange = $report->getDateArrange();

$_POST["type"] = isset($_POST["type"])? $_POST["type"]  : (isset($_SESSION[PTBookReport::SESSION_REPORT])&& $_SESSION[PTBookReport::SESSION_REPORT] ? $_SESSION[PTBookReport::SESSION_REPORT] : $dateArrange[4]["value"]);

if (isset($_POST["type"]) && $_POST["type"]){
	if ($_POST["type"] == "custom"){
		$startDate = $_POST["startDate"];
		$endDate = $_POST["endDate"];
		$report->setStartAndEnd($startDate, $endDate);
	}else{
		foreach ($dateArrange as $item){
			if ($item["value"] == $_POST["type"]){
				$report->setStartAndEnd($item["startDate"], $item["endDate"]);
			}
		}
	}
}elseif (isset($_POST["type"]) && $_POST["type"] == ""){
	$maxMinDate = $report->getMaxMinDate();
	$report->setStartAndEnd($maxMinDate["minDate"], $maxMinDate["maxDate"]);
}

$appList = $report->getAppList();
?>
<?php
foreach ($appList as $item){
    ?>
    <h3><?php echo date( 'F j, Y', strtotime($item["date"]) );?></h3>
    <?php
    $detailList = $report->getAppListByDay($item["date"]);
    foreach ($detailList as $dItem){
    ?>
    <div class="calendar-appt ">
        <div class="row appt-details" style="box-shadow: inset 5px 0 0 0 #3176ca;">
            <div class="col-xs-12">
                <span class="appt-datetime"><?php echo date( 'l, F j, Y', strtotime($dItem["apDate"]) );?></span>
<!--                <span class="appt-duration">60 MIN</span>-->

                <div class="pull-right is-paid">
                </div>
            </div>
        </div>

        <div class="row appt-heading" data-appointment-id="<?php echo $dItem["apId"];?>" style="box-shadow: inset 5px 0 0 0 #3176ca;">
            <div class="col-xs-12">
                <a class="btn-link detail-nav-link appt-time margin-right" href="book-appointments.php?action=detail&id=<?php echo $dItem["apId"];?>&backto="><?php echo $dItem["apTime"];?></a>
                <span class="appt-client-name">
																		<a class="btn-link detail-nav-link" href="book-appointments.php?action=detail&id=<?php echo $dItem["apId"];?>&backto="><?php echo $dItem["clFirstName"]." ".$dItem["clLastName"]?></a>
					</span>
            </div>
        </div>

        <div class="row appt-details" style="box-shadow: inset 5px 0 0 0 #3176ca;">
            <div class="col-xs-12">
                Service
                &mdash;
	            <?php echo $dItem["svName"];?>
                <br />
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
	            <?php echo $dItem["apComment"];?>
            </div>
        </div>
    </div>
    <?php
    }
}
?>