Timezone = (function(){
	function getTimezoneName(timezoneSelect) {
		var tz = jstz.determine();

		if (!tz) {
			if (typeof trackJs != 'undefined' && typeof JSON != 'undefined') {
				trackJs.track('Client time zone was not found. jstz.determine() output = ' + JSON.stringify(tz));
			}
			return '';
		}

		var name = tz.name();
		name = replaceAmbiguities(name, timezoneSelect);

		if (typeof Intl == 'undefined' || typeof Intl.DateTimeFormat == 'undefined') {
			// No intl support, resolve ambiguous zones in favor of business

			// jstz detects Shanghai, could be Perth or Singapore
			if (name == 'Asia/Shanghai' && (ownerTz == 'Australia/Perth' || ownerTz == 'Asia/Singapore')) {
				return ownerTz;
			}
		}

		return name;
	}

	// These are time zones that have been appearing that are not in our list
	// This will map them to time zones that ARE in our list - may need some constant updating when new time zones are
	// detected. They are being tracked.
	function replaceAmbiguities(timezone, timezoneSelect) {
		// Checking America/Los_Angeles specifically just to check if this is coming in as an object list of timezones
		// or a select field. If it's an object list then it will have America/Los_Angeles in there. Could have used
		// any time zone instead of America/Los_Angeles
		if ('America/Los_Angeles' in timezoneSelect) {
			var exists = timezone in timezoneSelect;
		} else {
			var exists = timezoneSelect.find('option[value="' + timezone +'"]').length > 0;
		}
		if (exists) {
			return timezone;
		}

		switch(timezone) {
			case 'UTC':
			case 'Etc/UTC':
				return 'Etc/GMT';
				break;
			case 'America/Detroit':
			case 'America/Indianapolis':
			case 'America/Indiana/Indianapolis':
			case 'America/Kentucky/Monticello':
			case 'America/Kentucky/Louisville':
			case 'America/Louisville':
			case 'America/Indiana/Vincennes':
			case 'US/Eastern':
			case 'America/Indiana/Petersburg':
				return 'America/New_York';
				break;
			case 'America/Menominee':
			case 'America/Indiana/Tell_City':
			case 'America/North_Dakota/Center':
				return 'America/Chicago';
				break;
			case 'US/Pacific':
				return 'America/Los_Angeles';
				break;
			case 'America/Boise':
				return 'America/Denver';
				break;
			case 'America/Juneau':
			case 'America/Nome':
			case 'America/Sitka':
				return 'America/Anchorage'
				break;
			case 'America/Buenos_Aires':
			case 'America/Cordoba':
			case 'America/Catamarca':
			case 'America/Argentina/Salta':
				return 'America/Argentina/Buenos_Aires';
				break;
			case 'America/Bahia_Banderas':
			case 'America/Monterrey':
			case 'America/Merida':
			case 'America/Matamoros':
				return 'America/Mexico_City';
				break;
			case 'America/Moncton':
			case 'America/Goose_Bay':
			case 'America/Glace_Bay':
				return 'America/Halifax';
				break;
			case 'America/Thunder_Bay':
				return 'America/Toronto';
				break;
			case 'America/Dawson':
			case 'America/Creston':
				return 'America/Dawson_Creek';
				break;
			case 'America/Coral_Harbour':
				return 'America/Winnipeg';
				break;
			case 'America/Chihuahua':
			case 'America/Ojinaga':
			case 'America/Santa_Isabel':
				return 'America/Mazatlan';
				break;
			case 'America/St_Barthelemy':
				return 'Atlantic/Stanley';
				break;
			case 'America/Marigot':
				return 'America/Puerto_Rico';
				break;
			case 'America/Kralendijk':
				return 'America/Curacao';
				break;
			case 'Europe/Bratislava':
			case 'Europe/Ljubljana':
			case 'Europe/Sarajevo':
			case 'Europe/Zagreb':
			case 'Europe/Skopje':
			case 'Europe/Vatican':
			case 'Europe/Podgorica':
				return 'Europe/Belgrade';
				break;
			case 'Europe/Volgograd':
				return 'Europe/Moscow';
				break;
			case 'Europe/Jersey':
			case 'Europe/Isle_of_Man':
				return 'Europe/London';
				break;
			case 'Asia/Kolkata':
				return 'Asia/Calcutta';
				break;
			case 'Asia/Novosibirsk':
			case 'Asia/Barnaul':
			case 'Asia/Tomsk':
				return 'Asia/Krasnoyarsk';
				break;
			case 'Asia/Yangon':
				return 'Asia/Rangoon';
				break;
			case 'Asia/Kathmandu':
				return 'Asia/Katmandu';
				break;
			case 'Asia/Ho_Chi_Minh':
				return 'Asia/Saigon';
				break;
			case 'Atlantic/Faeroe':
				return 'Atlantic/Faroe';
				break;
			case 'Asia/Hebron':
				return 'Asia/Amman';
				break;
			case 'Asia/Chita':
				return 'Asia/Yakutsk';
				break;
			case 'Asia/Kuching':
				return 'Asia/Kuala_Lumpur';
				break;
			case 'Africa/Juba':
				return 'Africa/Kampala';
				break;
		}

		// We don't want to log these unreliable timezones - we know they exist
		if (timezone.indexOf('Etc/GMT') !== -1) {
			var unreliableTimezone = true;
		} else {
			var unreliableTimezone = false;
		}

		if (typeof trackJs != 'undefined' && !unreliableTimezone) {
			trackJs.track('Detected time zone not in list. found time zone = ' + timezone);
		}

		return ownerTz;
	}

	function shouldDetectTimezone()
	{
		return typeof requireTZ!='undefined' && requireTZ && autodetect_timezone;
	}

	return {
		getTimezoneName: getTimezoneName,
		shouldDetectTimezone: shouldDetectTimezone
	}
})();