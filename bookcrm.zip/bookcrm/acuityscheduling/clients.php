<?php
global $view, $ajax;
include('tpl/header.php');
?>
<div class="container fast-animated main-nav-display sticky-main-nav-display" id="container-wrapper">

	<div class="pull-right help-top-container">
		<a href="book-appointments.php" class="btn btn-inverse btn-bordered btn-show-welcome-guide hidden-xs" style="display:none">Show Walkthrough</a>

		<script id="support-form-template" type="text/x-template">
			<div class="content">
				<a href="book-appointments.php" data-pjax class="btn btn-inverse btn-bordered btn-top btn-detail-back hidden-print"><i class="icon-chevron-left"></i> Back</a>

				<div class="row">
					<div class="col-xs-12">
						<form action="help.php?action=send&backto=thanks" class="support-form form-horizontal detail-nav-link margin-top" method="POST">
							<input type="hidden" name="fullstory" id="fullstory" value="" />
							<div class="form-group">
								<label class="control-label col-xs-2">Your<br />E-mail</label>
								<div class="col-xs-10">
									<input type="email" class="form-control validate required" id="email" name="email" value="softensoftwares@gmail.com" />
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-xs-2">Subject</label>
								<div class="col-xs-10">
									<input type="text" class="form-control" id="help-subject" name="subject" value="" />
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-xs-2">Message</label>
								<div class="col-xs-10">
									<textarea class="form-control validate required" name="message" id="help-message" rows="10"></textarea>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2"></label>
								<div class="col-sm-9">
									<select name="feeling" id="help-feeling" class="form-control inline-field">
										<option value="">Right now I'm...</option>
										<option value="Smiling">Smiling</option>
										<option value="Furrowing my eyebrows">Furrowing my eyebrows</option>
										<option value="Making a mean face">Making a mean face</option>
										<option value="Stroking my chin with curiosity">Stroking my chin with curiosity</option>
										<option value="I don’t make faces">I don’t make faces</option>
										<option value="other">Other...</option>
									</select>
									<input type="text" name="feeling_other" id="help-feeling-other" style="display:none" class="form-control" placeholder="¯\_(ツ)_/¯" />
								</div>
							</div>
							<div class="form-group">
								<div class="col-xs-10 ">
									<input type="submit" class="btn btn-default" value="Send Message" />
									<div class="margin-top text-muted">
										Or e-mail us at <a href="mailto:support@acuityscheduling.com" class="real-link">support@acuityscheduling.com</a>
									</div>
								</div>
							</div>
						</form>		</div>
				</div>
			</div>
		</script>


		<script type="text/javascript">
			justCompletedSetupStep = '';
		</script>
	</div>

    <?php
    $selParentTitle = 'appointments';
    $curpage = 'clients';

    include('tpl/sidebar.php');
    ?>
	<div class="row preferences-container">

		<div class="content default">

			<h1 class="page-title">
				Client List <span class="page-description margin-left">
                    <?php
                        $clientSql = "select * from tbl_book_clients";
                        $clientList = $db->queryArray($clientSql);

                        echo count($clientList);

                    ?>
                    clients</span>
			</h1>


			<div class="pane error-flash alert alert-danger" style="display:none"></div>

			<div class="client-details-pane"></div>
			<div class="client-list-standalone">

				<p class="body-italic-small import-client-link">Want to <a href="book-preferences.php?action=importexport">Import a Client List?</a></p>


				<div class="menu-nav client-nav" data-detail-cache="clients">
					<div class="client-list-heading">

						<a href="#" class="add-one-client pull-right btn btn-inverse btn-bordered"><i class="icon-plus-sign"></i> Add<span class="hidden-xs"> Client</span></a>
						<form id="client-search" action="#">
							<div class="search-group">
								<input type="text" class="form-control" placeholder="Search for clients...">
								<span class="search-icon-addon"><i class="icon-search"></i></span>
							</div>
							<div class="client-filter-container margin-top">
								<div class="client-filter-summary body-italic-small">
									<span class="client-filter-showing-text">Showing all clients</span> (<a href="#" class="client-filter-edit-btn">change</a>)
								</div>
								<div class="client-filter-edit" style="display:none">
									Only show clients who scheduled within the last
									<select name="filterAge" class="form-control inline-field">
										<option label="show all clients" value="">show all clients</option>
										<option label="3 months" value="-90">3 months</option>
										<option label="6 months" value="-180">6 months</option>
										<option label="1 year" value="-365">1 year</option>
										<option label="2 years" value="-730">2 years</option>
										<option label="3 years" value="-1095">3 years</option>
										<option label="4 years" value="-1460">4 years</option>

									</select>
								</div>
							</div>
						</form>

					</div>


					<div id="client-search-results" class="">
                        <?php

                            $numRange = range('0', '9');
                            foreach ($numRange as $number)
                            {
                                $firstIndex = true;
                                for($i = 0; $i < count($clientList); $i++){
                                    $firstName = $clientList[$i]['firstName'];
                                    if(strval($number) == substr($firstName,0,1)){
                                        if($firstIndex) {
                                            $firstIndex = false;
                                            ?>
                                            <div class="search-letter-group has-results">
                                            <h3><a name="1"></a><?php echo $number; ?></h3>
                                            <?php
                                        }
                                            ?>
                                            <ul class="client-list">
                                                <li>
                                                    <a href="book-appointments.php?action=new&timezone=America%2FNew_York&firstName=<?php echo $clientList[$i]['firstName'];?>&lastName=<?php echo $clientList[$i]['lastName'];?>&phone=<?php echo $clientList[$i]['phone'];?>&email=<?php echo $clientList[$i]['email'];?>" class="btn btn-xs no-chevron pull-right visible-md visible-lg btn-menu-action detail-nav-link" title="Schedule Appointment">
                                                        <i class="icon-time"></i></a>
                                                    <a href="book-clients.php?action=detail&firstName=<?php echo $clientList[$i]['firstName'];?>&lastName=<?php echo $clientList[$i]['lastName'];?>&phone=<?php echo $clientList[$i]['phone'];?>&backto=book-clients.php" class="show-client-btn">
                                                        <span class="client-name"><?php echo $clientList[$i]['firstName'];?>, <?php echo $clientList[$i]['lastName'];?></span>
                                                    </a>

                                                </li>
                                            </ul>
                        <?php
                                    }
                                }
                                if(!$firstIndex){
                                    echo '</div>';
                                }
                            }
                            $azRange = range('A', 'Z');
                            foreach ($azRange as $letter)
                            {
                                $firstIndex = true;
                                for($i = 0; $i < count($clientList); $i++){
                                    $firstName = $clientList[$i]['firstName'];
                                    if(strval($letter) == strtoupper (substr($firstName,0,1))){
                                        if($firstIndex) {
                                              $firstIndex = false;
                                ?>
                                                <div class="search-letter-group has-results">
                                                    <h3><a name="1"></a><?php echo $letter; ?></h3>
                                                    <?php
                                                    }
                                                    ?>
                                                    <ul class="client-list">
                                                        <li>
                                                            <a href="book-appointments.php?action=new&timezone=America%2FNew_York&firstName=<?php echo $clientList[$i]['firstName'];?>&lastName=<?php echo $clientList[$i]['lastName'];?>&phone=<?php echo $clientList[$i]['phone'];?>&email=<?php echo $clientList[$i]['email'];?>" class="btn btn-xs no-chevron pull-right visible-md visible-lg btn-menu-action detail-nav-link" title="Schedule Appointment">
                                                                <i class="icon-time"></i></a>
                                                            <a href="book-clients.php?action=detail&firstName=<?php echo $clientList[$i]['firstName'];?>&lastName=<?php echo $clientList[$i]['lastName'];?>&phone=<?php echo $clientList[$i]['phone'];?>&backto=book-clients.php" class="show-client-btn">
                                                                <span class="client-name"><?php echo $clientList[$i]['firstName'];?>, <?php echo $clientList[$i]['lastName'];?></span>
                                                            </a>

                                                        </li>
                                                    </ul>
                                                    <?php
                                                    }
                                                    }
                                                    if(!$firstIndex){
                                                        echo '</div>';
                                                    }
                            }
                        ?>
					</div>

				</div>

				<script id="add-client-template" type="text/x-template">
					<div class="content">
						<a href="#" data-pjax class="btn btn-inverse btn-bordered btn-top btn-detail-back back-to-clients hidden-print"><i class="icon-chevron-left"></i> Back</a>

						<div class="row">
							<div class="col-xs-12">
								<form action="book-clients.php?action=insert&backto=clients&refresh=1" class="add-client-form form-horizontal detail-nav-link margin-top" method="POST" novalidate>
									<input type="hidden" name="__csrf_magic" value="aXhiN1FxWVRWbUE3SWVkSUN0UkZiL0pjdlpCcm5VL0NDcjVqNGR1VHhNWT06eyJ1IjoxNTAzNjY1MSwieCI6MTUxOTYxOTgzOSwibiI6IjBmOWE3MGVmIn0=" />
									<div class="form-group">
										<label class="control-label col-xs-2 subhead-ac">First Name</label>
										<div class="col-xs-8">
											<input type="text" class="form-control validate required" id="firstName" title="First Name" name="firstName" value="" />
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-xs-2 subhead-ac">Last Name</label>
										<div class="col-xs-8">
											<input type="text" class="form-control validate required" id="lastName" title="Last Name" name="lastName" value="" size="35" />
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-xs-2 subhead-ac">Phone</label>
										<div class="col-xs-8">
											<input type="text" class="form-control" title="Phone" name="phone" value="" />
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-xs-2 subhead-ac">E-mail</label>
										<div class="col-xs-8">
											<input type="email" class="form-control" name="email" title="E-mail" value="" size="35" />
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-xs-2 subhead-ac">Notes</label>
										<div class="col-xs-8">
											<textarea rows="5" class="form-control" name="notes" title="Notes" value="" placeholder="Private notes about client" />
										</div>
									</div>
									<div class="form-group">
										<div class="col-xs-8">
											<input type="submit" class="btn btn-default" value="Add Client" />
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</script>
			</div>

		</div>
	</div>
</div>


</div>
</div>


<script type="text/javascript">
	window._trackJs = {
		token: "fbe49d5762cf4560847a05563bd04720",
		application: "admin",
		enabled: !(window.location.host.indexOf('127.0.0.1') >= 0),
		onError: function (payload, error) {
			var ignore = [/olark/, /ssl\.google-analytics/, /events\.olark\.com/, /assets\.customer\.io/, /error - getDetails/, /Error loading script/, /onContainerTouchMove/, /onContainerTouchStart/, /\[object Event\]/, /setHintValue/, /Type mismatch/, /Error calling method on NPObject/, /Out of memory/, /Argumento o llamada a procedimiento/, /__gCrWeb/, /undefined.*updatedAt/, /t is undefined/, /updatedAt.*undefined/, /Unspecified error/, /Redactor/];
			for (var i=0; i<ignore.length; i++) {
				if (ignore[i].test(payload.message)) return false;
			}

			return true;
		}
	};
</script>



<script>
	(function(d) {
		var config = {
				kitId: 'zza8qgp',
				scriptTimeout: 3000,
				async: true
			},
			h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
	})(document);
</script>


<!--[if lt IE 9]>
<script src="acuityscheduling/responsive/js/respond.min.js"></script>
<script src="acuityscheduling/js/tiny_mce/tiny_mce.js"></script>
<![endif]-->
<script type="text/javascript">
	window.CURRENT_VERSION=875;
	window.USERID='15036651';
	window.CLIENT_PAGE='https://app.acuityscheduling.com/schedule.php?owner=15036651';

</script>
<script type="text/javascript" src="acuityscheduling/responsive/js/all.min-875.js"></script>

<script type="text/javascript">if (typeof window.trackJs != 'undefined') window.trackJs.configure({userId: window.USERID});</script>



<script type="text/javascript">
	if (typeof _cio == 'undefined') {
		var _cio = _cio || [];
		(function() {
			var a,b,c;a=function(f){return function(){_cio.push([f].
			concat(Array.prototype.slice.call(arguments,0)))}};b=["load","identify",
				"sidentify","track","page"];for(c=0;c<b.length;c++){_cio[b[c]]=a(b[c])};
			var t = document.createElement('script'),
				s = document.getElementsByTagName('script')[0];
			t.async = true;
			t.id    = 'cio-tracker';
			t.setAttribute('data-site-id', '265a473ee947bb20fbb1');
			t.src = 'https://assets.customer.io/assets/track.js';
			s.parentNode.insertBefore(t, s);
		})();
	}
</script>

<script type="text/javascript">
	if (typeof amplitude == 'undefined') {
		(function(e,t){var n=e.amplitude||{_q:[],_iq:{}};var r=t.createElement("script");r.type="text/javascript";
			r.async=true;r.src="libs/amplitude-3.4.0-min.gz.js";
			r.onload=function(){e.amplitude.runQueuedFunctions()};var i=t.getElementsByTagName("script")[0];
			i.parentNode.insertBefore(r,i);function s(e,t){e.prototype[t]=function(){this._q.push([t].concat(Array.prototype.slice.call(arguments,0)));
				return this}}var o=function(){this._q=[];return this};var a=["add","append","clearAll","prepend","set","setOnce","unset"];
			for(var u=0;u<a.length;u++){s(o,a[u])}n.Identify=o;var c=function(){this._q=[];return this;
			};var p=["setProductId","setQuantity","setPrice","setRevenueType","setEventProperties"];
			for(var l=0;l<p.length;l++){s(c,p[l])}n.Revenue=c;var d=["init","logEvent","logRevenue","setUserId","setUserProperties","setOptOut","setVersionName","setDomain","setDeviceId","setGlobalUserProperties","identify","clearUserProperties","setGroup","logRevenueV2","regenerateDeviceId","logEventWithTimestamp","logEventWithGroups"];
			function v(e){function t(t){e[t]=function(){e._q.push([t].concat(Array.prototype.slice.call(arguments,0)));
			}}for(var n=0;n<d.length;n++){t(d[n])}}v(n);n.getInstance=function(e){e=(!e||e.length===0?"$default_instance":e).toLowerCase();
				if(!n._iq.hasOwnProperty(e)){n._iq[e]={_q:[]};v(n._iq[e])}return n._iq[e]};e.amplitude=n;
		})(window,document);
	}
	amplitude.getInstance().init("5bf377fa898a63e32d803ce376dbf310", '15036651', {includeUtm: true, includeReferrer: true});
</script>

<script src="https://apis.google.com/js/platform.js?onload=renderOptIn" async defer></script>
<script type="text/javascript">


	var u = {
		id: '15036651',
		email: 'softensoftwares@gmail.com',
		'$email': 'softensoftwares@gmail.com',
		created_at: 1516802400,
		business_name: 'uniqks',
		'$first_name': 'uniqks',
		keyword: 'Capterra',
		plan: 'Free',
		schedulingURL: 'https://app.acuityscheduling.com/schedule.php?owner=15036651',
		days_since_created: 29.609247685185,
		date_expired: 1518066000,


		source: 't'

	};

	_cio.identify(u);

	u['$created'] = u.created_at;


	amplitude.getInstance().setUserProperties({
		plan: u.plan,
		created_at: u.created_at,
		days_since_created: u.days_since_created,
		source: u.keyword
	});


	//begin Wootric code

	window.wootricSettings = {
		email: u.email,
		external_id: u.id,
		created_at: u.created_at,
		account_token: 'NPS-c8ffa412'
	};
</script>

<script type="text/javascript" src="https://disutgh7q0ncc.cloudfront.net/beacon.js"></script>
<script type="text/javascript">
	// This loads the Wootric survey
	if (typeof window.wootric === 'function') window.wootric('run');
</script>
<!-- end Wootric code -->

<script type="text/javascript">


	window['_fs_debug'] = false;
	window['_fs_host'] = 'www.fullstory.com';
	window['_fs_org'] = 'BdR';
	(function(m,n,e,t,l,o,g,y){
		g=m[e]=function(a,b){g.q?g.q.push([a,b]):g._api(a,b);};g.q=[];
		o=n.createElement(t);o.async=1;o.src='https://'+_fs_host+'/s/fs.js';
		y=n.getElementsByTagName(t)[0];y.parentNode.insertBefore(o,y);
		g.identify=function(i,v){g(l,{uid:i});if(v)g(l,v)};g.setUserVars=function(v){FS(l,v)};
		g.setSessionVars=function(v){FS('session',v)};g.setPageVars=function(v){FS('page',v)};
	})(window,document,'FS','script','user');

	FS.identify('15036651', {
		email: 'softensoftwares@gmail.com',
		displayName: u.business_name
	});



</script>


<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	ga('create', 'UA-1071942-1', 'auto');
	ga('send', 'pageview');

</script>
<script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"5649288"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script><noscript><img src="//bat.bing.com/action/0?ti=5649288&Ver=2" height="0" width="0" style="display:none; visibility: hidden;" /></noscript>
<!-- Facebook Pixel Code -->
<script>
	!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
		n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
		n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
		t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
		document,'script','https://connect.facebook.net/en_US/fbevents.js');
	fbq('set', 'autoConfig', 'false', '1210643745657267');
	fbq('init', '1210643745657267'); // Insert your pixel ID here.
	fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
               src="https://www.facebook.com/tr?id=1210643745657267&ev=PageView&noscript=1"
	/></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->







<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"e7043daa18","applicationID":"11269421","transactionName":"ZlQBZxYHXBACUhcMXl8eNkENSVEPClQNEUIfQQtD","queueTime":0,"applicationTime":72,"atts":"ShMWEV4dT09BUEFfSkxM","errorBeacon":"bam.nr-data.net","agent":""}</script></body>
</html>


<script type="text/javascript">
	$('#container-wrapper').removeClass('calendar-container-wrapper');</script>

<script type="text/javascript">
    <?php
    if(isset($_REQUEST['print'])){
    ?>
    $(function () {
        track('print');
        window.print();
    });
    <?php
    }
    ?>
</script>
