<?php

if ($action == "importexport"){
    include ("tpl/preferences/importexport.php");
}