<?php
$action = isset($_REQUEST["action"]) ? $_REQUEST["action"] : "";
if ($action == "detail"){
	include('tpl/appointments/detail.php');
}elseif ($action == "showCalendar"){
	include('tpl/schedule/showCalendar.php');
}elseif ($action == "reschedule"){
	include('tpl/schedule/reschedule.php');
}elseif ($action == "ajaxCal"){
	include('tpl/schedule/ajaxCal.php');
}elseif ($action == "backview"){
	include('tpl/schedule/backview.php');
}