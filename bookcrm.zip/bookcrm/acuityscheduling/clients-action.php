<?php
global $ajax;

$action = isset($_REQUEST["action"]) ? $_REQUEST["action"] : "";
if (isset($_REQUEST["action"])){
    if ($action == "detail"){
        include('tpl/clients/detail.php');
    }
    elseif ($action == 'bulkCancel'){
        include('tpl/clients/bulkCancel.php');
    }
    elseif ($action == 'update'){
        include('tpl/clients/update.php');
    }
    elseif ($action == 'delete'){
        include('tpl/clients/delete.php');
    }
    elseif ($action == 'search'){
        include('tpl/clients/search.php');
    }
    elseif ($action == 'insert'){
        include('tpl/clients/insert.php');
    }
}