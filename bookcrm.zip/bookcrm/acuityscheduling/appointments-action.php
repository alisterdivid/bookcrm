<?php
global $ajax;

$action = isset($_REQUEST["action"]) ? $_REQUEST["action"] : "";
$view = isset($_REQUEST["view"]) ? $_REQUEST["view"] : "thisWeek";
if (isset($_REQUEST["view"])){
	if ($view == "thisWeek"){
	    if(isset($_REQUEST['action']) && ($_REQUEST['action'] == 'ajaxCal')){
            include('tpl/appointments/ajaxCal.php');
        }
        else{
            include('tpl/appointments/thisWeek.php');
        }
	}elseif ($view == "thisMonth"){
        if(isset($_REQUEST['action']) && ($_REQUEST['action'] == 'ajaxCal')){
            include('tpl/appointments/ajaxCal.php');
        }
        else {
            include('tpl/appointments/thisMonth.php');
        }
	}elseif ($view == "day"){
        if(isset($_REQUEST['action']) && ($_REQUEST['action'] == 'ajaxCal')){
            include('tpl/appointments/ajaxCal.php');
        }
        else{
            include('tpl/appointments/day.php');
        }

	}
}elseif (isset($_REQUEST["action"])){
	if ($action == "detail"){
		include('tpl/appointments/detail.php');
	}elseif ($action == "new"){
	    if(isset($_REQUEST['date'])){
            include('tpl/appointments/weekDayNew.php');
        }
        else {
            include('tpl/appointments/new.php');
        }
	}elseif ($action == "reschedule"){
		include('tpl/appointments/reschedule.php');
	}elseif ($action == "ajaxCal"){
		include('tpl/appointments/ajaxCal.php');
	}elseif ($action == "backview"){
        include('tpl/appointments/backview.php');
    }elseif ($action == "insert"){
        include('tpl/appointments/insert.php');
    }elseif ($action == "cancel"){
        include('tpl/appointments/cancel.php');
    }elseif ($action == "updateReschedule"){
        include('tpl/appointments/updateReschedule.php');
    }elseif ($action == "clientdetail"){
        include('tpl/appointments/clientDetail.php');
    }elseif ($action == "bulkReschedule"){
        include('tpl/appointments/bulkReschedule.php');
    }elseif ($action == "updateBulkReschedule"){
        include('tpl/appointments/updateBulkReschedule.php');
    }elseif ($action == "update"){
        include('tpl/appointments/update.php');
    }elseif ($action == "newBlockHtml"){
        include('tpl/appointments/newBlock.php');
    }elseif ($action == "insertBlock"){
        include('tpl/appointments/insertBlock.php');
    }elseif ($action == "apptLog"){
        include('tpl/appointments/apptLog.php');
    }

}else{
	include('tpl/appointments/thisWeek.php');
}
