<?php
global $view, $ajax;
include('tpl/header.php');
?>
<div class="container fast-animated main-nav-display sticky-main-nav-display calendar-container-wrapper" id="container-wrapper">
    <?php
    $selParentTitle = 'appointments';
    $curpage = 'appointment';

    include('tpl/sidebar.php');
    ?>
    <div class="calendar-display">

        <div class="content default">

        <div class="pane error-flash alert alert-danger" style="display:none"></div>
        <div class="appointment-content " id="appointment-content">

            <div class="appointment-list-container">
                <?php
                include('appointments-action.php');
                ?>
            </div>
        </div>
    </div>

    <div class="calendar-actions hidden-print visible-xs visible-sm">
        <div class="btn-group appointment-action-group">
            <a class="btn btn-default detail-nav-link fastjax new-appointment-link" href="book-appointments.php?action=new"><i class="icon-plus-sign"></i> Appointment</a>
            <a class="btn btn-default detail-nav-link btn-block-time fastjax" href="book-appointments.php?action=newBlockHtml&day=2018-02-18"><i></i>  Block</a>
        </div>
    </div>

        <style type="text/css">
            .calendar-loading-text { display: none; }
            .listingTitle{font-size: 1.4em;}
            .timeslot.newHour{font-size: 1.2em}
            .calendar-list-view-container{display:block;}
            .appt-heading{font-size:16px;}
            .main-nav-display#container-wrapper{background: white;}
        </style>


    </div>
</div>


<script type="text/javascript">
	window._trackJs = {
		token: "fbe49d5762cf4560847a05563bd04720",
		application: "admin",
		enabled: !(window.location.host.indexOf('127.0.0.1') >= 0),
		onError: function (payload, error) {
			var ignore = [/olark/, /ssl\.google-analytics/, /events\.olark\.com/, /assets\.customer\.io/, /error - getDetails/, /Error loading script/, /onContainerTouchMove/, /onContainerTouchStart/, /\[object Event\]/, /setHintValue/, /Type mismatch/, /Error calling method on NPObject/, /Out of memory/, /Argumento o llamada a procedimiento/, /__gCrWeb/, /undefined.*updatedAt/, /t is undefined/, /updatedAt.*undefined/, /Unspecified error/, /Redactor/];
			for (var i=0; i<ignore.length; i++) {
				if (ignore[i].test(payload.message)) return false;
			}

			return true;
		}
	};
</script>

<script>
	(function(d) {
		var config = {
				kitId: 'zza8qgp',
				scriptTimeout: 3000,
				async: true
			},
			h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
	})(document);
</script>


<!--[if lt IE 9]>
<script src="acuityscheduling/responsive/js/respond.min.js"></script>
<script src="acuityscheduling/js/tiny_mce/tiny_mce.js"></script>
<![endif]-->
<script type="text/javascript">
	window.CURRENT_VERSION=875;
	window.USERID='15036651';
	window.CLIENT_PAGE='https://app.acuityscheduling.com/schedule.php?owner=15036651';

</script>
<script type="text/javascript" src="acuityscheduling/responsive/js/all.min-875.js"></script>

<script type="text/javascript">if (typeof window.trackJs != 'undefined') window.trackJs.configure({userId: window.USERID});</script>



<script type="text/javascript">
	if (typeof _cio == 'undefined') {
		var _cio = _cio || [];
		(function() {
			var a,b,c;a=function(f){return function(){_cio.push([f].
			concat(Array.prototype.slice.call(arguments,0)))}};b=["load","identify",
				"sidentify","track","page"];for(c=0;c<b.length;c++){_cio[b[c]]=a(b[c])};
			var t = document.createElement('script'),
				s = document.getElementsByTagName('script')[0];
			t.async = true;
			t.id    = 'cio-tracker';
			t.setAttribute('data-site-id', '265a473ee947bb20fbb1');
			t.src = 'https://assets.customer.io/assets/track.js';
			s.parentNode.insertBefore(t, s);
		})();
	}
</script>

<script type="text/javascript">
	if (typeof amplitude == 'undefined') {
		(function(e,t){var n=e.amplitude||{_q:[],_iq:{}};var r=t.createElement("script");r.type="text/javascript";
			r.async=true;r.src="acuityscheduling/libs/amplitude-3.4.0-min.gz.js";
			r.onload=function(){e.amplitude.runQueuedFunctions()};var i=t.getElementsByTagName("script")[0];
			i.parentNode.insertBefore(r,i);function s(e,t){e.prototype[t]=function(){this._q.push([t].concat(Array.prototype.slice.call(arguments,0)));
				return this}}var o=function(){this._q=[];return this};var a=["add","append","clearAll","prepend","set","setOnce","unset"];
			for(var u=0;u<a.length;u++){s(o,a[u])}n.Identify=o;var c=function(){this._q=[];return this;
			};var p=["setProductId","setQuantity","setPrice","setRevenueType","setEventProperties"];
			for(var l=0;l<p.length;l++){s(c,p[l])}n.Revenue=c;var d=["init","logEvent","logRevenue","setUserId","setUserProperties","setOptOut","setVersionName","setDomain","setDeviceId","setGlobalUserProperties","identify","clearUserProperties","setGroup","logRevenueV2","regenerateDeviceId","logEventWithTimestamp","logEventWithGroups"];
			function v(e){function t(t){e[t]=function(){e._q.push([t].concat(Array.prototype.slice.call(arguments,0)));
			}}for(var n=0;n<d.length;n++){t(d[n])}}v(n);n.getInstance=function(e){e=(!e||e.length===0?"$default_instance":e).toLowerCase();
				if(!n._iq.hasOwnProperty(e)){n._iq[e]={_q:[]};v(n._iq[e])}return n._iq[e]};e.amplitude=n;
		})(window,document);
	}
	amplitude.getInstance().init("5bf377fa898a63e32d803ce376dbf310", '15036651', {includeUtm: true, includeReferrer: true});
</script>

<script src="https://apis.google.com/js/platform.js?onload=renderOptIn" async defer></script>
<script type="text/javascript">


	var u = {
		id: '15036651',
		email: 'softensoftwares@gmail.com',
		'$email': 'softensoftwares@gmail.com',
		created_at: 1516802400,
		business_name: 'uniqks',
		'$first_name': 'uniqks',
		keyword: 'Capterra',
		plan: 'Free',
		schedulingURL: 'https://app.acuityscheduling.com/schedule.php?owner=15036651',
		days_since_created: 29.584918981481,
		date_expired: 1518066000,

		affiliateLink: 'https://acuityscheduling.com/?kw=YToxNTAzNjY1MQ%3D%3D',
		source: 't'

	};

	_cio.identify(u);

	u['$created'] = u.created_at;


	amplitude.getInstance().setUserProperties({
		plan: u.plan,
		created_at: u.created_at,
		days_since_created: u.days_since_created,
		source: u.keyword
	});


	//begin Wootric code

	window.wootricSettings = {
		email: u.email,
		external_id: u.id,
		created_at: u.created_at,
		account_token: 'NPS-c8ffa412'
	};
</script>

<script type="text/javascript" src="https://disutgh7q0ncc.cloudfront.net/beacon.js"></script>
<script type="text/javascript">
	// This loads the Wootric survey
	if (typeof window.wootric === 'function') window.wootric('run');
</script>
<!-- end Wootric code -->

<script type="text/javascript">


	window['_fs_debug'] = false;
	window['_fs_host'] = 'www.fullstory.com';
	window['_fs_org'] = 'BdR';
	(function(m,n,e,t,l,o,g,y){
		g=m[e]=function(a,b){g.q?g.q.push([a,b]):g._api(a,b);};g.q=[];
		o=n.createElement(t);o.async=1;o.src='https://'+_fs_host+'/s/fs.js';
		y=n.getElementsByTagName(t)[0];y.parentNode.insertBefore(o,y);
		g.identify=function(i,v){g(l,{uid:i});if(v)g(l,v)};g.setUserVars=function(v){FS(l,v)};
		g.setSessionVars=function(v){FS('session',v)};g.setPageVars=function(v){FS('page',v)};
	})(window,document,'FS','script','user');

	FS.identify('15036651', {
		email: 'softensoftwares@gmail.com',
		displayName: u.business_name
	});



</script>


<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	ga('create', 'UA-1071942-1', 'auto');
	ga('send', 'pageview');

</script>
<script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"5649288"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script><noscript><img src="//bat.bing.com/action/0?ti=5649288&Ver=2" height="0" width="0" style="display:none; visibility: hidden;" /></noscript>
<!-- Facebook Pixel Code -->
<script>
	!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
		n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
		n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
		t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
		document,'script','https://connect.facebook.net/en_US/fbevents.js');
	fbq('set', 'autoConfig', 'false', '1210643745657267');
	fbq('init', '1210643745657267'); // Insert your pixel ID here.
	fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
               src="https://www.facebook.com/tr?id=1210643745657267&ev=PageView&noscript=1"
    /></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->




<script type="text/javascript" src="//static.criteo.net/js/ld/ld.js" async="true">
</script>
<script type="text/javascript">
	window.criteo_q = window.criteo_q || [];
	var deviceType = /iPad/.test(navigator.userAgent) ? "t" :
		/Mobile|iP(hone|od)|Android|BlackBerry|IEMobile|Silk/.test(navigator.userAgent) ? "m"
			: "d";
	window.criteo_q.push(
		{ event: "setAccount", account: 44441 },
		{ event: "setSiteType", type: deviceType },
		{ event: "setEmail", email: 'softensoftwares@gmail.com' },
		{ event: "setData", ui_segment: 1 },
		{ event: "viewItem", item: "1"}
	);
</script>

<?php
    if(isset($_REQUEST['print'])){
        ?>

        <script type="text/javascript">
            $(function () {
                track('print');
                window.print();
});
</script>
<?php
    }
?>



<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"e7043daa18","applicationID":"11269421","transactionName":"ZlQBZxYHXBACUhcMXl8eNkENSVMTE14KC0VcVA1HF0hCCxM=","queueTime":0,"applicationTime":109,"atts":"ShMWEV4dT09BUEFfSkxM","errorBeacon":"bam.nr-data.net","agent":""}</script>

<script type="text/javascript">
	$('#container-wrapper').addClass('calendar-container-wrapper');</script>




 