<?php
$ajax = isset($_REQUEST["ajax"]) ? $_REQUEST["ajax"] : "";
$action = isset($_REQUEST["action"]) ? $_REQUEST["action"] : "";
if (($ajax == "1") || ($action == 'ajaxCal') || ($action == 'getForms')) {
    require_once("core/DB_Connection.php");
    require_once("core/functions.php");
    include ("acuityscheduling/appointments-action.php");
    die();
}
require_once("common/header.php");
?>

<?php include("acuityscheduling/appointments.php"); ?>

<?php

require_once('common/footer.php');

?>
