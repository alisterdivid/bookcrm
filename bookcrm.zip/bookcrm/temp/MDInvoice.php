<?php


class MDInvoice {
	const PAY_METHOD_CREDIT_CARD = "Credit Card";
	const PAY_METHOD_BANK_ACCOUNT = "Bank Account";
	const PAY_METHOD_ZELLE = "Zelle";
	const PAY_METHOD_WIRE = "Wire";
	const PAY_METHOD_BITCOIN = "Bitcoin";
	const PAY_METHOD_LITECOIN = "Litecoin";

	static public $sessionOrder = "invoiceOder";
	static public $statusPending = "Pending";
	static public $statusPaid = "Paid";
	static public $statusActive = "Active";

	const SORT_BY_DONOR_SHORT = array(
		"recent"  => "Recent Supporters",
		"highest" => "Highest"
	);
	const DONOR_LIMIT = 20;

	function __construct() {

	}

	static public function getAllInvoices() {
		global $db;
		$sql    = "SELECT iv.id AS inId,
						iv.in_sid AS inSId,
						iv.us_id AS usId,
						us.us_firstname as usFirstName,
						us.us_lastname as usLastName,
						us.us_website AS usWebsite,
						us.us_facebook AS usFacebook,
						us.us_twitter AS usTwitter,
						us.us_insta AS usInsta,
						iv.in_total_price AS inTPrice,
						iv.in_paid_price AS inPPrice,
						iv.in_status AS inStatus,
						iv.in_paid_yn AS inPaid,
						iv.in_paid_date AS inPaidTime,
						iv.in_isAnonymous as inIsAnonymous,
						iv.in_anonymous AS inAnonymous,
						iv.in_has_exlink AS inHasExLink,
						iv.in_exlink AS inExLink,
						iv.in_website AS inWebsite,
						iv.in_facebook AS inFacebook,
						iv.in_twitter AS inTwitter,
						iv.in_insta AS inInsta,
						iv.ref_id AS refId,
						iv.update_time AS updateTime,
						iv.create_time AS createTime
					FROM md_invoice iv, md_user us
					WHERE us.id = iv.us_id
					ORDER BY iv.create_time DESC";
		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result = [];
		} else {
			$result = MDInvoice::getFullInvoiceData( $result );
		}

		return $result;
	}

	static public function getInvoiceById( $id ) {
		global $db;
		$sql    = "SELECT iv.id AS inId,
						iv.in_sid AS inSId,
						iv.us_id AS usId,
						us.us_firstname as usFirstName,
						us.us_lastname as usLastName,
						us.us_website AS usWebsite,
						us.us_facebook AS usFacebook,
						us.us_twitter AS usTwitter,
						us.us_insta AS usInsta,
						iv.in_total_price AS inTPrice,
						iv.in_paid_price AS inPPrice,
						iv.in_status AS inStatus,
						iv.in_paid_yn AS inPaid,
						iv.in_paid_date AS inPaidTime,
						iv.in_isAnonymous as inIsAnonymous,
						iv.in_anonymous AS inAnonymous,
						iv.in_has_exlink AS inHasExLink,
						iv.in_exlink AS inExLink,
						iv.in_website AS inWebsite,
						iv.in_facebook AS inFacebook,
						iv.in_twitter AS inTwitter,
						iv.in_insta AS inInsta,
						iv.ref_id AS refId,
						iv.update_time AS updateTime,
						iv.create_time AS createTime
					FROM md_invoice iv,  md_user us
			      	WHERE iv.id = '$id' 
			      	AND us.id = iv.us_id";
		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result[0] = [];
		} else {
			$result = MDInvoice::getFullInvoiceData( $result );
		}

		return $result[0];
	}

	static public function getInvoiceByInSId( $inSId ) {
		global $db;
		$sql    = "SELECT iv.id AS inId,
						iv.in_sid AS inSId,
						iv.us_id AS usId,
						us.us_firstname as usFirstName,
						us.us_lastname as usLastName,
						us.us_website AS usWebsite,
						us.us_facebook AS usFacebook,
						us.us_twitter AS usTwitter,
						us.us_insta AS usInsta,
						iv.in_total_price AS inTPrice,
						iv.in_paid_price AS inPPrice,
						iv.in_status AS inStatus,
						iv.in_paid_yn AS inPaid,
						iv.in_paid_date AS inPaidTime,
						iv.in_isAnonymous as inIsAnonymous,
						iv.in_anonymous AS inAnonymous,
						iv.in_has_exlink AS inHasExLink,
						iv.in_exlink AS inExLink,
						iv.in_website AS inWebsite,
						iv.in_facebook AS inFacebook,
						iv.in_twitter AS inTwitter,
						iv.in_insta AS inInsta,
						iv.ref_id AS refId,
						iv.update_time AS updateTime,
						iv.create_time AS createTime
					FROM md_invoice iv,  md_user us
			      	WHERE iv.in_sid = '$inSId' 
			      	AND us.id = iv.us_id";
		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result[0] = [];
		} else {
			$result = MDInvoice::getFullInvoiceData( $result );
		}

		return $result[0];
	}

	static public function getDonors( $day = 0, $sort = "", $limit = 0 ) {
		global $db;

		$sql = "SELECT iv.id AS inId,
						iv.in_sid AS inSId,
						iv.us_id AS usId,
						us.us_username AS usName,
						us.us_bu_name AS usBuName,
						us.us_firstname as usFirstName,
						us.us_lastname as usLastName,
						us.us_website AS usWebsite,
						us.us_facebook AS usFacebook,
						us.us_twitter AS usTwitter,
						us.us_insta AS usInsta,
						iv.in_total_price AS inTPrice,
						iv.in_paid_price AS inPPrice,
						iv.in_status AS inStatus,
						iv.in_paid_yn AS inPaid,
						iv.in_paid_date AS inPaidTime,
						iv.in_isAnonymous as inIsAnonymous,
						iv.in_anonymous AS inAnonymous,
						iv.in_has_exlink AS inHasExLink,
						iv.in_exlink AS inExLink,
						iv.in_website AS inWebsite,
						iv.in_facebook AS inFacebook,
						iv.in_twitter AS inTwitter,
						iv.in_insta AS inInsta,
						iv.ref_id AS refId,
						iv.update_time AS updateTime,
						iv.create_time AS createTime
					FROM md_invoice iv, md_user us
					WHERE us.id = iv.us_id
					AND iv.in_paid_yn = 1";
		if ( $day ) {
			$sql .= " AND iv.create_time > DATE_ADD(CURDATE(), INTERVAL $day)";
		}
		if ( $sort ) {
			if ( $sort == 'recent' ) {
				$sql .= " ORDER BY iv.create_time DESC";
			} elseif ( $sort == 'highest' ) {
				$sql .= " ORDER BY iv.in_total_price*1 DESC";
			}
		} else {
			$sql .= " ORDER BY iv.create_time DESC";
		}

		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result = [];
		} else {
			$result = MDInvoice::getFullInvoiceData( $result );
		}

		return $result;
	}

	static public function getPaidStatue( $filter ) {
		global $db;
		$data = array();

		$start = isset($filter["start"]) ? $filter["start"] : 0;
		$end = isset($filter["end"]) ? $filter["end"] : 0;

		$sql = "SELECT CONCAT(SUM(ini.ini_count),' ', IF(SUM(ini.ini_count) = 1, 'tree', 'trees'), ' sold') AS title,	  
					DATE(iv.in_paid_date) AS start
				FROM md_invoice iv, md_invoice_items ini
				WHERE iv.in_paid_yn = 1
				AND ini.in_id LIKE iv.id
				AND DATE(iv.in_paid_date) >= DATE('$start')
				AND DATE(iv.in_paid_date) <= DATE('$end')
				GROUP BY DATE(iv.in_paid_date)
				ORDER BY DATE(iv.in_paid_date) DESC";

		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result = [];
		}

		$data = array_merge($data, $result);

		return $data;
	}

	static public function getByDay( $day ,$isPaid = 1) {
		global $db;
		$sql    = "SELECT iv.id AS inId,
						iv.in_sid AS inSId,
						iv.us_id AS usId,
						us.us_username AS usName,
						us.us_bu_name AS usBuName,
						us.us_firstname as usFirstName,
						us.us_lastname as usLastName,
						us.us_website AS usWebsite,
						us.us_facebook AS usFacebook,
						us.us_twitter AS usTwitter,
						us.us_insta AS usInsta,
						iv.in_total_price AS inTPrice,
						iv.in_paid_price AS inPPrice,
						iv.in_status AS inStatus,
						iv.in_paid_yn AS inPaid,
						iv.in_paid_date AS inPaidTime,
						iv.in_isAnonymous as inIsAnonymous,
						iv.in_anonymous AS inAnonymous,
						iv.in_has_exlink AS inHasExLink,
						iv.in_exlink AS inExLink,
						iv.in_website AS inWebsite,
						iv.in_facebook AS inFacebook,
						iv.in_twitter AS inTwitter,
						iv.in_insta AS inInsta,
						iv.ref_id AS refId,
						iv.update_time AS updateTime,
						iv.create_time AS createTime
					FROM md_invoice iv,  md_user us
			      	WHERE DATE(iv.in_paid_date) = DATE('$day') 
			      	AND us.id = iv.us_id
			      	AND iv.in_paid_yn = $isPaid 
					ORDER BY iv.in_paid_date DESC";

		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result = [];
		} else {
			$result = MDInvoice::getFullInvoiceData( $result );
		}

		return $result;
	}

	static public function getInvoiceByUsId( $usId ) {
		global $db;
		$sql    = "SELECT iv.id AS inId,
						iv.in_sid AS inSId,
						iv.us_id AS usId,
						us.us_username AS usName,
						us.us_bu_name AS usBuName,
						us.us_firstname as usFirstName,
						us.us_lastname as usLastName,
						us.us_website AS usWebsite,
						us.us_facebook AS usFacebook,
						us.us_twitter AS usTwitter,
						us.us_insta AS usInsta,
						iv.in_total_price AS inTPrice,
						iv.in_paid_price AS inPPrice,
						iv.in_status AS inStatus,
						iv.in_paid_yn AS inPaid,
						iv.in_paid_date AS inPaidTime,
						iv.in_isAnonymous as inIsAnonymous,
						iv.in_anonymous AS inAnonymous,
						iv.in_has_exlink AS inHasExLink,
						iv.in_exlink AS inExLink,
						iv.in_website AS inWebsite,
						iv.in_facebook AS inFacebook,
						iv.in_twitter AS inTwitter,
						iv.in_insta AS inInsta,
						iv.ref_id AS refId,
						iv.update_time AS updateTime,
						iv.create_time AS createTime
					FROM md_invoice iv,  md_user us
			      	WHERE iv.us_id = '$usId' 
			      	AND us.id = iv.us_id
					ORDER BY iv.create_time DESC";
		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result = [];
		} else {
			$result = MDInvoice::getFullInvoiceData( $result );
		}

		return $result;
	}


	static public function hasUnpiadInvoice( $usId ) {
		global $db;
		$sql    = "SELECT iv.id AS inId,
						iv.in_sid AS inSId,
						iv.us_id AS usId,
						iv.in_total_price AS inTPrice,
						iv.in_paid_price AS inPPrice,
						iv.in_status AS inStatus,
						iv.in_paid_yn AS inPaid,
						iv.in_paid_date AS inPaidTime,
						iv.in_isAnonymous as inIsAnonymous,
						iv.in_anonymous AS inAnonymous,
						iv.in_has_exlink AS inHasExLink,
						iv.in_exlink AS inExLink,
						iv.in_website AS inWebsite,
						iv.in_facebook AS inFacebook,
						iv.in_twitter AS inTwitter,
						iv.in_insta AS inInsta,
						iv.ref_id AS refId,
						iv.update_time AS updateTime,
						iv.create_time AS createTime
					FROM md_invoice iv
			      	WHERE iv.us_id = '$usId' 
			      	AND iv.in_paid_yn = 0 
					ORDER BY iv.create_time DESC";
		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result = false;
		} else {
			$result = true;
		}

		return $result;
	}

	static public function insertInvoice( $data = [] ) {
		global $db;

		$data = MD_realEscapeArray( $data );

		$usId     = isset( $data["usId"] ) ? $data["usId"] : "";
		$inTPrice = isset( $data["inTPrice"] ) ? $data["inTPrice"] : "";
		$inItems  = isset( $data["inItems"] ) ? $data["inItems"] : "";
		$inStatus = self::$statusActive;

		$inIsAnonymous = isset( $data["inIsAnonymous"] ) ? $data["inIsAnonymous"] : 0;
		$inAnonymous   = isset( $data["inAnonymous"] ) ? $data["inAnonymous"] : "";
		$inHasExLink = isset( $data["inHasExLink"] ) ? $data["inHasExLink"] : 0;
		$inExLink = isset( $data["inExLink"] ) ? $data["inExLink"] : '';
		$inWebsite = isset( $data["inWebsite"] ) ? $data["inWebsite"] : '';
		$inFacebook = isset( $data["inFacebook"] ) ? $data["inFacebook"] : '';
		$inTwitter = isset( $data["inTwitter"] ) ? $data["inTwitter"] : '';
		$inInsta = isset( $data["inInsta"] ) ? $data["inInsta"] : '';

		$refIds = array();
		$referUrl = MD_getSession(MDReferer::SESSION_NAME);
		$referId = MD_getSession(MDReferer::SESSION_ID_NAME);
		if ($referUrl){
			$refObject = [];
			$refObject["refUrl"] = $referUrl;
			$refIds[] = MDReferer::insertRefer($refObject);
		}
		if ($referId){
			$refObject = [];
			$refObject["refUrl"] = $referId;
			$refIds[] = MDReferer::insertRefer($refObject);
		}
		$refId = implode("|",$refIds);
//		in_paid_price = '$inPPrice',
//					      in_status = '$inStatus',
//					      in_paid_yn = '$inPaid',

		$inSID = MD_generateRandom( 16 );

		$sql = "INSERT INTO md_invoice
					  SET in_sid = '$inSID', 
					      us_id = '$usId', 
					      in_total_price = '$inTPrice',
					      in_isAnonymous = '$inIsAnonymous',
					      in_anonymous = '$inAnonymous',
					      in_status = '$inStatus',
					      in_has_exlink = '$inHasExLink',
						  in_exlink = '$inExLink',
						  in_website = '$inWebsite',
						  in_facebook = '$inFacebook',
						  in_twitter = '$inTwitter',
						  in_insta = '$inInsta',
						  ref_id = '$refId',
					      update_time = now(),
					      create_time = now()";
		$db->queryInsert( $sql );

		$result = $db->getPrevInsertId();

		if ( $result ) {
			foreach ( $inItems as $inItem ) {
				$inItem["inId"] = $result;
				MDInvoiceItem::insertInvoiceItem( $inItem );
			}

			$user         = MDUser::getUserById( $usId );
			$newInvoice   = MDInvoice::getInvoiceById( $result );
			$emailInvoice = new MDEmailInvoice( $user, $newInvoice );
			$emailInvoice->sendInvoice();
		}

		return $result;
	}

	static public function updateInvoiceById( $inId, $data = [] ) {
		global $db;

		$data = MD_realEscapeArray( $data );

		$invoice = self::getInvoiceById( $inId );


		$inPPrice = isset( $data["inPPrice"] ) ? $data["inPPrice"] : $invoice["inPPrice"];
		$inStatus = isset( $data["inStatus"] ) ? $data["inStatus"] : $invoice["inStatus"];
		$inPaid   = 0;
		if ( $inStatus == self::$statusPaid ) {
			$inPaid = 1;
		}

		$inIsAnonymous = isset( $data["inIsAnonymous"] ) ? $data["inIsAnonymous"] : 0;
		$inAnonymous = isset( $data["inAnonymous"] ) ? $data["inAnonymous"] : "";
		$inHasExLink = isset( $data["inHasExLink"] ) ? $data["inHasExLink"] :  $invoice["inHasExLink"];
		$inExLink = isset( $data["inExLink"] ) ? $data["inExLink"] :  $invoice["inExLink"];
		$inWebsite = isset( $data["inWebsite"] ) ? $data["inWebsite"] : '';
		$inFacebook = isset( $data["inFacebook"] ) ? $data["inFacebook"] : '';
		$inTwitter = isset( $data["inTwitter"] ) ? $data["inTwitter"] : '';
		$inInsta = isset( $data["inInsta"] ) ? $data["inInsta"] : '';

		$sql = "UPDATE md_invoice
					  SET in_paid_price = '$inPPrice',
					      in_status = '$inStatus',
					      in_paid_yn = '$inPaid',
					      in_isAnonymous = '$inIsAnonymous',
					      in_anonymous = '$inAnonymous',
					      in_has_exlink = '$inHasExLink',
					      in_website = '$inWebsite',
						  in_facebook = '$inFacebook',
						  in_twitter = '$inTwitter',
						  in_insta = '$inInsta',
						  in_exlink = '$inExLink',";
		if ($inPaid){
			$sql .= " in_paid_date = now(),";
		}
		$sql .= " update_time = now() 
				      WHERE id = '$inId'";

		$result = $db->query( $sql );

		if ( $result ) {

			$invoice = MDInvoice::getInvoiceById( $inId );
			$inUser  = MDUser::getUserById( $invoice["usId"] );

			if ( $inPaid ) {
				$emailInvoice = new MDEmailInvoice( $inUser, $invoice );
				$emailInvoice->paidInvoice();
			}

			$inItems = MDInvoiceItem::getInvoiceItemsByInId( $inId );
			foreach ( $inItems as $inItem ) {
				if ( $inPaid ) {


					if ( $inItem["iniType"] != self::$statusPaid ) {
						$tree           = MDTree::getTreeById( $inItem["trId"] );
						$tree["trSold"] = $tree["trSold"] * 1 + $inItem["iniCount"] * 1;
						MDTree::updateTreeSold( $tree["trId"], $tree["trSold"] );

						for ( $i = 0; $i < intval( $inItem["iniCount"] ); $i ++ ) {
							$ctrItem["usId"] = $inUser["usId"];
							$ctrItem["trId"] = $tree["trId"];
							$ctrItem["inId"] = $invoice["inId"];

							MDCustomerTree::insertTree( $ctrItem );
						}
					}
				} else {
					if ( $inItem["iniType"] == self::$statusPaid ) {
						$tree           = MDTree::getTreeById( $inItem["trId"] );
						$tree["trSold"] = $tree["trSold"] * 1 - $inItem["iniCount"] * 1;
						MDTree::updateTreeSold( $tree["trId"], $tree["trSold"] );

						MDCustomerTree::deleteTreeByInId( $inId );
					}
				}
				MDInvoiceItem::setInvoiceItemType( $inId, $inStatus );
			}
		}

		return $result;
	}

	static public function updateAnonymousById( $inId, $data = [] ) {
		global $db;

		$data = MD_realEscapeArray( $data );

		$invoice = self::getInvoiceById( $inId );

		$inIsAnonymous = isset( $data["inIsAnonymous"] ) ? $data["inIsAnonymous"] : 0;

		$inAnonymous = isset( $data["inAnonymous"] ) ? $data["inAnonymous"] : "";

		$sql = "UPDATE md_invoice
					  SET in_isAnonymous = '$inIsAnonymous',
					      in_anonymous = '$inAnonymous',
					      update_time = now() 
				      WHERE id = '$inId'";

		$result = $db->query( $sql );

		return $result;
	}

	static public function updateExLinkById( $inId, $data = [] ) {
		global $db;

		$data = MD_realEscapeArray( $data );

		$invoice = self::getInvoiceById( $inId );

		$inHasExLink = isset( $data["inHasExLink"] ) ? $data["inHasExLink"] :  $invoice["inHasExLink"];
		$inExLink = isset( $data["inExLink"] ) ? $data["inExLink"] :  $invoice["inExLink"];

		$sql = "UPDATE md_invoice
					  SET in_has_exlink = '$inHasExLink',
						  in_exlink = '$inExLink',
					      update_time = now() 
				      WHERE id = '$inId'";

		$result = $db->query( $sql );

		return $result;
	}

	static public function updateSocialLinkById( $inId, $data = [] ) {
		global $db;

		$data = MD_realEscapeArray( $data );

		$inWebsite = isset( $data["inWebsite"] ) ? $data["inWebsite"] : '';
		$inFacebook = isset( $data["inFacebook"] ) ? $data["inFacebook"] : '';
		$inTwitter = isset( $data["inTwitter"] ) ? $data["inTwitter"] : '';
		$inInsta = isset( $data["inInsta"] ) ? $data["inInsta"] : '';

		$sql = "UPDATE md_invoice
					  SET in_website = '$inWebsite',
						  in_facebook = '$inFacebook',
						  in_twitter = '$inTwitter',
						  in_insta = '$inInsta',
					      update_time = now() 
				      WHERE id = '$inId'";

		$result = $db->query( $sql );

		return $result;
	}

	static public function deleteInvoiceById( $inId ) {
		global $db;
		$invoice = self::getInvoiceById( $inId );

		$sql    = "DELETE FROM md_invoice
						where  id = '$inId'";
		$result = $db->query( $sql );

		if ( $result ) {
			MDInvoiceItem::deleteInvoiceItemByInId( $inId );
			MDBankAccount::deleteBankAccountByInId( $inId );
			MDCoinPayment::deleteCoinPaymentByInSId( $invoice["inSId"] );
		}

		return $result;
	}

	static public function deleteInvoiceByInSId( $inSId ) {
		global $db;

		$invoice = self::getInvoiceByInSId( $inSId );

		$sql    = "DELETE FROM md_invoice
						WHERE in_sid = '$inSId'";
		$result = $db->query( $sql );

		if ( $result ) {
			MDInvoiceItem::deleteInvoiceItemByInId( $invoice["inId"] );
			MDBankAccount::deleteBankAccountByInId( $invoice["inId"] );
			MDCoinPayment::deleteCoinPaymentByInSId( $inSId );
		}

		return $result;
	}

	static public function getFullInvoiceData( $data = [] ) {
		if ( is_array( $data ) ) {
			foreach ( $data as &$item ) {
				$treeCount           = MDInvoiceItem::getTreeCountByInId( $item["inId"] );
				$item["inTreeCount"] = $treeCount;
			}
		} else {
			$treeCount           = MDInvoiceItem::getTreeCountByInId( $data["inId"] );
			$data["inTreeCount"] = $treeCount;
		}

		return $data;
	}

	static public function getInvoiceStatuses() {
		$status = array( self::$statusActive, self::$statusPending, self::$statusPaid );

		return $status;
	}
}