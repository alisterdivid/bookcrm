<?php
ob_start();
session_start();
error_reporting(NULL);
if ( $_SERVER['SERVER_NAME'] == 'localhost' ) {
	$toyotahost		= 'localhost';
	$toyotadatabase	= 'pickeringtoyota_toyota';
	$toyotausername	= 'root';
	$toyotapassword	= '';
}else{
	$toyotahost		= 'localhost';
	$toyotadatabase	= 'pickeringtoyota_toyota';
	$toyotausername	= 'pickeringtoyota_toyota';
	$toyotapassword	= 'L?1,[#6-9b=Q';
}

$toyotadbcon	= mysqli_connect($toyotahost, $toyotausername, $toyotapassword, $toyotadatabase) or die("Could not connect. Please try again.");


////////////////// added jeni/////////////////////////////
if ( $_SERVER['SERVER_NAME'] == 'localhost' ) {
	define( "DB_TYPE", "mysql" );
	define( "DB_HOSTNAME", "localhost" );
	define( "DB_USERNAME", "root" );
	define( "DB_PASSWORD", "" );
	define( "DB_DATABASE", "pickeringtoyota_toyota" );
	define( "SITE_NAME", "Pickering Toyota" );
}else {
	define( "DB_TYPE", "mysql" );
	define( "DB_HOSTNAME", "localhost" );
	define( "DB_USERNAME", "pickeringtoyota_toyota" );
	define( "DB_PASSWORD", "L?1,[#6-9b=Q" );
	define( "DB_DATABASE", "pickeringtoyota_toyota" );
	define( "SITE_NAME", "Pickering Toyota" );
}



// Start : Path
$SalesmanPanelPath	= 'https://pickeringtoyota.com/toyotasalesadmin/';
$SalesmanAdminABSPath = "../toyotasalesadmin/";
// End : Path

// Email Authentication 
/*$smtpUsername = 'frank@@thousandtomillion.com';
$smtpPassword = '8JjvOd+MdUDY';
$smtpHost = 'thousandtomillion.com';
$smtpPort = 587;
$SMTPSecure = 'tls';
$smtpSetFrom = 'frank@@thousandtomillion.com';
$smtpAddReplyTo = 'frank@@thousandtomillion.com';*/
$smtpUsername = 'smtp@pickeringtoyota.com';
$smtpPassword = '1(c8OzZ{$[WU';
$smtpHost = 'mail.pickeringtoyota.com';
$smtpPort = 465;
$SMTPSecure = 'ssl';
$smtpSetFrom = 'smtp@pickeringtoyota.com';
$smtpAddReplyTo = 'smtp@pickeringtoyota.com';

define( "PT_BACKEND", "../toyotasubadmin/" );
define( "PT_FRONTEND", "https://pickeringtoyota.com/" );
define("PT_SERVER_DECUMENT_ROOT", $_SERVER['DOCUMENT_ROOT'] . "/toyotasubadmin/");

//define( "PT_BACKEND", "http://thousandtomillion.com/toyotasalesadmin/" );
//define( "PT_FRONTEND", "http://thousandtomillion.com/toyotafront/" );
//define("PT_SERVER_DECUMENT_ROOT", $_SERVER['DOCUMENT_ROOT'] . "/toyotasalesadmin/");

define( "PT_BACKENDJang", "/toyotasubadmin" );


include('functions.php');
?>
	