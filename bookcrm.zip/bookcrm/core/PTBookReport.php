<?php

class PTBookReport {
	private $start = false;
	private $end = false;
	private $report = array();
	private $appList = array();
	private $dateArrange = array();

	const TYPE_NAME = 'service-department';
	const SCHEDULED = 'new_lead';
	const CANCELED = 'closing_lead';
	const SESSION_REPORT = 'bookreporttype';

	function __construct( $start = false, $end = false ) {
		$search_form = date( 'Y-m-01', strtotime( date( 'Y-m-d' ) ) );
		$search_to   = date( 'Y-m-t', strtotime( date( 'Y-m-d' ) ) );

		$this->start = $start ? $start : $search_form;
		$this->end   = $end ? $end : $search_to;
		self::filterStartAndEnd();

		$this->dateArrange[0] = array(
			'label'     => "- " . date( "Y" ) . " -",
			'value'     => "y|" . date( "Y" ),
			'title'     => "all of " . date( "Y" ),
			'startDate' => date( 'Y-m-d', strtotime( "first day of January " . date( 'Y' ) ) ),
			'endDate'   => date( 'Y-m-d', strtotime( "last day of December " . date( 'Y' ) ) )
		);
		$this->dateArrange[1] = array(
			'label'     => date( 'F Y', strtotime( "first day of +3 month" ) ) . " (future)",
			'value'     => date( 'Y-m-d', strtotime( "first day of +3 month" ) ),
			'title'     => date( 'F Y', strtotime( "first day of +3 month" ) ),
			'startDate' => date( 'Y-m-d', strtotime( "first day of +3 month" ) ),
			'endDate'   => date( 'Y-m-d', strtotime( "last day of +3 month" ) )
		);
		$this->dateArrange[2] = array(
			'label'     => date( 'F Y', strtotime( "first day of +2 month" ) ) . " (future)",
			'value'     => date( 'Y-m-d', strtotime( "first day of +2 month" ) ),
			'title'     => date( 'F Y', strtotime( "first day of +2 month" ) ),
			'startDate' => date( 'Y-m-d', strtotime( "first day of +2 month" ) ),
			'endDate'   => date( 'Y-m-d', strtotime( "last day of +2 month" ) )
		);
		$this->dateArrange[3] = array(
			'label'     => date( 'F Y', strtotime( "first day of +1 month" ) ) . " (future)",
			'value'     => date( 'Y-m-d', strtotime( "first day of +1 month" ) ),
			'title'     => date( 'F Y', strtotime( "first day of +1 month" ) ),
			'startDate' => date( 'Y-m-d', strtotime( "first day of +1 month" ) ),
			'endDate'   => date( 'Y-m-d', strtotime( "last day of +1 month" ) )
		);
		$this->dateArrange[4] = array(
			'label'     => date( 'F Y', strtotime( "first day of this month" ) ),
			'value'     => date( 'Y-m-d', strtotime( "first day of this month" ) ),
			'title'     => date( 'F Y', strtotime( "first day of this month" ) ),
			'startDate' => date( 'Y-m-d', strtotime( "first day of this month" ) ),
			'endDate'   => date( 'Y-m-d', strtotime( "last day of this month" ) )
		);
		$this->dateArrange[5] = array(
			'label'     => date( 'F Y', strtotime( "first day of -1 month" ) ),
			'value'     => date( 'Y-m-d', strtotime( "first day of -1 month" ) ),
			'title'     => date( 'F Y', strtotime( "first day of -1 month" ) ),
			'startDate' => date( 'Y-m-d', strtotime( "first day of -1 month" ) ),
			'endDate'   => date( 'Y-m-d', strtotime( "last day of -1 month" ) )
		);
	}

	public function getDateArrange() {
		return $this->dateArrange;
	}

	public function getAppList() {
		self::getScheduledStatue();
		return $this->appList;
	}

	public function setStartAndEnd( $start, $end ) {
		$this->start = $start;
		$this->end   = $end;
		self::filterStartAndEnd();
	}

	public function getScheduledStatue() {
		global $db;

		$start = $this->start;
		$end   = $this->end;

		$sql = "SELECT COUNT(ld.id) AS `count`, 
					DATE(ld.td_request_date) AS `date` 
				FROM leads ld, tbl_book_clients as cl
				WHERE ld.service_type='" . self::TYPE_NAME . "' AND ld.lead_type ='" . self::SCHEDULED . "'
				AND ld.siteuser_id = cl.id
				AND DATE(ld.td_request_date) >= DATE('$start')
				AND DATE(ld.td_request_date) <= DATE('$end')
				GROUP BY DATE(ld.td_request_date)
				ORDER BY DATE(ld.td_request_date) ASC";

		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result = [];
		}

		$this->appList = $result;
		$this->report  = self::filterReport( $result );

		return $this->report;
	}

	public function getCanceledStatue() {
		global $db;

		$start = $this->start;
		$end   = $this->end;

		$sql = "SELECT COUNT(ld.id) AS `count`, 
					DATE(ld.td_request_date) AS `date` 
				FROM leads ld, tbl_book_clients as cl
				WHERE ld.service_type='" . self::TYPE_NAME . "' AND ld.lead_type ='" . self::CANCELED . "'
				AND ld.siteuser_id = cl.id
				AND DATE(ld.td_request_date) >= DATE('$start')
				AND DATE(ld.td_request_date) <= DATE('$end')
				GROUP BY DATE(ld.td_request_date)
				ORDER BY DATE(ld.td_request_date) ASC";

		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result = [];
		}


		$this->report = self::filterReport( $result );

		return $this->report;
	}

	public function getAppListByDay($day){
		global $db;

		$sql = "SELECT ld.id AS apId,
					ld.rq_pack_id AS svId,
					ld.rq_comments AS apComment,
					ld.td_request_time AS apTime, 
					ld.td_request_date AS apDate,
					cl.firstName AS clFirstName,
					cl.lastName AS clLastName,
					sv.service_name AS svName 
				FROM leads ld, tbl_book_clients as cl, tbl_service as sv
				WHERE ld.service_type='" . self::TYPE_NAME . "' AND ld.lead_type ='" . self::SCHEDULED . "'
				AND DATE(ld.td_request_date) = DATE('$day')
				AND ld.siteuser_id = cl.id
				AND ld.rq_pack_id = sv.id
				ORDER BY DATE(ld.td_request_date) ASC";

		$result = $db->queryArray( $sql );

		if ( ! $result ) {
			$result = [];
		}

		return $result;
	}

	public function toHighChartSeries( $data ) {
		$result = array();
		foreach ( $data as $value ) {
			$timestamp = strtotime( $value["date"] );
			$result[]  = "[Date.UTC(" . date( "Y", $timestamp ) . ", " . date( "m", $timestamp ) . "-1," . date( "d", $timestamp ) . "), " . $value["count"] . "]";
		}

		return $result;
	}

	public function getMaxMinDate() {
		global $db;

		$sql = "SELECT MAX(DATE(ld.td_request_date)) AS maxDate, MIN(DATE(ld.td_request_date)) AS minDate
				FROM leads ld, tbl_book_clients as cl
				WHERE ld.service_type='" . self::TYPE_NAME . "'
				AND ld.siteuser_id = cl.id";

		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result[0] = [];
		}

		return $result[0];
	}

	private function filterStartAndEnd() {
		$this->start = date( "Y-m-d", strtotime( $this->start ) );
		$this->end   = date( "Y-m-d", strtotime( $this->end ) );
	}

	private function toDateReport( $result ) {
		$report = array();
		foreach ( $result as $item ) {
			$report[ $item['date'] ] = $item;
		}

		return $report;
	}

	private function filterReport( $report ) {
		$result = array();
		$item   = array();

		$report = self::toDateReport( $report );

		$start = $this->start;
		$end   = $this->end;

		while ( strtotime( $start ) <= strtotime( $end ) ) {
			$item['date']  = $start;
			$item['count'] = 0;
			if ( isset( $report[ $start ] ) ) {
				$result[] = $report[ $start ];
			} else {
				$result[] = $item;
			}
			$start = date( "Y-m-d", strtotime( "+1 day", strtotime( $start ) ) );
		}

		return $result;
	}
}