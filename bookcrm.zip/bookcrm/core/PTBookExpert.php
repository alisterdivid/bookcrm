<?php

class PTBookExpert {
	private $inDays = false;
	private $minDate = false;
	private $maxDate = false;

	function __construct(){
	}

	public function setInDays($inDays){
		$this->inDays = $inDays;
		return true;
	}

	public function setMaxMinDates($minDate, $maxDate){
		$this->minDate = $minDate;
		$this->maxDate = $maxDate;
		return true;
	}

	public function getExpertClients(){
		global $db;

		$inDays = $this->inDays;

		$sql = "SELECT cl.clFirstName AS `FirstName`, 
					cl.clLastName AS `LastName`, 
					cl.clPhone AS `Phone`, 
					cl.clEmail AS `Email`, 
					cl.clNotes AS `Notes`, 
					cl.apLastDate AS `LastDate`
				FROM (SELECT cl.firstName AS clFirstName,
						cl.lastName AS clLastName,
						cl.phone AS clPhone,
						cl.email AS clEmail,
						cl.notes AS clNotes,
						ld.td_request_date AS apDate,
						MAX(DATE(ld.lead_insert_date)) AS apLastDate
					FROM `tbl_book_clients` cl, `leads` ld
					WHERE ld.siteuser_id = cl.id			  
					AND ld.service_type='" . PTBookReport::TYPE_NAME . "'
					GROUP BY cl.id) cl";
		if ($inDays > 0){
			$sql .= " WHERE DATE(cl.apLastDate) < DATE(ADDDATE(NOW(), -".$inDays."))";
		}elseif ($inDays < 0){
			$sql .= " WHERE DATE(cl.apLastDate) > DATE(ADDDATE(NOW(), ".$inDays."))";
		}

		$sql .= " ORDER BY DATE(cl.apLastDate) DESC";

		$result = $db->queryArray( $sql );
		if ( ! $result ) {
			$result = [];
		}

		return $result;
	}

	public function getExpertAppointments(){
		global $db;

		$minDay = $this->minDate;
		$maxDay = $this->maxDate;

		$sql = "SELECT ld.td_request_date AS `Date`,
					ld.td_request_time AS `Time`,									  										 				  
					cl.firstName AS `FirstName`,
					cl.lastName AS `LastName`,
					cl.phone AS `Phone`,
					cl.email AS `Email`,
					sv.service_name AS `ServiceName`,
					ld.rq_comments AS `Notes`
				FROM leads ld, tbl_book_clients as cl, tbl_service as sv
				WHERE ld.service_type='" . PTBookReport::TYPE_NAME . "' AND ld.lead_type ='" . PTBookReport::SCHEDULED . "'";

		if ($minDay){
			$sql .= " AND DATE(ld.td_request_date) > DATE('$minDay')";
		}
		if ($maxDay){
			$sql .= " AND DATE(ld.td_request_date) < DATE('$maxDay')";
		}
		$sql .= " AND ld.siteuser_id = cl.id
				AND ld.rq_pack_id = sv.id
				ORDER BY DATE(ld.td_request_date) ASC";

		$result = $db->queryArray( $sql );

		if ( ! $result ) {
			$result = [];
		}

		return $result;
	}
}