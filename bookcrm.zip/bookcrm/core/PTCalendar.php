<?php

class Calendar {

    /**
     * Constructor
     */
    public function __construct(){
        $this->naviHref = htmlentities($_SERVER['PHP_SELF']);
    }

    /********************* PROPERTY ********************/
    private $dayLabels = array("Mon","Tue","Wed","Thu","Fri","Sat","Sun");
    private $currentYear=0;
    private $currentMonth=0;
    private $currentDay=0;
    private $currentDate=null;
    private $daysInMonth=0;
    private $apptsCount = 0;
    private $naviHref= null;

    /********************* PUBLIC **********************/

    /**
     * print out the calendar
     */
    public function show() {
        $year  = null;
        $month = null;

        if(null==$year&&isset($_GET['year'])){
            $year = $_GET['year'];
        }else if(null==$year){
            $year = date("Y",time());
        }

        if(null==$month&&isset($_GET['month'])){
            $month = $_GET['month'];
        }else if(null==$month){
            $month = date("m",time());
        }

        $this->currentYear=$year;
        $this->currentMonth=$month;
        $this->currentDay=0;
        $this->daysInMonth=$this->_daysInMonth($month,$year);
        $content='<table class="big-calendar"><tr class=""> '.$this->_createLabels().'</tr>';
        $weeksInMonth = $this->_weeksInMonth($month,$year);
        // Create weeks in a month
        for( $i=0; $i<$weeksInMonth; $i++ ){
            //Create days in a week
            for($j=1;$j<=7;$j++){
                if($j == 1){$content.='<tr class="">';}
                $content.=$this->_showDay($i*7+$j);
                if($j == 7) {$content.='</tr>';}
            }
        }
        $content.='</tbody>'.'</table>';

        return $content;
    }
    public function countMonthAppts($selIndex){
        $this->apptsCount = 0;
        $year  = null;
        $month = null;

        if(null==$year&&isset($_GET['year'])){
            $year = $_GET['year'];
        }else if(null==$year){
            $year = date("Y",time());
        }

        if(null==$month&&isset($_GET['month'])){
            $month = $_GET['month'];
        }else if(null==$month){
            $month = date("m",time());
        }

        $this->currentYear=$year;
        $this->currentMonth=$month;
        $this->currentDay=0;
        $this->daysInMonth=$this->_daysInMonth($month,$year);

        $weeksInMonth = $this->_weeksInMonth($month,$year);
        $apptsListContent = '';
        // Create weeks in a month
        for( $i=0; $i<$weeksInMonth; $i++ ){
            //Create days in a week
            for($j=1;$j<=7;$j++){
                $apptsListContent .=  $this->_monthCheckIsApps($i*7+$j ,$selIndex);
            }
        }

        if($selIndex == 'countAppts') {
            return $this->apptsCount;
        }
        elseif ($selIndex == 'apptsList'){
            return $apptsListContent;
        }
    }

    public function showWeek(){
        $year  = null;
        $month = null;
        $day = null;

        if(null==$year&&isset($_GET['year'])){
            $year = $_GET['year'];
        }else if(null==$year){
            $year = date("Y",time());
        }

        if(null==$month&&isset($_GET['month'])){
            $month = $_GET['month'];
        }else if(null==$month){
            $month = date("m",time());
        }

        if(null==$day&&isset($_GET['day'])){
            $day = $_GET['day'];
        }else if(null==$day){
            $day = date("d",time());
        }

        $this->currentYear=$year;
        $this->currentMonth=$month;
        $this->currentDay=$day;
        $this->daysInMonth=$this->_daysInMonth($month,$year);

        $content = '';
        for($j=0;$j<=6;$j++){
            if($j == 0){$content.='<tr class="">';}
            $content.=$this->_showWeekDay($j + $day);
            if($j == 6) {$content.='</tr>';}
        }

        return $content;
    }
    public function countWeekApps(){
        $this->apptsCount = 0;
        $year  = null;
        $month = null;
        $day = null;

        if(null==$year&&isset($_GET['year'])){
            $year = $_GET['year'];
        }else if(null==$year){
            $year = date("Y",time());
        }

        if(null==$month&&isset($_GET['month'])){
            $month = $_GET['month'];
        }else if(null==$month){
            $month = date("m",time());
        }

        if(null==$day&&isset($_GET['day'])){
            $day = $_GET['day'];
        }else if(null==$day){
            $day = date("d",time());
        }

        $this->currentYear=$year;
        $this->currentMonth=$month;
        $this->currentDay=$day;
        $this->daysInMonth=$this->_daysInMonth($month,$year);

        for($j=0;$j<=6;$j++){
           $this->_weeksCheckIsAppts($j + $day);
        }

        return $this->apptsCount;
    }
    public function showDayView(){
        $year  = null;
        $month = null;
        $day = null;
        global $db;

        if(null==$year&&isset($_GET['year'])){
            $year = $_GET['year'];
        }else if(null==$year){
            $year = date("Y",time());
        }

        if(null==$month&&isset($_GET['month'])){
            $month = $_GET['month'];
        }else if(null==$month){
            $month = date("m",time());
        }

        if(null==$day&&isset($_GET['day'])){
            $day = $_GET['day'];
        }else if(null==$day){
            $day = date("d",time());
        }

        $this->currentYear=$year;
        $this->currentMonth=$month;
        $this->currentDay=$day;
        $this->daysInMonth=$this->_daysInMonth($month,$year);

        $this->currentDate = date('Y-m-d',strtotime($this->currentYear.'-'.$this->currentMonth.'-'.($this->currentDay)));

        $sql = "SELECT clients.id AS clientID, clients.firstName AS lf_first_name , clients.lastName AS lf_last_name ,
                       clients.phone AS phone , clients.email AS email, clients.notes AS clientNotes,
                       clients.intake AS intake, leads.id AS id ,leads.td_request_date AS td_request_date, 
                       leads.td_request_time AS td_request_time, leads.rq_pack_id AS rq_pack_id,
                       leads.rq_comments AS rq_comments 
                   FROM leads AS leads, tbl_book_clients AS clients   
                   WHERE leads.siteuser_id = clients.id AND leads.service_type = 'service-department' 
                          AND leads.lead_type= 'new_lead' AND leads.td_request_date = '".$this->currentDate."'";
//        $sql = "select * from leads WHERE service_type = 'service-department'
//                AND lead_type= 'new_lead' AND td_request_date = '".$this->currentDate."'";
        $appts = $db->queryArray($sql);
        $apptsContent = '';
        if($appts != null){
            for($i=0; $i<count($appts);$i++) {
                $topStyle = (intval($appts[$i]['td_request_time']) - 9)*2*42;
                $apptsContent .= '<div id="appt:'.$appts[$i]['id'].'" start="'.$appts[$i]['td_request_time'].'" end="11:30" style="background: #F1EFBC; color: #000000; top: '.$topStyle.'px; height: 43px; position: absolute;" 
                      title="'.$appts[$i]['lf_first_name'].' '.$appts[$i]['lf_last_name'].': jang '.$appts[$i]['td_request_time'].'AM-11:30AM" class="timeslot-column-0 timeslot appointment cal_1856907" 
                      data-origin-html="<div style=&quot;height: 42px;&quot; class=&quot;appointment-inner &quot;><span class=&quot;appt-name&quot;>'.$appts[$i]['lf_first_name'].' '.$appts[$i]['lf_last_name'].':</span>
                     <span class=&quot;type-name&quot;>jang</span>
                     <span class=&quot;interval&quot;>'.$appts[$i]['td_requst_time'].'AM-11:30AM</span><div class=&quot;appt-notes&quot;></div></div>"><div style="height: 42px;" class="appointment-inner ">
                     <span class="appt-name">'.$appts[$i]['lf_first_name'].' '.$appts[$i]['lf_last_name'].':</span>
                     <span class="type-name">jang</span>
                     <span class="interval">'.$appts[$i]['td_request_time'].'AM-11:30AM</span><div class="appt-notes"></div></div></div>';
            }
        }

        $content = '<td id="cal_parent:1856907<>America/New_York" class="cal_parent:1856907<>America/New_York calendar-column">
                        <script type="text/javascript">var timeInterval = 15; var clickTimePrecision=15; var absOpenMinute = 540; var minutesPerPixel = 0.71428571428571; var timeSlotHeight = 21;</script>
                        <div class="appointmentListing-container ">
                            <div class="listingTitle affix affix-top" style="top: 0px; z-index: 3;" data-top="127" data-left="302">
                            frank
                            </div>
                            <div class="open-close" style="width: 100%; height: 84px; bottom: 0;"></div>
                            <div class="current-time-marker" data-container="body" data-toggle="tooltip" data-placement="left" title="" style="bottom: -9999px" data-original-title="Current Time: 2:29am"></div>
                            <div class="advance-time-marker" style=";height:0px;" data-tooltip-clickable-content="<a href=\'/preferences.php?tab=calendars&amp;hnav=restrictions\'><i>Scheduling Limits</i></a> prevent clients from scheduling this time"></div>
                            <div class="advance-time-marker" style=";height:0px;" data-tooltip-clickable-content="<a href=\'/preferences.php?tab=calendars&amp;hnav=restrictions\'><i>Scheduling Limits</i></a> prevent clients from scheduling this time"></div>
                            <div class="appointmentListing hour-height-84 num-columns-0" data-num-columns="0" calendar="parent:1856907<>America/New_York" date="'.$this->currentDate.'" style="width: 100%;  height: 756px;">                                
                                '.$apptsContent.'
                                <div class="mouse-position" style="top: 158px; display: none;">
                                    <div class="tooltip top in" style="top: -32px; left: 110px; display: block;">
                                        <div class="tooltip-arrow"></div>
                                        <div class="tooltip-inner">11:00am</div>
                                    </div>
                                </div>
                            </div>
                        <div style="height: 0;"></div>
                        </div>
                     </td>';


        return $content;
    }
    public function countDayAppts(){
        $this->apptsCount = 0;
        $year  = null;
        $month = null;
        $day = null;
        global $db;

        if(null==$year&&isset($_GET['year'])){
            $year = $_GET['year'];
        }else if(null==$year){
            $year = date("Y",time());
        }

        if(null==$month&&isset($_GET['month'])){
            $month = $_GET['month'];
        }else if(null==$month){
            $month = date("m",time());
        }

        if(null==$day&&isset($_GET['day'])){
            $day = $_GET['day'];
        }else if(null==$day){
            $day = date("d",time());
        }

        $this->currentYear=$year;
        $this->currentMonth=$month;
        $this->currentDay=$day;
        $this->daysInMonth=$this->_daysInMonth($month,$year);

        $this->currentDate = date('Y-m-d',strtotime($this->currentYear.'-'.$this->currentMonth.'-'.($this->currentDay)));

        $sql = "SELECT clients.id AS clientID, clients.firstName AS lf_first_name , clients.lastName AS lf_last_name ,
                       clients.phone AS phone , clients.email AS email, clients.notes AS clientNotes,
                       clients.intake AS intake, leads.id AS id ,leads.td_request_date AS td_request_date, 
                       leads.td_request_time AS td_request_time, leads.rq_pack_id AS rq_pack_id,
                       leads.rq_comments AS rq_comments 
                   FROM leads AS leads, tbl_book_clients AS clients   
                   WHERE leads.siteuser_id = clients.id AND leads.service_type = 'service-department' 
                    AND leads.lead_type= 'new_lead' AND leads.td_request_date = '".$this->currentDate."'";
//        $sql = "select * from leads WHERE service_type = 'service-department'
//                AND lead_type= 'new_lead' AND td_request_date = '".$this->currentDate."'";
        $appts = $db->queryArray($sql);

        return count($appts);
    }

    public function showNavi(){
        $year  = null;
        $month = null;
        $day = null;

        if(null==$year&&isset($_GET['year'])){
            $year = $_GET['year'];
        }else if(null==$year){
            $year = date("Y",time());
        }

        if(null==$month&&isset($_GET['month'])){
            $month = $_GET['month'];
        }else if(null==$month){
            $month = date("m",time());
        }

        if(null==$day&&isset($_GET['day'])){
            $day = $_GET['day'];
        }else if(null==$day){
            $day = date("d",time());
        }

        $this->currentYear=$year;
        $this->currentMonth=$month;
        $this->currentDay=$day;

      return   $this->_createNavi();
    }

    public function showWeekNavi(){
        $year  = null;
        $month = null;
        $day = null;

        if(null==$year&&isset($_GET['year'])){
            $year = $_GET['year'];
        }else if(null==$year){
            $year = date("Y",time());
        }

        if(null==$month&&isset($_GET['month'])){
            $month = $_GET['month'];
        }else if(null==$month){
            $month = date("m",time());
        }

        if(null==$day&&isset($_GET['day'])){
            $day = $_GET['day'];
        }else if(null==$day){
            $day = date("d",time());
        }

        $this->currentYear=$year;
        $this->currentMonth=$month;
        $this->currentDay=$day;

        return   $this->_createWeekNavi();
    }

    public function showDayNavi(){
        $year  = null;
        $month = null;
        $day = null;

        if(null==$year&&isset($_GET['year'])){
            $year = $_GET['year'];
        }else if(null==$year){
            $year = date("Y",time());
        }

        if(null==$month&&isset($_GET['month'])){
            $month = $_GET['month'];
        }else if(null==$month){
            $month = date("m",time());
        }

        if(null==$day&&isset($_GET['day'])){
            $day = $_GET['day'];
        }else if(null==$day){
            $day = date("d",time());
        }

        $this->currentYear=$year;
        $this->currentMonth=$month;
        $this->currentDay=$day;

        return   $this->_createdayNavi();
    }
    /********************* PRIVATE **********************/
    /**
     * create the li element for ul
     */
    private function _showDay($cellNumber){

        global $db;
        if($this->currentDay==0){
            $firstDayOfTheWeek = date('N',strtotime($this->currentYear.'-'.$this->currentMonth.'-01'));

            if(intval($cellNumber) == intval($firstDayOfTheWeek)){
                $this->currentDay=1;
            }
        }

        if( ($this->currentDay!=0)&&($this->currentDay<=$this->daysInMonth) ){
            $this->currentDate = date('Y-m-d',strtotime($this->currentYear.'-'.$this->currentMonth.'-'.($this->currentDay)));
            $cellContent = $this->currentDay;
            $this->currentDay++;
        }else{
            $this->currentDate =null;
            $cellContent=null;
        }
       $preStatus = "";
      if($this->currentDate < date('Y-m-d')){
          $preStatus = 'prev-date';
      }

      $sql = "SELECT clients.id AS clientID, clients.firstName AS lf_first_name , clients.lastName AS lf_last_name ,
                       clients.phone AS phone , clients.email AS email, clients.notes AS clientNotes,
                       clients.intake AS intake, leads.id AS id ,leads.td_request_date AS td_request_date, 
                       leads.td_request_time AS td_request_time, leads.rq_pack_id AS rq_pack_id,
                       leads.rq_comments AS rq_comments 
                   FROM leads AS leads, tbl_book_clients AS clients   
                   WHERE leads.siteuser_id = clients.id AND leads.service_type = 'service-department' 
                   AND leads.lead_type= 'new_lead' AND leads.td_request_date = '".$this->currentDate."'";
//      $sql = "select * from leads WHERE service_type = 'service-department'
//                      AND lead_type= 'new_lead' AND td_request_date = '".$this->currentDate."'";
      $appts = $db->queryArray($sql);
      if($appts != null){
          $summaryContents = '';
          for($i = 0 ; $i< count($appts); $i++){
              $summaryContents .= '<div class="summary-entry">
                                <span class="summary-time">'.$appts[$i]['td_request_time'].'</span>
                                <span class="summary-name">'.$appts[$i]['lf_first_name'].' '.$appts[$i]['lf_last_name'].'</span>
                            </div>';
          }
          $cellHtml = '<td day="' . $this->currentDate . '" class="day has-appts"> 
                           <span class="date">' . $cellContent . '</span> 
                            <div class="apptCount">
                                <span class="apptCountNum">'.count($appts).'</span>
                                <span class="apptCountLabel"> appts.</span>
                            </div>
                            <div class="day-summary hidden-xs">
                            '.$summaryContents.'
                        </div>
                        </td>';
      }
      else {
          $cellHtml = '<td day="' . $this->currentDate . '" class="day ">  <span class="date">' . $cellContent . '</span><div class="apptCount">&nbsp;&nbsp;</div></td>';
      }
        return $cellHtml;
    }

    private function _monthCheckIsApps($cellNumber,$selIndex){
        global $db;
        if($this->currentDay==0){
            $firstDayOfTheWeek = date('N',strtotime($this->currentYear.'-'.$this->currentMonth.'-01'));

            if(intval($cellNumber) == intval($firstDayOfTheWeek)){
                $this->currentDay=1;
            }
        }

        if( ($this->currentDay!=0)&&($this->currentDay<=$this->daysInMonth) ){
            $this->currentDate = date('Y-m-d',strtotime($this->currentYear.'-'.$this->currentMonth.'-'.($this->currentDay)));
            $cellContent = $this->currentDay;
            $this->currentDay++;
        }else{
            $this->currentDate =null;
            $cellContent=null;
        }

        $sql = "SELECT clients.id AS clientID, clients.firstName AS lf_first_name , clients.lastName AS lf_last_name ,
                       clients.phone AS phone , clients.email AS email, clients.notes AS clientNotes,
                       clients.intake AS intake, leads.id AS id ,leads.td_request_date AS td_request_date, 
                       leads.td_request_time AS td_request_time, leads.rq_pack_id AS rq_pack_id,
                       leads.rq_comments AS rq_comments 
                   FROM leads AS leads, tbl_book_clients AS clients   
                   WHERE leads.siteuser_id = clients.id AND leads.service_type = 'service-department' 
                   AND leads.lead_type= 'new_lead' AND leads.td_request_date = '".$this->currentDate."'";
//        $sql = "select * from leads WHERE service_type = 'service-department'
//                        AND lead_type= 'new_lead' AND td_request_date = '".$this->currentDate."'";
        $appts = $db->queryArray($sql);
        if($appts != null){
            if($selIndex == 'countAppts') {
                $this->apptsCount += count($appts);
            }
            elseif ($selIndex == 'apptsList'){
                $apptsListContent = '';
                $apptsListContent .= '<h3><a id="date-'. $this->currentDate.'"></a>'. $this->currentDate.'
                                        <a href="#container-wrapper" class="pull-right" data-toggle="tooltip" data-placement="left" title="" data-original-title="Go to top of page"><i class="icon-chevron-up"></i></a>
                                    </h3>';
                for($i = 0; $i< count($appts); $i++){
                    $apptsListContent .= '<div class="calendar-appt ">
                                               <div class="row appt-details" style="box-shadow: inset 5px 0 0 0 #EFACAE;">
				                                <div class="col-xs-12">
                                                    <span class="appt-datetime">'.date('l, F d , Y', strtotime($this->currentDate)).'</span>
                                                    <span class="appt-duration">50 MIN</span>
                                                    <div class="pull-right is-paid">   </div>
                                                </div>
                                            </div>                                
                                            <div class="row appt-heading"  style="box-shadow: inset 5px 0 0 0 #EFACAE;">
                                                <div class="col-xs-12">
                                                    <a class="btn-link detail-nav-link appt-time margin-right" href="book-expertAppointments.php?action=detail&id='.$appts[$i]['id'].'&backto=">'.$appts[$i]['td_request_time'].'</a>
                                                    <span class="appt-client-name">
                                                       <div class="pull-right hidden-xs" title="" data-toggle="tooltip" data-placement="left" data-original-title="Client user: aaaaa@gmail.com"><i class="icon-user"></i></div>
                                                       <a class="btn-link detail-nav-link" href="book-expertAppointments.php?action=detail&id='.$appts[$i]['id'].'&backto=">'.$appts[$i]['lf_first_name'].' '.$appts[$i]['lf_last_name'].'</a>
                                                    </span>
                                                </div>
                                            </div>                                
                                            <div class="row appt-details" style="box-shadow: inset 5px 0 0 0 #EFACAE;">
                                                <div class="col-xs-12">
                                                    CONSULTATION   —    FRANK FROM '.$appts[$i]['td_request_time'].'PM-2:40PM 
                                                    <br>
                                                </div>
                                            </div>
					                    </div>';
                }
                return $apptsListContent;
            }
        }

    }
    private function _showWeekDay($cellNumber){

        global $db;
        if($this->currentDay==0){
            $firstDayOfTheWeek = date('N',strtotime($this->currentYear.'-'.$this->currentMonth.'-01'));
            if(intval($cellNumber) == intval($firstDayOfTheWeek)){
                $this->currentDay=1;
            }
        }

        if( ($this->currentDay!=0)&&($this->currentDay<=$this->daysInMonth) ){
            $this->currentDate = date('Y-m-d',strtotime($this->currentYear.'-'.$this->currentMonth.'-'.($this->currentDay)));
            $this->currentDay++;

        }else{
            $this->currentMonth =  $this->currentMonth==12?1:intval($this->currentMonth)+1;
            $this->currentYear = $this->currentMonth==12?intval($this->currentYear)+1:$this->currentYear;
            $this->currentDay = 1;
            $this->currentDate = date('Y-m-d',strtotime($this->currentYear.'-'.$this->currentMonth.'-01'));
            $this->currentDay ++;
        }

        $sql = "SELECT clients.id AS clientID, clients.firstName AS lf_first_name , clients.lastName AS lf_last_name ,
                       clients.phone AS phone , clients.email AS email, clients.notes AS clientNotes,
                       clients.intake AS intake, leads.id AS id ,leads.td_request_date AS td_request_date, 
                       leads.td_request_time AS td_request_time, leads.rq_pack_id AS rq_pack_id,
                       leads.rq_comments AS rq_comments 
                   FROM leads AS leads, tbl_book_clients AS clients   
                   WHERE leads.siteuser_id = clients.id AND leads.service_type = 'service-department'
                    AND leads.lead_type= 'new_lead' AND leads.td_request_date = '".$this->currentDate."'";
//        $sql = "select * from leads WHERE service_type = 'service-department'
//                      AND lead_type= 'new_lead' AND td_request_date = '".$this->currentDate."'";
        $appts = $db->queryArray($sql);
        if($appts != null){
            $columnNum = '1';
        }
        else{
            $columnNum = '0';
        }

        $nameOfDay = date('l, M d', strtotime($this->currentDate));

        $cellHtml = '<td id="cal_' . $this->currentDate . '" class="cal_' . $this->currentDate . ' calendar-column">  
                       <script type="text/javascript">var timeInterval = 15; var clickTimePrecision=15; var absOpenMinute = 540; var minutesPerPixel = 0.71428571428571; var timeSlotHeight = 21;</script>
                       <div class="appointmentListing-container ">
                        <div class="listingTitle affix affix-top affixing" style="top: 0px; z-index: 500; position: relative;" data-top="130" data-left="462">'.$nameOfDay.'
                        </div>                    
                        <div class="current-time-marker" data-container="body" data-toggle="tooltip" data-placement="left" title="" style="bottom: -9999px" data-original-title="Current Time: 12:36pm"></div>
                        <div class="advance-time-marker" style=";height:0px;" data-tooltip-clickable-content="<a href=\'/preferences.php?tab=calendars&amp;hnav=restrictions\'><i>Scheduling Limits</i></a> prevent clients from scheduling this time"></div>
                        <div class="advance-time-marker" style=";height:0px;" data-tooltip-clickable-content="<a href=\'/preferences.php?tab=calendars&amp;hnav=restrictions\'><i>Scheduling Limits</i></a> prevent clients from scheduling this time"></div>
                        <div class="appointmentListing hour-height-84 num-columns-'.$columnNum.'" data-num-columns="'.$columnNum.'" calendar="1856907" date="'.$this->currentDate.'" style="width: 100%;  height: 840px;">';

        if($appts != null){
            for($i=0; $i< count($appts); $i++) {
                $cellTop = (intval($appts[$i]['td_request_time']) - 9)*2*42;
                $cellHtml .='<div id="appt:'.$appts[$i]['id'].'" start="'.$appts[$i]['td_request_time'].'" end="11:30" 
                             style="background: #F1EFBC; color: #000000; top: '.$cellTop.'px; height: 43px; position: absolute;" 
                             title="'.$appts[$i]['lf_first_name'].' '.$appts[$i]['lf_last_name'].': '.$appts[$i]['lf_first_name'].' '.$appts[$i]['td_request_time'].':30AM" class="timeslot-column-0 timeslot appointment cal_1856907" 
                             data-origin-html="<div style=&quot;height: 42px;&quot; class=&quot;appointment-inner &quot;><span class=&quot;appt-name&quot;>'.$appts[$i]['lf_first_name'].' '.$appts[$i]['lf_last_name'].':</span>
                             <span class=&quot;type-name&quot;>jang</span>
                             <span class=&quot;interval&quot;>'.$appts[$i]['lf_first_name'].'-11:30AM</span><div class=&quot;appt-notes&quot;></div></div>">
                                <div style="height: 42px;" class="appointment-inner ">
                                    <span class="appt-name">'.$appts[$i]['lf_first_name'].' '.$appts[$i]['lf_last_name'].':</span>
                                    <span class="type-name">'.$appts[$i]['first_name'].'</span>
                                    <span class="interval">'.$appts[$i]['td_request_time'].'-11:30AM</span>
                                    <div class="appt-notes"></div>
                                </div>
                             </div>
                            ';
            }
        }


        $cellHtml .= '<div class="mouse-position" style="top: 14px; display: none;">
                            <div class="tooltip top in" style="top: -32px; left: 121px; display: block;">
                            <div class="tooltip-arrow"></div><div class="tooltip-inner">9:15am</div>
                            </div>
                            </div>
                        </div>
                        <div style=" height: 0;"></div>
                        </div>
                        </td>';

        return $cellHtml;
    }

    private function _weeksCheckIsAppts($cellNumber){
        global $db;
        if($this->currentDay==0){
            $firstDayOfTheWeek = date('N',strtotime($this->currentYear.'-'.$this->currentMonth.'-01'));
            if(intval($cellNumber) == intval($firstDayOfTheWeek)){
                $this->currentDay=1;
            }
        }

        if( ($this->currentDay!=0)&&($this->currentDay<=$this->daysInMonth) ){
            $this->currentDate = date('Y-m-d',strtotime($this->currentYear.'-'.$this->currentMonth.'-'.($this->currentDay)));
            $cellContent = $this->currentDay;
            $this->currentDay++;
        }else{
            $this->currentMonth++;
            $this->currentDay = 1;
            $this->currentDate = date('Y-m-d',strtotime($this->currentYear.'-'.$this->currentMonth.'-01'));
        }
        $nameOfDay = date('D', strtotime($this->currentDate));
        $nameOfMonth = date('M', strtotime($this->currentDate));

        $sql = "SELECT clients.id AS clientID, clients.firstName AS lf_first_name , clients.lastName AS lf_last_name ,
                       clients.phone AS phone , clients.email AS email, clients.notes AS clientNotes,
                       clients.intake AS intake, leads.id AS id ,leads.td_request_date AS td_request_date, 
                       leads.td_request_time AS td_request_time, leads.rq_pack_id AS rq_pack_id,
                       leads.rq_comments AS rq_comments 
                   FROM leads AS leads, tbl_book_clients AS clients   
                   WHERE leads.siteuser_id = clients.id AND leads.service_type = 'service-department'
                    AND leads.lead_type= 'new_lead' AND leads.td_request_date = '".$this->currentDate."'";
//        $sql = "select * from leads WHERE service_type = 'service-department'
//                    AND lead_type= 'new_lead' AND td_request_date = '".$this->currentDate."'";
        $appts = $db->queryArray($sql);
        if($appts != null){
            $this->apptsCount += count($appts);
        }
    }
    /**
     * create navigation
     */
    private function _createNavi(){

        $nextMonth = $this->currentMonth==12?1:intval($this->currentMonth)+1;
        $nextYear = $this->currentMonth==12?intval($this->currentYear)+1:$this->currentYear;
        $preMonth = $this->currentMonth==1?12:intval($this->currentMonth)-1;
        $preYear = $this->currentMonth==1?intval($this->currentYear)-1:$this->currentYear;

        return
            '<a href="book-expertAppointments.php?view=day&upnext=1&day=today" class="btn btn-default btn-today ">Today</a>
            <a href="book-expertAppointments.php?view=thisWeek&day='.$this->currentYear.'-'.$this->currentMonth.'-'.$this->currentDay.'&round=1" class="btn btn-week btn-default ">Week</a>
            <a href="book-expertAppointments.php?view=thisMonth&day='.$this->currentYear.'-'.$this->currentMonth.'-'.$this->currentDay.'" class="btn btn-month btn-default active">Month</a>
            <a href="book-expertAppointments.php?view=thisMonth&day='.$preYear.'-'.$preMonth.'-01" id="nav-previous" class="btn btn-inverse icon-chevron-left" title="Previous"><span>&lt;</span></a>
            <a href="book-expertAppointments.php?view=thisMonth&day='.$nextYear.'-'.$nextMonth.'-01" id="nav-next" class="btn btn-inverse icon-chevron-right" title="Next"><span>&gt;</span></a>';
    }

    private function _createWeekNavi(){
        $nextWeekStart = intval($this->currentDay) + 7;
        $nextMonth = $this->currentMonth==12?1:intval($this->currentMonth)+1;
        $nextYear = $this->currentMonth==12?intval($this->currentYear)+1:$this->currentYear;
        $preMonth = $this->currentMonth==1?12:intval($this->currentMonth)-1;
        $preYear = $this->currentMonth==1?intval($this->currentYear)-1:$this->currentYear;

        if($nextWeekStart<=intval($this->_daysInMonth($this->currentYear,$this->currentMonth))){
            $nextWeek = $nextWeekStart;
            $nextMonth = $this->currentMonth;
            $nextYear = $this->currentYear;
        }
        else{
            $nextWeek = $nextWeekStart - intval($this->_daysInMonth($this->currentYear,$this->currentMonth));
        }
        $preWeekStart = intval($this->currentDay) - 7;

        if($preWeekStart > 0){
            $preWeek = $preWeekStart;
            $preMonth = $this->currentMonth;
            $preYear = $this->currentYear;
        }
        else{
            $premonthDayNum = $this->_daysInMonth($preYear,$preMonth);
            $preWeek = intval($premonthDayNum) + $preWeekStart;
        }
        return
            '<a href="book-expertAppointments.php?view=day&upnext=1&day=today" class="btn btn-default btn-today ">Today</a>
            <a href="book-expertAppointments.php?view=thisWeek&day='.$this->currentYear.'-'.$this->currentMonth.'-'.$this->currentDay.'&round=1" class="btn btn-week btn-default active">Week</a>
            <a href="book-expertAppointments.php?view=thisMonth&day='.$this->currentYear.'-'.$this->currentMonth.'-'.$this->currentDay.'" class="btn btn-month btn-default ">Month</a>
            <a href="book-expertAppointments.php?view=thisWeek&day='.$preYear.'-'.$preMonth.'-'.$preWeek.'" id="nav-previous" class="btn btn-inverse icon-chevron-left" title="Previous"><span>&lt;</span></a>
            <a href="book-expertAppointments.php?view=thisWeek&day='.$nextYear.'-'.$nextMonth.'-'.$nextWeek.'" id="nav-next" class="btn btn-inverse icon-chevron-right" title="Next"><span>&gt;</span></a>';
    }

    private function _createdayNavi(){
        if(intval($this->currentDay) < intval( date('t',strtotime($this->currentYear.'-'.$this->currentMonth.'-01')))){
           $nextMonth = $this->currentMonth;
           $nextYear = $this->currentYear;
           $nextDay = intval($this->currentDay) + 1;
        }
        else{
            $nextMonth = $this->currentMonth==12?1:intval($this->currentMonth)+1;
            $nextYear = $this->currentMonth==12?intval($this->currentYear)+1:$this->currentYear;
            $nextDay = '01';
        }

        if(intval($this->currentDay) > 1){
            $preMonth = $this->currentMonth;
            $preYear = $this->currentYear;
            $preDay = intval($this->currentDay) - 1;
        }
        else{
            $preMonth = $this->currentMonth==1?12:intval($this->currentMonth)-1;
            $preYear = $this->currentMonth==1?intval($this->currentYear)-1:$this->currentYear;
            $preDay =  date('t',strtotime($preYear.'-'.$preMonth.'-01'));
        }


        return
            '<a href="book-expertAppointments.php?view=day&upnext=1&day=today" class="btn btn-default btn-today active">Today</a>
            <a href="book-expertAppointments.php?view=thisWeek&day='.$this->currentYear.'-'.$this->currentMonth.'-'.$this->currentDay.'&round=1" class="btn btn-week btn-default ">Week</a>
            <a href="book-expertAppointments.php?view=thisMonth&day='.$this->currentYear.'-'.$this->currentMonth.'-'.$this->currentDay.'" class="btn btn-month btn-default ">Month</a>
            <a href="book-expertAppointments.php?view=day&day='.$preYear.'-'.$preMonth.'-'.$preDay.'" id="nav-previous" class="btn btn-inverse icon-chevron-left" title="Previous"><span>&lt;</span></a>
            <a href="book-expertAppointments.php?view=day&day='.$nextYear.'-'.$nextMonth.'-'.$nextDay.'" id="nav-next" class="btn btn-inverse icon-chevron-right" title="Next"><span>&gt;</span></a>';
    }
    /**
     * create calendar week labels
     */
    private function _createLabels(){
        $content='';
        foreach($this->dayLabels as $index=>$label){
            $content.='<th>'.$label.'</th>';
        }
        return $content;
    }



    /**
     * calculate number of weeks in a particular month
     */
    private function _weeksInMonth($month=null,$year=null){
        if( null==($year) ) {
            $year =  date("Y",time());
        }

        if(null==($month)) {
            $month = date("m",time());
        }
        // find number of days in this month
        $daysInMonths = $this->_daysInMonth($month,$year);
        $numOfweeks = ($daysInMonths%7==0?0:1) + intval($daysInMonths/7);
        $monthEndingDay= date('N',strtotime($year.'-'.$month.'-'.$daysInMonths));
        $monthStartDay = date('N',strtotime($year.'-'.$month.'-01'));
        if($monthEndingDay<$monthStartDay){
            $numOfweeks++;
        }

        return $numOfweeks;
    }

    /**
     * calculate number of days in a particular month
     */
    private function _daysInMonth($month=null,$year=null){

        if(null==($year))
            $year =  date("Y",time());
        if(null==($month))
            $month = date("m",time());

        return date('t',strtotime($year.'-'.$month.'-01'));
    }

}