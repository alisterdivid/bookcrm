<?php
require_once dirname( __FILE__ ) . '/load.php';

// Start : Fetch login admin/user detail
if ( isset( $_SESSION['TMCid'] ) && $_SESSION['TMCid'] != "" && is_numeric( $_SESSION['TMCid'] ) ) {
	$LoginDetailSql        = "SELECT * FROM admin WHERE id = " . $_SESSION['TMCid'];
	$LoginDetailQue        = mysqli_query( $toyotadbcon, $LoginDetailSql );
	$ResultArray           = fetchassoc( $LoginDetailQue );
	$_SESSION['LoginVars'] = $ResultArray;

	//echo "<pre>";print_r($_SESSION['LoginVars']);exit;
}
// End : Fetch login admin/user detail

// Start : Get result array
function fetcharray( $Query ) {
	$ResultArray = array();
	while ( $Res = mysqli_fetch_array( $Query ) ) {
		$ResultArray[] = $Res;
	}

	return $ResultArray;
}

function fetchassoc( $Query ) {
	$ResultArray = array();
	while ( $Res = mysqli_fetch_assoc( $Query ) ) {
		$ResultArray[] = $Res;
	}

	return $ResultArray;
}

function fetchrow( $Query ) {
	$ResultArray = array();
	while ( $Res = mysqli_fetch_row( $Query ) ) {
		$ResultArray[] = $Res;
	}

	return $ResultArray;
}

function calculateHowManyPages( $messagecount, $seperator ) {

	$tmp_page   = floor( $messagecount / $seperator );
	$total_page = $tmp_page * $seperator;
	if ( $messagecount != $total_page ) {
		$how_many = $tmp_page + 1;
	} else {
		$how_many = $tmp_page;
	}

	return $how_many;
}

function logToFile( $filename, $msg ) {
	$fd  = fopen( $filename, "a" );
	$str = "[" . date( "Y/m/d h:i:s", time() ) . "] " . $msg;
	fwrite( $fd, $str . "\n" );
	fclose( $fd );
}

function PT_MkDir( $path, $mode = 0777 ) {
	$dirs  = explode( DIRECTORY_SEPARATOR, $path );
	$count = count( $dirs );
	$path  = '.';
	for ( $i = 0; $i < $count; ++ $i ) {
		$path .= DIRECTORY_SEPARATOR . $dirs[ $i ];
		if ( ! is_dir( $path ) && ! mkdir( $path, $mode ) ) {
			return false;
		}
	}

	return true;
}

function PT_generateRandom( $len ) {
	$strpattern = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	$result     = "";
	for ( $i = 0; $i < $len; $i ++ ) {
		$rand   = rand( 0, strlen( $strpattern ) - 1 );
		$result = $result . $strpattern[ $rand ];
	}

	return $result;
}

function PT_isLogin() {
	if ( isset( $_COOKIE['PT_TOKEN'] ) ) {
		return true;
	} else {
		return false;
	}
}

function PT_setCookie( $name, $value ) {
	setcookie( $name, $value . "", time() + ( 2 * 7 * 24 * 60 * 60 ) );
}

function PT_getCookie( $name ) {
	return $_COOKIE[ $name ];
}

function PT_deleteCookie( $name ) {
	setcookie( $name, "", time() - 3600 );
}

function PT_getCurrentId() {
	if ( PT_isLogin() ) {
		return PT_getUserId( $_COOKIE['PT_TOKEN'] );
	} else {
		return "";
	}
}

function PT_getUserId( $token ) {
	global $db;
	if ( $token == "" ) {
		return "";
	} else {
		$sql    = "select id from `admin` where token = '$token'";
		$result = $db->queryArray( $sql );
		if ( $result == null ) {
			return "";
		} else {
			return $result[0]['id'];
		}
	}
}

function getCurrentAccountType() {
	if ( PT_isLogin() ) {
		return getAccountType( $_COOKIE['PT_TOKEN'] );
	} else {
		return "";
	}
}

function getAccountType( $token ) {
	global $db;
	if ( $token == "" ) {
		return "";
	} else {
		$sql    = "select account_type from admin where token = '$token'";
		$result = $db->queryArray( $sql );
		if ( $result == null ) {
			return "";
		} else {
			return $result[0]['account_type'];
		}
	}
}

function getCurrentGender() {
	if ( PT_isLogin() ) {
		return geGender( $_COOKIE['PT_TOKEN'] );
	} else {
		return "";
	}
}

function geGender( $token ) {
	global $db;
	if ( $token == "" ) {
		return "";
	} else {
		$sql    = "select gender from admin where token = '$token'";
		$result = $db->queryArray( $sql );
		if ( $result == null ) {
			return "";
		} else {
			return $result[0]['gender'];
		}
	}
}

function getCurrentUserName() {
	if ( PT_isLogin() ) {
		return getUserName( $_COOKIE['PT_TOKEN'] );
	} else {
		return "";
	}
}

function getUserName( $token ) {
	global $db;
	if ( $token == "" ) {
		return "";
	} else {
		$sql    = "select username from admin where token = '$token'";
		$result = $db->queryArray( $sql );
		if ( $result == null ) {
			return "";
		} else {
			return $result[0]['username'];
		}
	}
}

function PT_getCurrentType() {
	if ( PT_isLogin() ) {
		return PT_getUserType( $_COOKIE['PT_TOKEN'] );
	} else {
		return "";
	}
}

function PT_getUserType( $token ) {
	global $db;
	if ( $token == "" ) {
		return "";
	} else {
		$sql    = "select user_type from admin where token = '$token'";
		$result = $db->queryArray( $sql );
		if ( $result == null ) {
			return "";
		} else {
			return $result[0]['user_type'];
		}
	}
}

function specIsChecked( $checkedList, $subModelId ) {
	$listArray  = explode( "|", $checkedList );
	$subModelId = (string) $subModelId;
	$result     = in_array( $subModelId, $listArray );
	if ( $result ) {
		return true;
	} else {
		return false;
	}
}

function splitData( $data, $index ) {
	$pieces = explode( "|", $data );

	return $pieces[ $index ];
}

function PT_getImageName( $url ) {
	$imageNameArray = explode( '/', $url );

	return end( $imageNameArray );
}

function PT_getFullImageUrl( $imageName, $slug ) {
	$target_model = strtolower( $slug );
	$target_model = trim( $target_model );
	$target_model = str_replace( ' ', '-', $target_model );
	if ( ( $imageName == 'noPhoto.png' ) || ( $imageName == "" ) ) {
		return PT_BACKENDJang . '/img/noPhoto.png';
	} else {
		return PT_BACKENDJang . '/media/' . $target_model . '/' . $imageName;
	}
}

function PT_getFullVideoImgUrl( $imageName, $catName ) {
	$target_model = strtolower( $catName );
	$target_model = trim( $target_model );
	$target_model = str_replace( ' ', '-', $target_model );
	if ( $imageName == 'noPhoto.png' ) {
		return PT_BACKENDJang . '/img/noPhoto.png';
	} else {
		return PT_BACKENDJang . '/img/video-icon.jpg';
	}
}

function PT_getFullVideoUrl( $videoName, $catName ) {
	$target_model = strtolower( $catName );
	$target_model = trim( $target_model );
	$target_model = str_replace( ' ', '-', $target_model );
	if ( ( $videoName == 'noPhoto.png' ) || ( $videoName == "" ) ) {
		return PT_BACKENDJang . '/img/noPhoto.png';
	} else {
		return PT_BACKENDJang . '/media/' . $target_model . '/' . $videoName;
	}
}

function PT_getFileExtension( $file ) {
	$extension = end( explode( ".", $file ) );

	return $extension ? $extension : false;
}

function PT_getBackendRealMediaUrl( $mediaUrl ) {
	return PT_BACKEND . $mediaUrl;
}

function PT_getFrontendRealMediaUrl( $mediaUrl ) {
	return PT_FRONTEND . $mediaUrl;
}

function PT_escapeString( $pt_str ) {

	$pt_rstr = strtolower( $pt_str );
	$pt_rstr = trim( $pt_rstr );
	$pt_rstr = str_replace( ' ', '-', $pt_rstr );

	return $pt_rstr;
}

function PT_getExcerptString( $pt_str, $length = 50 ) {
	$result = "";
	if ( mb_strlen( $pt_str ) > $length ) {
		$subex   = mb_substr( $pt_str, 0, $length - 5 );
		$exwords = explode( ' ', $subex );
		$excut   = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
		if ( $excut < 0 ) {
			$result .= mb_substr( $subex, 0, $excut );
		} else {
			$result .= $subex;
		}
		$result .= '<br>...';
	} else {
		$result .= $pt_str;
	}

	return $result;
}

//resize and crop image
function resize_crop_image( $max_width, $max_height, $source_file, $dst_dir, $quality = 80 ) {
	$imgsize = getimagesize( $source_file );
	$width   = $imgsize[0];
	$height  = $imgsize[1];
	$mime    = $imgsize['mime'];

	$dst_img = imagecreatetruecolor( $max_width, $max_height );
	$src_img = imagecreatefromjpeg( $source_file );

	$width_new  = $height * $max_width / $max_height;
	$height_new = $width * $max_height / $max_width;
	//if the new width is greater than the actual width of the image, then the height is too large and the rest cut off, or vice versa
	if ( $width_new > $width ) {
		//cut point by height
		$h_point = ( ( $height - $height_new ) / 2 );
		//copy image
		imagecopyresampled( $dst_img, $src_img, 0, 0, 0, $h_point, $max_width, $max_height, $width, $height_new );
	} else {
		//cut point by width
		$w_point = ( ( $width - $width_new ) / 2 );
		imagecopyresampled( $dst_img, $src_img, 0, 0, $w_point, 0, $max_width, $max_height, $width_new, $height );
	}

	imageJpeg( $dst_img, $dst_dir, $quality );

	if ( $dst_img ) {
		imagedestroy( $dst_img );
	}
	if ( $src_img ) {
		imagedestroy( $src_img );
	}
}

//end resize and crop
//convert image from png, gif, bmp, jpeg to jpg
function convertimageJPG( $file, $modelname, $target, $filename, $quality = 100 ) {

	//make directory if it is not exist
	if ( ! is_dir( '../media/' . $modelname ) ) {
		mkdir( '../media/' . $modelname, 0777, true );
	}
	if ( ! is_dir( '../media/' . $modelname . '/' . $target ) ) {
		mkdir( '../media/' . $modelname . '/' . $target, 0777, true );
	}
//end make directory

	$img_name = $file['name'];
	$file_tmp = $file['tmp_name'];
	list( $original_name, $img_type ) = explode( ".", $img_name );
	$img_type = strtolower( $img_type );

	$img_path = $img_path = '../media/' . $modelname . '/' . $target . '/';
	//converter all image to .jpg file
	if ( $img_type != "jpg" ) {
		if ( $img_type == "png" || $img_type == "gif" || $img_type == "bmp" || $img_type == "jpeg" ) {
			$new_name = $original_name . "_thumb";
			imageJpeg( imagecreatefromstring( file_get_contents( $file_tmp ) ), $img_path . $filename . '.jpg', $quality );

//        return $img_name.'.'.$convert_type;
			return $img_path . $filename;

		} else {
			return null;
		}
	} else {
		move_uploaded_file( $file_tmp, $img_path . $filename . '.jpg' );

		return $img_path . $filename;
	}
}

//end convert this function return converted image path(if success), return null(failed)
function PT_displayPaginationBelow( $per_page, $page, $total, $catId ) {
	if ( $catId == "" ) {
		$page_url = "?";
	} else {
		$page_url = "?cat_id=" . $catId . "&";
	}
	$adjacents = "2";

	$page  = ( $page == 0 ? 1 : $page );
	$start = ( $page - 1 ) * $per_page;

	$prev        = $page - 1;
	$next        = $page + 1;
	$setLastpage = ceil( $total / $per_page );
	$lpm1        = $setLastpage - 1;

	$setPaginate = "";
	if ( $setLastpage > 1 ) {
		$setPaginate .= "<ul class='setPaginate'>";
		$setPaginate .= "<li class='setPage'>Page $page of $setLastpage</li>";
		if ( $setLastpage < 7 + ( $adjacents * 2 ) ) {
			for ( $counter = 1; $counter <= $setLastpage; $counter ++ ) {
				if ( $counter == $page ) {
					$setPaginate .= "<li><a class='current_page'>$counter</a></li>";
				} else {
					$setPaginate .= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
				}
			}
		} elseif ( $setLastpage > 5 + ( $adjacents * 2 ) ) {
			if ( $page < 1 + ( $adjacents * 2 ) ) {
				for ( $counter = 1; $counter < 4 + ( $adjacents * 2 ); $counter ++ ) {
					if ( $counter == $page ) {
						$setPaginate .= "<li><a class='current_page'>$counter</a></li>";
					} else {
						$setPaginate .= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
					}
				}
				$setPaginate .= "<li class='dot'>...</li>";
				$setPaginate .= "<li><a href='{$page_url}page=$lpm1'>$lpm1</a></li>";
				$setPaginate .= "<li><a href='{$page_url}page=$setLastpage'>$setLastpage</a></li>";
			} elseif ( $setLastpage - ( $adjacents * 2 ) > $page && $page > ( $adjacents * 2 ) ) {
				$setPaginate .= "<li><a href='{$page_url}page=1'>1</a></li>";
				$setPaginate .= "<li><a href='{$page_url}page=2'>2</a></li>";
				$setPaginate .= "<li class='dot'>...</li>";
				for ( $counter = $page - $adjacents; $counter <= $page + $adjacents; $counter ++ ) {
					if ( $counter == $page ) {
						$setPaginate .= "<li><a class='current_page'>$counter</a></li>";
					} else {
						$setPaginate .= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
					}
				}
				$setPaginate .= "<li class='dot'>..</li>";
				$setPaginate .= "<li><a href='{$page_url}page=$lpm1'>$lpm1</a></li>";
				$setPaginate .= "<li><a href='{$page_url}page=$setLastpage'>$setLastpage</a></li>";
			} else {
				$setPaginate .= "<li><a href='{$page_url}page=1'>1</a></li>";
				$setPaginate .= "<li><a href='{$page_url}page=2'>2</a></li>";
				$setPaginate .= "<li class='dot'>..</li>";
				for ( $counter = $setLastpage - ( 2 + ( $adjacents * 2 ) ); $counter <= $setLastpage; $counter ++ ) {
					if ( $counter == $page ) {
						$setPaginate .= "<li><a class='current_page'>$counter</a></li>";
					} else {
						$setPaginate .= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
					}
				}
			}
		}

		if ( $page < $counter - 1 ) {
			$setPaginate .= "<li><a href='{$page_url}page=$next'>Next</a></li>";
			$setPaginate .= "<li><a href='{$page_url}page=$setLastpage'>Last</a></li>";
		} else {
			$setPaginate .= "<li><a class='current_page'>Next</a></li>";
			$setPaginate .= "<li><a class='current_page'>Last</a></li>";
		}

		$setPaginate .= "</ul>\n";
	}


	return $setPaginate;
}

// Pagination
function displayPaginationBelow( $per_page, $page, $total, $letter ) {
	if ( $letter == "" ) {
		$page_url = "?";
	} else {
		$page_url = "?letter=" . $letter . "&";
	}
	$adjacents = "2";

	$page  = ( $page == 0 ? 1 : $page );
	$start = ( $page - 1 ) * $per_page;

	$prev        = $page - 1;
	$next        = $page + 1;
	$setLastpage = ceil( $total / $per_page );
	$lpm1        = $setLastpage - 1;

	$setPaginate = "";
	if ( $setLastpage > 1 ) {
		$setPaginate .= "<ul class='setPaginate'>";
		$setPaginate .= "<li class='setPage'>Page $page of $setLastpage</li>";
		if ( $setLastpage < 7 + ( $adjacents * 2 ) ) {
			for ( $counter = 1; $counter <= $setLastpage; $counter ++ ) {
				if ( $counter == $page ) {
					$setPaginate .= "<li><a class='current_page'>$counter</a></li>";
				} else {
					$setPaginate .= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
				}
			}
		} elseif ( $setLastpage > 5 + ( $adjacents * 2 ) ) {
			if ( $page < 1 + ( $adjacents * 2 ) ) {
				for ( $counter = 1; $counter < 4 + ( $adjacents * 2 ); $counter ++ ) {
					if ( $counter == $page ) {
						$setPaginate .= "<li><a class='current_page'>$counter</a></li>";
					} else {
						$setPaginate .= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
					}
				}
				$setPaginate .= "<li class='dot'>...</li>";
				$setPaginate .= "<li><a href='{$page_url}page=$lpm1'>$lpm1</a></li>";
				$setPaginate .= "<li><a href='{$page_url}page=$setLastpage'>$setLastpage</a></li>";
			} elseif ( $setLastpage - ( $adjacents * 2 ) > $page && $page > ( $adjacents * 2 ) ) {
				$setPaginate .= "<li><a href='{$page_url}page=1'>1</a></li>";
				$setPaginate .= "<li><a href='{$page_url}page=2'>2</a></li>";
				$setPaginate .= "<li class='dot'>...</li>";
				for ( $counter = $page - $adjacents; $counter <= $page + $adjacents; $counter ++ ) {
					if ( $counter == $page ) {
						$setPaginate .= "<li><a class='current_page'>$counter</a></li>";
					} else {
						$setPaginate .= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
					}
				}
				$setPaginate .= "<li class='dot'>..</li>";
				$setPaginate .= "<li><a href='{$page_url}page=$lpm1'>$lpm1</a></li>";
				$setPaginate .= "<li><a href='{$page_url}page=$setLastpage'>$setLastpage</a></li>";
			} else {
				$setPaginate .= "<li><a href='{$page_url}page=1'>1</a></li>";
				$setPaginate .= "<li><a href='{$page_url}page=2'>2</a></li>";
				$setPaginate .= "<li class='dot'>..</li>";
				for ( $counter = $setLastpage - ( 2 + ( $adjacents * 2 ) ); $counter <= $setLastpage; $counter ++ ) {
					if ( $counter == $page ) {
						$setPaginate .= "<li><a class='current_page'>$counter</a></li>";
					} else {
						$setPaginate .= "<li><a href='{$page_url}page=$counter'>$counter</a></li>";
					}
				}
			}
		}

		if ( $page < $counter - 1 ) {
			$setPaginate .= "<li><a href='{$page_url}page=$next'>Next</a></li>";
			$setPaginate .= "<li><a href='{$page_url}page=$setLastpage'>Last</a></li>";
		} else {
			$setPaginate .= "<li><a class='current_page'>Next</a></li>";
			$setPaginate .= "<li><a class='current_page'>Last</a></li>";
		}

		$setPaginate .= "</ul>\n";
	}


	return $setPaginate;
}


// End : Fetch login admin detail
function paginate_function( $item_per_page, $current_page, $total_records, $total_pages ) {
	$pagination = '';
	if ( $total_pages > 0 && $total_pages != 1 && $current_page <= $total_pages ) { //verify total pages and current page number
		$pagination .= '<ul class="pagination">';

		$right_links = $current_page + 3;
		$previous    = $current_page - 3; //previous link
		$next        = $current_page + 1; //next link
		$first_link  = true; //boolean var to decide our first link

		if ( $current_page > 1 ) {
			$previous_link = ( $previous == 0 ) ? 1 : $previous;
			$pagination    .= '<li class="first"><a data-page="1" title="First">&laquo;</a></li>'; //first link
			$pagination    .= '<li><a data-page="' . $previous_link . '" title="Previous">&lt;</a></li>'; //previous link
			for ( $i = ( $current_page - 2 ); $i < $current_page; $i ++ ) { //Create left-hand side links
				if ( $i > 0 ) {
					$pagination .= '<li><a data-page="' . $i . '" title="Page' . $i . '">' . $i . '</a></li>';
				}
			}
			$first_link = false; //set first link to false
		}

		if ( $first_link ) { //if current active page is first link
			$pagination .= '<li class="first active">' . $current_page . '</li>';
		} elseif ( $current_page == $total_pages ) { //if it's the last active link
			$pagination .= '<li class="last active">' . $current_page . '</li>';
		} else { //regular current link
			$pagination .= '<li class="active">' . $current_page . '</li>';
		}

		for ( $i = $current_page + 1; $i < $right_links; $i ++ ) { //create right-hand side links
			if ( $i <= $total_pages ) {
				$pagination .= '<li><a data-page="' . $i . '" title="Page ' . $i . '">' . $i . '</a></li>';
			}
		}
		if ( $current_page < $total_pages ) {
			$next_link  = ( $i > $total_pages ) ? $total_pages : $i;
			$pagination .= '<li><a data-page="' . $next_link . '" title="Next">&gt;</a></li>'; //next link
			$pagination .= '<li class="last"><a data-page="' . $total_pages . '" title="Last">&raquo;</a></li>'; //last link
		}

		$pagination .= '</ul>';
	}

	return $pagination; //return pagination links
}

function PT_array_to_csv( $data, $filename, $attachment = false, $headers = true ) {

	if ( $attachment ) {
		// send response headers to the browser
		header( 'Content-Type: text/csv' );
		header( 'Content-Disposition: attachment;filename=' . $filename );
		$fp = fopen( 'php://output', 'w' );
	} else {
		$fp = fopen( $filename, 'w' );
	}

	if ( $headers ) {
		if ( $data[0] ) {
//			$data[0]["No"] = 1;
			fputcsv( $fp, array_keys( $data[0] ) );
		}
	}

	$count = 1;
	foreach ( $data AS $row ) {
//		$row["No"] = $count;
		fputcsv( $fp, $row );
		$count ++;
	}

	fclose( $fp );
}
?>