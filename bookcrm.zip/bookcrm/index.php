<?php 
header("Location: book-appointments.php"); exit;
?>