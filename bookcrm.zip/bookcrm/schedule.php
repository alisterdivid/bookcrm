<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 2/28/2018
 * Time: 9:27 PM
 */

if(isset($_REQUEST['action'])){
    if($_REQUEST['action']== 'availableTimes'){
        ?>
        <div class="form-inline"><input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="09:00" id="appt1519308000"   >
            <label id='lbl_appt1519308000' for='appt1519308000'>9:00am</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="09:30" id="appt1519309800"   >
            <label id='lbl_appt1519309800' for='appt1519309800'>9:30am</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="10:00" id="appt1519311600"   >
            <label id='lbl_appt1519311600' for='appt1519311600'>10:00am</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="10:30" id="appt1519313400"   >
            <label id='lbl_appt1519313400' for='appt1519313400'>10:30am</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="11:00" id="appt1519315200"   >
            <label id='lbl_appt1519315200' for='appt1519315200'>11:00am</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="11:30" id="appt1519317000"   >
            <label id='lbl_appt1519317000' for='appt1519317000'>11:30am</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="12:00" id="appt1519318800"   >
            <label id='lbl_appt1519318800' for='appt1519318800'>12:00pm</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="12:30" id="appt1519320600"   >
            <label id='lbl_appt1519320600' for='appt1519320600'>12:30pm</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="13:00" id="appt1519322400"   >
            <label id='lbl_appt1519322400' for='appt1519322400'>1:00pm</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="13:30" id="appt1519324200"   >
            <label id='lbl_appt1519324200' for='appt1519324200'>1:30pm</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="14:00" id="appt1519326000"   >
            <label id='lbl_appt1519326000' for='appt1519326000'>2:00pm</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="14:30" id="appt1519327800"   >
            <label id='lbl_appt1519327800' for='appt1519327800'>2:30pm</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="15:00" id="appt1519329600"   >
            <label id='lbl_appt1519329600' for='appt1519329600'>3:00pm</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="15:30" id="appt1519331400"   >
            <label id='lbl_appt1519331400' for='appt1519331400'>3:30pm</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="16:00" id="appt1519333200"   >
            <label id='lbl_appt1519333200' for='appt1519333200'>4:00pm</label><br />

            <input type='radio' class='time-selection' name="time[]" data-readable-date="2018-02-22" value="16:30" id="appt1519335000"   >
            <label id='lbl_appt1519335000' for='appt1519335000'>4:30pm</label><br />

        </div>
<?php
    }
    if($_REQUEST['action'] == 'checkConflict'){
        $date = array();
        echo json_encode($date);
    }
}