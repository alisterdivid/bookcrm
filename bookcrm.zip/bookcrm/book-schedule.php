<?php
require_once("core/DB_Connection.php");
require_once("core/functions.php");
include ("acuityscheduling/schedule.php");