<?php
require_once("core/DB_Connection.php");
require_once("core/functions.php");
$ajax = isset($_REQUEST["ajax"]) ? $_REQUEST["ajax"] : "";

if ($ajax == "1"){
	include ("acuityscheduling/reports-action.php");
	die();
}
if (isset($_REQUEST["action"]) && $_REQUEST["action"] == 'detail'){
	include ("acuityscheduling/tpl/reports/detail.php");
	die();
}
?>
<?php include("acuityscheduling/reports.php"); ?>

