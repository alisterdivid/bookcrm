<?php
/**
 * Created by PhpStorm.
 * User: alexei
 * Date: 3/3/2018
 * Time: 2:51 PM
 */
require_once("core/DB_Connection.php");
require_once("core/functions.php");

$searchQuery = $_REQUEST['q'];
$sql = "select * from tbl_book_clients WHERE (firstName LIKE '%$searchQuery%' OR lastName LIKE '%$searchQuery%')";
$searchResult = $db->queryArray($sql);
if($searchResult == null) {
    ?>
    <button type="button" class="close-results" aria-hidden="true">&times;</button>
    <ul class="list-unstyled results-list">
        <li>No clients matching <strong><?php echo $searchQuery;?></strong> found.<br/><br/></li>
    </ul>
    <?php
}
else {
    ?>
    <button type="button" class="close-results" aria-hidden="true">&times;</button>
    <ul class="list-unstyled results-list">
        <?php
            for($i= 0; $i<count($searchResult); $i++) {
                $apptSql = "select * from leads WHERE td_request_date > now() AND siteuser_id = '".$searchResult[$i]['id']."'";
                $apptsLists = $db->queryArray($apptSql);
        ?>
                <li>
                    <a href="book-clients.php?action=detail&firstName=<?php echo $searchResult[$i]['firstName']?>&lastName=<?php echo $searchResult[$i]['lastName']?>&phone=<?php echo $searchResult[$i]['phone']?>"
                       class="detail-nav-link client-name">
                        <?php echo $searchResult[$i]['firstName'].' '.$searchResult[$i]['lastName']?>
                    </a>
                    <a href="book-appointments.php?action=new&timezone=America%2FNew_York&firstName=<?php echo $searchResult[$i]['firstName']?>&lastName=<?php echo $searchResult[$i]['lastName']?>&phone=<?php echo $searchResult[$i]['phone']?>&email=<?php echo $searchResult[$i]['email']?>"
                       class="schedule-btn detail-nav-link"><i class="icon-time"></i> Schedule</a>
                    <div class="body-italic-small appointment-next">
                        <?php
                          if($apptsLists != null) {
                              ?>
                              Next appointment
                              <a href="book-appointments.php?action=detail&id=<?php echo $apptsLists[0]['id'] ?>"
                                 class="detail-nav-link">
                                  <?php echo date('F d, Y', strtotime($apptsLists[0]['td_request_date'])); ?><?php echo $apptsLists[0]['td_request_time']; ?>
                              </a>
                              <?php
                          }
                          else{
                              echo ' No upcoming appointments';
                          }
                        ?>
                    </div>
                </li>
        <?php
            }
        ?>
    </ul>

    <?php
}
?>